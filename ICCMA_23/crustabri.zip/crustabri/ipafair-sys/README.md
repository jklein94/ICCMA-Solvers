# ipafair-sys

Rust types for the IPAFAIR API.
