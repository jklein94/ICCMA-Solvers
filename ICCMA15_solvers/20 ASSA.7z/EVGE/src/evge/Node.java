package evge;

public class Node {

	private String name;
	
	public Node(String name) {
		super();
		this.name = name;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Node() 
	{
	}
	
	@Override
	public String toString() {
		return "Node [name=" + name + "]";
	}
	

}
