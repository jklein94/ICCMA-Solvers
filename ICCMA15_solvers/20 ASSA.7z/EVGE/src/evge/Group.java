package evge;

import java.util.Vector;

public class Group 
{

	private Vector group = new Vector();
	
	public Group() 
	{
		
	}
	
	public void addIntoGroup(Node node)
	{
		this.group.add(node);
	}
	
	public Vector getGroup()
	{
		return this.group;
	}
	
	public int isEqual(Group p2)
	{
		Vector v1 = this.group;
		Vector v2 = p2.getGroup();
		
		int exit_code=1;
	    if (v1.size()==p2.getMembersSize())
	    {
	    	int q=0;
	    	for (int i=0; i<v1.size(); i++)
			{
				Node n1 = (Node)v1.elementAt(i);
				Node n2 = (Node)v2.elementAt(i);
				if (n1.getName().equalsIgnoreCase(n2.getName()))
				{
					q++;
				}
				if (q==v1.size())
				{
					exit_code=0;
				}
			}
	    }
		return exit_code;
	}
    
	
	public boolean isSubSet(Group p2)
	{
		boolean exit_code=false;
		Vector v2 = p2.getGroup();
		int g = p2.getMembersSize();
		int gg =0;
		for (int i=0; i<v2.size(); i++)
		{
			Node n = (Node)v2.elementAt(i);
			if (nodeExistsInGroup(n))
			{
				gg++;
			}
		}
		if (gg==g)
		{
			  exit_code=true;
		}
		return exit_code;
	}
	
	
	public boolean nodeExistsInGroup(Node n)
	{
		boolean exit_code=false;
		for (int i=0; i<group.size(); i++)
		{
			Node node = (Node)group.elementAt(i);
		    if (node.getName().equalsIgnoreCase(n.getName()))
		    {
		    	exit_code=true;
		    	break;
		    }
		}
		return exit_code;
	}
	
	
	
	public int getMembersSize()
	{
		return this.group.size();
	}
	
	public  void printGroup()
	{
		int j=0;
		String rt="[";
		for (int i=0; i<group.size(); i++)
		{
			Node n = (Node)group.elementAt(i);
			rt +=n.getName()+",";
		}
		rt = rt.substring(0,rt.length()-1);
		rt +="]";
		System.out.println(rt);
	}
	
	
	public  void printGroup2()
	{
		
		for (int i=0; i<group.size(); i++)
		{
			Node n = (Node)group.elementAt(i);
			System.out.print(n.getName()+" ,");
		}
	    System.out.println();
		
		
	}
	
	public static void main(String[] args) 
	{
		Node n1 = new Node("1");
		Node n2 =  new Node("2");
		Node n3 = new Node("3");
		Node n4 = new Node("4");
		
		Group g1 = new Group();
		g1.addIntoGroup(n1);
		g1.addIntoGroup(n2);
		g1.addIntoGroup(n3);
		
		
		//g.printGroup2();
		g1.printGroup();
		
		
		Group g2 = new Group();
		g2.addIntoGroup(n1);
		g2.addIntoGroup(n4);
		g2.printGroup();
		
		//System.out.println(g1.isSubSet(g2));
		System.out.println(g1.isSubSet(g2));
	    
	}

}
