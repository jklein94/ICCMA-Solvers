package evge;

public class Edge {

	
	private Node start;
	private Node end;
	
	public Edge(Node start, Node end) {
		super();
		this.start = start;
		this.end = end;
	}

	public Node getStart() {
		return start;
	}

	public void setStart(Node start) {
		this.start = start;
	}

	public Node getEnd() {
		return end;
	}

	public void setEnd(Node end) {
		this.end = end;
	}

	public Edge() 
	{
		
	}

	@Override
	public String toString() {
		return "Edge [start=" + start + ", end=" + end + "]";
	}
	

}
