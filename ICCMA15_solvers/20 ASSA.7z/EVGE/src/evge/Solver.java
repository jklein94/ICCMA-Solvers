package evge;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Date;
import java.util.Vector;

import Jama.Matrix;

public class Solver {

	private String filename="";
    private String format="";
    private String problem="";
    private String additional="";
	
	Vector NODES = new Vector();
	Vector EDGES = new Vector();
	String[ ][ ] adjancyMatrix = null;
	String[ ][ ] allPossibleNodesCombination = null;
	
	Vector CONFLICTFREELIST = new Vector();
	Vector STABLELIST = new Vector();
	
	    //****************************************************************************************************************************************
	    //****************************************************************************************************************************************
		public Solver(String filename, String format, String problem,String additional) 
		{
			super();
			this.filename = filename;
			this.format = format;
			this.problem = problem;
			this.additional = additional;
			
			
			if (problem.equalsIgnoreCase("DC-ST"))
			{
			    if (format.equalsIgnoreCase("tgf"))
			    {
			    	 File f = new File(filename);
			    	 if (f.exists())
			    	 {
			    		 evge();
			    		 if (!additional.equalsIgnoreCase(""))
			    		 {
			    			  Node n = new Node(additional);
			    			  Group p2 = new Group();
			    			  p2.addIntoGroup(n);
			    			  
			    			  int t=0;
			    			  for (int i=0; i<STABLELIST.size(); i++)
							  {
									Group e= (Group)STABLELIST.elementAt(i);
									if (e.isSubSet(p2))
									{
										t++;
									}								
							  } 
			    			  if (t>0)
			    			  {
			    				  System.out.println("[YES]");
			    			  }
			    			  else
			    			  {
			    				  System.out.println("[NO]");  
			    			  }
			    		 }
			    		 else
			    		 {
			    			 System.out.println(" No arguments given.");
			    		 }
			    		 
			    	 }
			    	 else
			    	 {
			    		 System.out.println(" File does not exist.");
			    	 }
			    }
			    else
			    {
			    	System.out.println(" Unknown or Unsupported Format");
			    }
			}
			else if (problem.equalsIgnoreCase("DS-ST"))
			{
				 if (format.equalsIgnoreCase("tgf"))
				    {
				    	 File f = new File(filename);
				    	 if (f.exists())
				    	 {
				    		 evge();
				    		 if (!additional.equalsIgnoreCase(""))
				    		 {
				    			  Node n = new Node(additional);
				    			  Group p2 = new Group();
				    			  p2.addIntoGroup(n);
				    			  
				    			  int t=0;
				    			  for (int i=0; i<STABLELIST.size(); i++)
								  {
										Group e= (Group)STABLELIST.elementAt(i);
										if (e.isSubSet(p2))
										{
											t++;
										}								
								  } 
				    			  if (t==STABLELIST.size())
				    			  {
				    				  System.out.println("[YES]");
				    			  }
				    			  else
				    			  {
				    				  System.out.println("[NO]");  
				    			  }
				    		 }
				    		 else
				    		 {
				    			 System.out.println(" No arguments given.");
				    		 }
				    	 }
				    	 else
				    	 {
				    		 System.out.println(" File does not exist.");
				    	 }
				    }
				    else
				    {
				    	System.out.println(" Unknown or Unsupported Format");
				    }
			}
			else if (problem.equalsIgnoreCase("EE-ST"))
			{
				 if (format.equalsIgnoreCase("tgf"))
				    {
				    	 File f = new File(filename);
				    	 if (f.exists())
				    	 {
				    		  evge();
				    		  for (int i=0; i<STABLELIST.size(); i++)
							  {
									Group e= (Group)STABLELIST.elementAt(i);
									e.printGroup();
							  }
				    	 }
				    	 else
				    	 {
				    		 System.out.println(" File does not exist.");
				    	 }
				    }
				    else
				    {
				    	System.out.println(" Unknown or Unsupported Format");
				    }
			}
			else if (problem.equalsIgnoreCase("SE-ST"))
			{
				 if (format.equalsIgnoreCase("tgf"))
				    {
				    	 File f = new File(filename);
				    	 if (f.exists())
				    	 {
				    		  evge();
				    		  if (STABLELIST.size() > 0)
				    		  {
				    			  for (int i=0; i<STABLELIST.size(); i++)
				    			  {
				    				  Group e= (Group)STABLELIST.elementAt(i);
				    				  e.printGroup();
				    			  }
				    		  }
				    		  else
				    		  {
				    			  System.out.println(" No Stable.");  
				    		  }
				    	 }
				    	 else
				    	 {
				    		 System.out.println(" File does not exist.");
				    	 }
				    }
				    else
				    {
				    	System.out.println(" Unknown or Unsupported Format");
				    }
			}
			else
			{
				
			}
			
			
		}
		//****************************************************************************************************************************************
		//****************************************************************************************************************************************
		public void evge()
		{
			
			    //System.out.println("0");
				parseTrivialFiles(filename);
				//System.out.println("1");
				this.adjancyMatrix = getMatrix();
				//System.out.println("2");
				
			
				this.allPossibleNodesCombination=getAllCombinationsMatrix(this.NODES.size());
			
				
				
				//printMatrix(this.allPossibleNodesCombination);
				/*
				int[ ][ ] m1 = null;
				int[ ][ ] m2 = null;
				int[ ][ ] rs = null;
				m1=covertMatrixtoInteger(this.adjancyMatrix); 
				m2=covertMatrixtoInteger(this.allPossibleNodesCombination);
				*/
				//rs=calculateProductMatrixes (m1,m2);
				//printMatrix(rs);
				//rs=calculateProductMatrixes (m2,m1);
				//printMatrix(rs);
				
				double[ ][ ] m1 = null;
				double[ ][ ] m2 = null;
				m1=covertMatrixtoDouble(this.adjancyMatrix);
				m2=covertMatrixtoDouble(this.allPossibleNodesCombination);
				calculateProductMatrixes (m1,m2);
				//System.out.println(new Date()+" System Ends.");
				
		}
		//****************************************************************************************************************************************
		//****************************************************************************************************************************************
		public int isConflictFreeNode(Group p)
		{
			int exit_code=1;
			if (CONFLICTFREELIST.size() > 0)
			{
				for (int i=0; i<CONFLICTFREELIST.size(); i++)
				{
					Group e= (Group)CONFLICTFREELIST.elementAt(i);
					if (e.isEqual(p)==0)
					{
						exit_code=0;
					}
				}
			}
			return exit_code;
		}
		//****************************************************************************************************************************************
		//****************************************************************************************************************************************
		public void calculateStable(Matrix m1, Matrix m2)
		{
			 double [ ][ ] B = m2.getArray();
			 double [ ][ ] C = m1.getArray();
			
			 int rows = B.length;
			 int cols = B[0].length;
			 
			 int nodesSize = rows;
			
			 
			double[ ][ ] CV = new double [rows][cols];
			
			for (int i=0; i<rows; i++)
			{
				
				for (int j=0; j<cols; j++)
				{
					if (B[i][j] == 0.0)
					{
						CV[i][j]=1.0;
					}
					else
					{
						CV[i][j]=0.0;
					}
				}
				 
			}
			
			/*
			double[ ][ ] DF0 = transposeMatrix (CV);
			double[ ][ ] DF1 = transposeMatrix (CV);
			printMatrix(DF0);
			printMatrix(DF1);
			*/
			
			CV = transposeMatrix (CV);
			C  = transposeMatrix (C);
			
			rows = C.length;
			cols = C[0].length;
			nodesSize = rows;
			
			//printMatrix(CV);
			//printMatrix(C);
			
			 int j=0;
			 int q=0;
			 for (int i=0; i<cols; i++)
			 {		
				 	Group group = new Group();
					while(j<rows)
					{
					 
						 if (C[j][i]==CV[j][i])
						 {
							 q++;
							 if (C[j][i] == 0)
							 {
								 Node node = new Node(getNodeByPosition(j));
								 group.addIntoGroup(node);
							 }						 
							 //System.out.print(node.getName()+" is added ..., ");
						 }
						 j++;
					}
					//System.out.println("row end ");
					if (q==nodesSize)
					{	
						if (isConflictFreeNode(group)==0) 
						{
							//System.out.println(" Group is stable");
							//group.printGroup();
							STABLELIST.add(group);
						}
						q=0;
					}
					else
					{
						group = new Group();
						q=0;
					}
					j=0;
					

			 }
			
			
			//System.out.println("***********************************************");
			//printMatrix(B);
			//System.out.println("****************** All Conditions antristrofa *****************************");
			//printMatrix(CV);
			//System.out.println("**********************Result A * All conditions *************************");
			//printMatrix(C);
			//System.out.println("***********************************************");
		}
		//****************************************************************************************************************************************
		//****************************************************************************************************************************************
		public void calculateConflictFree(Matrix m1, Matrix m2)
		{
			double[ ][ ] A = m1.getArray();
			
			double[ ][ ] B = m2.getArray();
			
			 int rows = A.length;
			 int cols = A[0].length;
			
			 //printMatrix(A);
			 
			 int j=0;
			 int n=0;
			 int t=0;
			 boolean found = false;
			 for (int i=0; i<cols; i++)
			 {		
				Group group = new Group();
				while(j<rows)
				{
					 if (A[j][i] > 0)
					 {
						 found =true;
						 n++;
						 //System.out.print("Node:"+j+",");
						 Node node = new Node(getNodeByPosition(j));
						 group.addIntoGroup(node);
						 if (B[j][i]==0)
						 {
							 t++;
						 }
					 }
					 j++;
				}
				j=0;
				if (found)
				{
					if (t==n)
					{
						//System.out.println("  Conflict free passed.");
						CONFLICTFREELIST.add(group);
						
					}
					else
					{
						//System.out.println("  Conflict free failed.");
					}
					t=n=0;
				}
				
			 }
			 
		}
		
		//****************************************************************************************************************************************
		//****************************************************************************************************************************************
			public void calculateProductMatrixes (double [][]m1, double [][]m2)
			{
				double[ ][ ] tr = null;
				double[ ][ ] test = null;
				tr = transposeMatrix (m2);
				Matrix ALL = new Matrix(m2);
				Matrix Y = new Matrix(m2);
				Matrix A = new Matrix(m1);
				Matrix B = new Matrix(tr);
				//A.print(1,1);
				//System.out.println("X");
				//B.print(1,1);
				Matrix C = A.times(B);
				//System.out.println("||");
				//C.print(1,1);
				
				//System.out.println("* * * Conflict free test * * *");
				calculateConflictFree(B,C);
				
				
				/*
				System.out.println("* * * Pass nodes: * * *");
				for (int i=0; i<CONFLICTFREELIST.size(); i++)
				{
					Group e= (Group)CONFLICTFREELIST.elementAt(i);
					e.printGroup();
				}
				*/
				
				
				
				//System.out.println("* * * Stable test * * *");
				// C= A x ALL Conditions 
				// B= All Conditions 
				//C.print(1,1);
				//B.print(1, 1);
				//calculateStable(C,B);
				
				
				//System.out.println("##################################################################");
				//System.out.println("##################################################################");
				//Y.print(1,1);
				//System.out.println("X");
				//A.print(1,1);
				
				Matrix D = Y.times(A);
				
				//System.out.println("* * * Stable test 2 * * *");
				// Where D is ALL conditions x A
				//D.print(1,1);
				//ALL.print(1,1);
				calculateStable(D,ALL);
				
				
				
				//System.out.println("||");
				//D.print(1,1);
				//System.out.println("##################################################################");
				//System.out.println("##################################################################");
				//test = D.getArray();
				//printMatrix(test);
			}
	//****************************************************************************************************************************************
	//****************************************************************************************************************************************
		public int [][] calculateProductMatrixes (int [][]m1, int [][]m2)
		{
			 
			  int m1_rows = m1.length;
			  int m1_cols = m1[0].length;
			  
			  int m2_rows = m2.length;
			  int m2_cols = m2[0].length;
			  
			  int[] [] transpose = null;
			  int[ ][ ] multi = null;
			  
			  System.out.println("");
			  System.out.println("Start multiplying ..");
			  System.out.println("Input:");
			  System.out.println("Matrix 1: ["+m1_rows+" X "+m1_cols+"]");
			  System.out.println("Matrix 2: ["+m2_rows+" X "+m2_cols+"]");
			  
			  if ((m1_rows != m2_rows ) && (m1_cols==m2_rows))
			  {
				  System.out.println("1");
				  m1=transposeMatrix(m1);
				  
				  
		
				   
			  }
			  else if ((m1_rows != m2_rows ) && (m1_rows==m2_cols)) 
			  {
				  System.out.println("2");
				  m2=transposeMatrix(m2);
				  
				  int a_rows = m1.length;
				  int a_columns = m1[0].length;
				  int b_columns = m2[0].length;
				  

				  
				  multi = new int [a_columns][b_columns];
				  
				   for (int i = 0; i < a_rows; i++) { // aRow
			            for (int j = 0; j < b_columns; j++) { // bColumn
			                for (int k = 0; k < a_columns; k++) { // aColumn
			                    multi[i][j] += m1[i][k] * m2[k][j];
			                }
			            }
			        }
				   System.out.println("Results:");
				  
			  }
			  else
			  {
			  }
			  return multi;
		}
	//****************************************************************************************************************************************
	//****************************************************************************************************************************************
	public int [][] multiplyMatrixes (String [][]m1, String [][]m2)
	{
		 int[ ][ ] multi = null;
		  int[ ][ ] adj = null;
		  int[] [] transpose = null;
		 
		  int m1_rows = m1.length;
		  int m1_cols = m1[0].length;
		  
		  int m2_rows = m2.length;
		  int m2_cols = m2[0].length;
		  
		  
		  
		  System.out.println("");
		  System.out.println("Start multiplying ..");
		  System.out.println("Input:");
		  System.out.println("Matrix 1: ["+m1_rows+" X "+m1_cols+"]");
		  System.out.println("Matrix 2: ["+m2_rows+" X "+m2_cols+"]");
		  
		  if ((m1_rows != m2_rows ) && (m1_rows==m2_cols))
		  {
			  
			  System.out.println("Transpose Matrix is needed.");
			  
			  transpose=transposeMatrix(m2);
			  System.out.println("Transpose: ["+transpose.length+" X "+transpose[0].length+"]");
			  
			  System.out.println("");
			  adj=covertMatrixtoInteger(m1); 
			  //printMatrix(adj);
			  
			  int rows = adj.length;
			  int aColumns = adj[0].length;
			  int columns = transpose[0].length;
			  
			  multi = new int [rows][columns];
			  //System.out.println("Multi Matrix: ["+rows+" X "+columns+"]");
			  
			   for (int i = 0; i < rows; i++) { // aRow
		            for (int j = 0; j < columns; j++) { // bColumn
		                for (int k = 0; k < aColumns; k++) { // aColumn
		                    multi[i][j] += adj[i][k] * transpose[k][j];
		                }
		            }
		        }
			   System.out.println("Results:");
			     printMatrix(multi);
			
		  }
		  else
		  {
			  //System.out.println("Start multiplying ..");
			  int rows = adj.length;
			  int aColumns = adj[0].length;
			  int columns = m2[0].length;
			  int[ ][ ] allcond = null;
			  adj=covertMatrixtoInteger(m1); 
			  allcond=covertMatrixtoInteger(m1); 
			  
			  
			  multi = new int [rows][columns];
			  //System.out.println("Multi Matrix: ["+rows+" X "+columns+"]");
			  
			   for (int i = 0; i < rows; i++) { // aRow
		            for (int j = 0; j < columns; j++) { // bColumn
		                for (int k = 0; k < aColumns; k++) { // aColumn
		                    multi[i][j] += adj[i][k] * allcond[k][j];
		                }
		            }
		        }
			   System.out.println("Results:");
			     printMatrix(multi);
		  }
		  
		 
		 
		
		 return multi;
	}
	//****************************************************************************************************************************************
	//****************************************************************************************************************************************
			public double [][] transposeMatrix (double [][]m1)
			{
				 int m1_rows = m1.length;
				 int m1_cols = m1[0].length;
				 int tmp =-1;
				 double[ ][ ] transpose = new double [m1_cols][m1_rows];
				 
				 for (int i=0; i<m1_rows; i++)
				 {		
					for (int j=0; j<m1_cols; j++)
					{
						transpose[j][i]=m1[i][j];
					}
				 }
				 return  transpose;
			}
		//****************************************************************************************************************************************
		//****************************************************************************************************************************************
	//****************************************************************************************************************************************
		//****************************************************************************************************************************************
		public int [][] transposeMatrix (int [][]m1)
		{
			 int m1_rows = m1.length;
			 int m1_cols = m1[0].length;
			 int tmp =-1;
			 int[ ][ ] transpose = new int [m1_cols][m1_rows];
			 
			 for (int i=0; i<m1_rows; i++)
			 {		
				for (int j=0; j<m1_cols; j++)
				{
					transpose[j][i]=m1[i][j];
				}
			 }
			 return  transpose;
		}
	//****************************************************************************************************************************************
	//****************************************************************************************************************************************
	public int [][] transposeMatrix (String [][]m1)
	{
		 int m1_rows = m1.length;
		 int m1_cols = m1[0].length;
		 int tmp =-1;
		 int[ ][ ] transpose = new int [m1_cols][m1_rows];
		 
		 for (int i=0; i<m1_rows; i++)
		 {		
			for (int j=0; j<m1_cols; j++)
			{
				tmp=Integer.parseInt(m1[i][j]);
				transpose[j][i]=tmp;
			}
		 }
		 return  transpose;
	}
	//****************************************************************************************************************************************
			//****************************************************************************************************************************************
			public void printMatrix(double [][]m1)
			{
				int rows = m1.length;
				int columns = m1[0].length;
				
				for (int i=0; i<rows; i++)
				{
					
					for (int j=0; j<columns; j++)
					{
						 System.out.print(" | " + m1[i][j] + " | ");	
					}
					 System.out.println("");
					 
				}	 
				
			}
	//****************************************************************************************************************************************
		//****************************************************************************************************************************************
		public void printMatrix(int [][]m1)
		{
			int rows = m1.length;
			int columns = m1[0].length;
			
			for (int i=0; i<rows; i++)
			{
				
				for (int j=0; j<columns; j++)
				{
					 System.out.print(" | " + m1[i][j] + " | ");	
				}
				 System.out.println("");
				 
			}	 
			
		}
	//****************************************************************************************************************************************
	//****************************************************************************************************************************************
	public void printMatrix(String [][]m1)
	{
		int rows = m1.length;
		int columns = m1[0].length;
		
		for (int i=0; i<rows; i++)
		{
			
			for (int j=0; j<columns; j++)
			{
				 System.out.print(" | " + m1[i][j] + " | ");	
			}
			 System.out.println("");
			 
		}
		
	}
	//****************************************************************************************************************************************
	//****************************************************************************************************************************************
	public double[][] covertMatrixtoDouble(String [][]m1)
	{
		int rows = m1.length;
		int columns = m1[0].length;
		double tmp=-1;
		double[ ][ ] matrix = new double [rows][columns];
		
		//print
		for (int i=0; i<rows; i++)
		{
			
			for (int j=0; j<columns; j++)
			{
				tmp = Double.parseDouble(m1[i][j]);
			   matrix[i][j]=tmp;
			}
		}
		return matrix;
	}
	//****************************************************************************************************************************************
	//****************************************************************************************************************************************
		public double[][] covertMatrixtoDouble(int [][]m1)
		{
			int rows = m1.length;
			int columns = m1[0].length;
			double tmp=-1;
			double[ ][ ] matrix = new double [rows][columns];
			
			//print
			for (int i=0; i<rows; i++)
			{
				
				for (int j=0; j<columns; j++)
				{
				   tmp = Double.parseDouble(""+m1[i][j]);
				   matrix[i][j]=tmp;
				}
			}
			return matrix;
		}
	//****************************************************************************************************************************************
	//****************************************************************************************************************************************
	public int[][] covertMatrixtoInteger(String [][]m1)
	{
		int rows = m1.length;
		int columns = m1[0].length;
		int tmp=-1;
		int[ ][ ] matrix = new int [rows][columns];
		
		//print
		for (int i=0; i<rows; i++)
		{
			
			for (int j=0; j<columns; j++)
			{
			   tmp = Integer.parseInt(m1[i][j]);
			   matrix[i][j]=tmp;
			}
		}
		return matrix;
	}
	//****************************************************************************************************************************************
	//****************************************************************************************************************************************
	public Solver() 
	{
		
	}
	//****************************************************************************************************************************************
	//****************************************************************************************************************************************
	public void printEdges()
	{
		System.out.println("Input Edges:");
		for (int i=0; i<EDGES.size(); i++)
		{
			Edge e= (Edge)EDGES.elementAt(i);
			System.out.println(e);
		}
	}
	//****************************************************************************************************************************************
	//****************************************************************************************************************************************
	public void printNodes()
	{
		System.out.println("Input Nodes:");
		for (int i=0; i<NODES.size(); i++)
		{
			Node n= (Node)NODES.elementAt(i);
			System.out.println(n);
		}
	}
	//****************************************************************************************************************************************
	//****************************************************************************************************************************************
	//  position = 2n, number which number to print  
	public String [][] getbinaryMatrix (int positions, int number)
	 {
		 String[ ][ ] matrix = null;
		 matrix = new String[1][positions];
		 int t=0;
		 int tmp=0;
		 int m=powerOf(2,positions-1);
		 int q=0;
		 boolean f= true;
		 for (int i=positions-1; i>=0; i--)
		 {
			 
			 tmp=t;
			 t=t+powerOf(2,i);
			 
			 if (t > number)
			 {
				 matrix[0][q]="0";
				 t=tmp;
			 }
			 else
			 {
				 matrix[0][q]="1";
			 }
			 q++;
			 
		 }
		 return matrix;
	 }
	 
	//****************************************************************************************************************************************
	//****************************************************************************************************************************************
	 public String [][] getAllCombinationsMatrix(int numberOfNodes)
     {
		 	String[ ][ ] matrix = null;
		 	String[ ][ ] tmp = null;
		 	
            int columns=numberOfNodes;
            int rows=powerOf(2,numberOfNodes);
            
            matrix = new String[rows][columns];
            tmp= new String[1][numberOfNodes];
            
            for (int i=rows-1; i>=0; i--)
    		{
    				tmp=getbinaryMatrix (numberOfNodes,i);
    				
    				
    				for (int w=0; w<1; w++)
    				{
    					for (int j=0; j<numberOfNodes; j++)
    					{
    							matrix[i][j]=tmp[w][j];	
    					}	 
    				}
    				
    		}
           
            
            
            
          /*
			for (int i=0; i<rows; i++)
			{
				
				for (int j=0; j<columns; j++)
				{
				   System.out.print(" | " + matrix[i][j] + " | ");	
				}
				 System.out.println("");
			}
		 */
            return matrix;

     }
	
	//****************************************************************************************************************************************
	//****************************************************************************************************************************************
	 public int powerOf(int base, int power)
	 {
		 int a = base;
		 if (power>0)
		 {
			 for (int k=1; k<power; k++)
			 {
                 a *=base;
			 } 
		 }
		 else if (power==0)
		 {
			 a=1;
		 }
		 else
		 {
			 a=-1;
		 }
		 return a;
	 }
	
	//****************************************************************************************************************************************
	//****************************************************************************************************************************************
	public String [][] getMatrix()
	{
		String[ ][ ] matrix = null;
		
		if (NODES.size() > 0)
		{
			int rows = NODES.size();
			int columns = NODES.size();
			 matrix = new String[rows][columns];
			// Initialized to 0
			for (int i=0; i<rows; i++)
			{
				for (int j=0; j<columns; j++)
				{
				   matrix[i][j]="0";	
				}
			}
			
			// Set edges
			for (int i=0; i<EDGES.size(); i++)
			{
				Edge edge= (Edge)EDGES.elementAt(i);
				Node s = edge.getStart();
				Node e = edge.getEnd();
				//System.out.println(s.getName()+":"+e.getName());
				matrix[getNodePosition(s.getName())][getNodePosition(e.getName())]="1";
			}
			
			//print
			/*
			 System.out.println("Pinakas gitonias !!!");
			for (int i=0; i<rows; i++)
			{
				
				for (int j=0; j<columns; j++)
				{
				   System.out.print(" | " + matrix[i][j] + " | ");	
				}
				 System.out.println("");
			}
			*/
		}
		return matrix;
	}
	//****************************************************************************************************************************************
	//****************************************************************************************************************************************
	public int getNodePosition(String nodeName)
	{
		int position = -1;
		for (int i=0; i<NODES.size(); i++)
		{
			Node n= (Node)NODES.elementAt(i);
			if (n.getName().equalsIgnoreCase(nodeName))
			{
				position = i;
				break;
			}
		}
		return position;
	}
	
	//****************************************************************************************************************************************
	//****************************************************************************************************************************************
	public String getNodeByPosition(int position)
	{		
		Node n= (Node)NODES.elementAt(position);
		return n.getName();
	}
	//****************************************************************************************************************************************
	//****************************************************************************************************************************************
	private Edge parseTrivialEdges(String line)
	{
		String tmp="";
		Node startNode = new Node();
		Node endNode = new Node();
		for (int i = 0; i < line.length(); i++) 
		{
		    tmp += line.charAt(i);
			if (Character.isWhitespace(line.charAt(i))) 
		    {
		    	startNode.setName(tmp.trim());
		    	tmp="";
		    }
		}
		endNode.setName(tmp.trim());
		Edge e = new Edge(startNode,endNode);
		//System.out.println(e.toString());
		return e;
	}
	
	
	//****************************************************************************************************************************************
	//****************************************************************************************************************************************
	public void parseTrivialFiles(String f )
	{
		
	
		BufferedReader br = null;
		boolean found= false;
		Node n = null;
		try 
		{
			String sCurrentLine;
			br = new BufferedReader(new FileReader(f));
			while ((sCurrentLine = br.readLine()) != null) 
			{
					if (!sCurrentLine.equalsIgnoreCase("#") && (!found))
					{
						//System.out.println("Node:["+sCurrentLine+"] found.");
						n = new Node(sCurrentLine);
						this.NODES.add(n);					
					}
					else
					{
						found=true;
					}
					
					if (found)
					{
						if (!sCurrentLine.equalsIgnoreCase("#"))
						{
							Edge e = parseTrivialEdges(sCurrentLine);
							this.EDGES.add(e);
						}
						
					}
			}

		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		} 
		finally 
		{
			try 
			{
				if (br != null)br.close();
			} 
			catch (IOException ex) 
			{
				ex.printStackTrace();
			}
		}
		   
	}

	//****************************************************************************************************************************************
	//****************************************************************************************************************************************
	//  set get method
	//****************************************************************************************************************************************
	//****************************************************************************************************************************************
	public String getFilename() {
		return filename;
	}


	public void setFilename(String filename) {
		this.filename = filename;
	}


	public String getFormat() {
		return format;
	}


	public void setFormat(String format) {
		this.format = format;
	}


	public String getProblem() {
		return problem;
	}


	public void setProblem(String problem) {
		this.problem = problem;
	}


	public String getAdditional() {
		return additional;
	}


	public void setAdditional(String additional) {
		this.additional = additional;
	}


	//****************************************************************************************************************************************
	//****************************************************************************************************************************************
	//  MAIN 
	//****************************************************************************************************************************************
	//****************************************************************************************************************************************
	public static void main(String[] args) 
	{
		String filename="";
		String format="";
		String problem="";
		String additional="";
		boolean printFormats=false;
		boolean printProblems=false;
		
		
		boolean problemIsGiver=false;
		boolean formatIsGiven=false;
		boolean fileIsGiven=false;
		boolean argsIsGiven=false;
		
		//Solver s= new Solver("C:\\EVGE\\benchmark\\iccma15_testcases2\\test_cases2\\tgf\\116134__200__18_19_87__57.tgf","tgf","SE-ST","");
		
		//Solver s= new Solver("C:\\EVGE\\data\\trivial4b.txt","tgf","DC-ST","9");
		//Solver s= new Solver("C:\\EVGE\\data\\trivial4b.txt","tgf","DC-ST","1");
		//Solver s= new Solver("C:\\EVGE\\data\\trivial4.txt","tgf","SE-ST","");
		//Solver s= new Solver("C:\\EVGE\\data\\trivial.txt","tgf","SE-ST","");
		
		
		if (args.length > 0) 
		{
		    
			for ( int i=0; i<args.length; i++)
			{
				 if (args[i].equalsIgnoreCase("-f"))
				 {
					 filename=args[i+1];
					 if (!filename.equalsIgnoreCase(""))
					 {
						 fileIsGiven=true;
					 }
				 }
				 
				 if (args[i].equalsIgnoreCase("-fo"))
				 {
					 format=args[i+1];
					 if (!format.equalsIgnoreCase(""))
					 {
						 formatIsGiven=true;
					 }
					
				 }
				 
				 if (args[i].equalsIgnoreCase("-p"))
				 {
					 problem=args[i+1];
					 if (!problem.equalsIgnoreCase(""))
					 {
						 problemIsGiver=true;
					 }
				 }
				 
				 if (args[i].equalsIgnoreCase("-a"))
				 {
					 additional=args[i+1];
					 if (!additional.equalsIgnoreCase(""))
					 {
						 argsIsGiven=true; 
					 }
					 
				 }
				 if (args[i].equalsIgnoreCase("-help"))
				 {
					 System.out.println("Program arguments:");
					 System.out.println("                  -f {filename} -fo {format} -p {problem} -a {additional}");
				 }
				 if (args[i].equalsIgnoreCase("--formats"))
				 {
					 printFormats=true;
				 }
				 if (args[i].equalsIgnoreCase("--problems"))
				 {
					 printProblems=true;
				 }	 
			}// end for
			//*************************************************************************************************
			if ((problemIsGiver)&&(formatIsGiven)&&(fileIsGiven))
			{
				 Solver s= new Solver(filename,format,problem,additional);
			
			}
			 else
			 {
				 	if (printFormats)
					{
						System.out.println("[tgf]");
					}
				 	else if (printProblems)
					{
						System.out.println("[DC-ST,DS-ST,EE-ST,SE-ST]");
					}
				 	else
				 	{
						System.out.println("Program arguments:");
						System.out.println("                  [-f {filename} -fo tgf -p DC-ST|DS-ST|EE-ST|SE-ST -a {additional}]");
						System.out.println("                  [--formats]");
						System.out.println("                  [--problems]");
				 	}
					
			 }
			 //*******************************************************************************************************************************
		}
		else
		{
			System.out.println("Solver v.0.1");
			System.out.println("Evgenios Hadjisoteriou, Michael A. Georgiou");
			System.out.println();
			System.out.println("Program arguments:");
			System.out.println("                  [-f {filename} -fo tgf -p DC-ST|DS-ST|EE-ST|SE-ST -a {additional}]");
			System.out.println("                  [--formats]");
			System.out.println("                  [--problems]");
		}
		
		
		
		
	}
	

}
