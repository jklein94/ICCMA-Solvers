/*
 * March_hiWrapper.cpp
 *
 *  Created on: Jun 1, 2012
 *      Author: joh
 */

#include "ExternalSolver.h"
//#include "stdio.h"
//#include "iostream"
//#include "string"

ExternalSolver::ExternalSolver(std::string filename) {
	this->filename = filename;
	maxVar = 0;
	externalError = false;
}

bool ExternalSolver::addClause(AbstractLit p, AbstractLit q) {
//	solver.addClause(getLit(p),getLit(q));
	std::vector<AbstractLit> lits;
	lits.push_back(p);
	lits.push_back(q);
	addClause_(lits);
	return true;
}

bool ExternalSolver::addClause(AbstractLit p) {
//	solver.addClause(getLit(p));
	std::vector<AbstractLit> lits;
	lits.push_back(p);
	addClause_(lits);
	return true;
}

bool ExternalSolver::addClause(AbstractLit p, AbstractLit q, AbstractLit r) {
//	solver.addClause(getLit(p),getLit(q),getLit(r));
	std::vector<AbstractLit> lits;
	lits.push_back(p);
	lits.push_back(q);
	lits.push_back(r);
	addClause_(lits);
	return true;
}

bool ExternalSolver::addClause_(std::vector<AbstractLit>& ps) {
//	Minisat::vec<Minisat::Lit> vec;
//	std::vector<AbstractLit>::iterator it = ps.begin();
//	while(it != ps.end()) {
//		vec.push(getLit(*it));
//		it++;
//	}
//	if ((*ps.begin()).x > 260)
//		int y = 1;

	if (ps.size() > 0)
		clausesToProcess.push_back(ps);
	else { // special case... have a unsat clause => add two conflicting clauses, TODO check if this is ok for other solvers
		addClause(mkAbstrLit(0));
		addClause(~mkAbstrLit(0));
	}
	return true;
//	return solver.addClause_(vec);
}

int ExternalSolver::newVar() {
//	solver.newVar();
	maxVar++;
	return true;
}


bool ExternalSolver::solve() {
	std::vector<AbstractLit> dummy;
	return solveLimited(dummy);
}

bool ExternalSolver::solveLimited(std::vector<AbstractLit>& assumps) {

	char buffer [L_tmpnam];
	char * pointer;

	tmpnam (buffer);
	dumpSATinstance(buffer, assumps);

	modelFound = false;
	resModel.clear();
	// TODO call external solver on dump
	executeExternalSolver(buffer);

	// TODO read

	// remove tmp file
	remove(buffer);

	return modelFound;
}

std::vector<int> ExternalSolver::model() {
	return resModel;
}

bool ExternalSolver::simplify() {
	return true;
}

bool ExternalSolver::dumpSATinstance(char *tmpfile, std::vector<AbstractLit>& assumps ) {
	std::ofstream outputFile;
	outputFile.open(tmpfile);

	int nVars = clausesToProcess.size() + assumps.size();

	outputFile << "p cnf " << maxVar << " " << nVars << std::endl;

	std::vector<std::vector<AbstractLit> >::iterator itcs = clausesToProcess.begin();
	while (itcs != clausesToProcess.end()) {
		std::vector<AbstractLit>::iterator itc = (*itcs).begin();
		while(itc != (*itcs).end()) {
			if (!(*itc).pol)
				outputFile << "-";
			int outvar = (*itc).x + 1;
			outputFile << outvar << " "; // increase of variables so that they start at 1
			itc++;
		}
		outputFile << "0" << std::endl;
		itcs++;
	}

	std::vector<AbstractLit>::iterator it = assumps.begin();
		while (it != assumps.end()) {
			if (!(*it).pol)
				outputFile << "-";
			int outvar = (*it).x + 1;
			outputFile << outvar << " 0" << std::endl; // increase of variables so that they start at 1
			it++;
		}

	outputFile.close();
	return true;
}

typedef boost::iostreams::stream<boost::iostreams::file_descriptor_source> boost_stream;


//namespace io = boost::iostreams;

bool ExternalSolver::executeExternalSolver(char *tmpfile) {
//
	FILE *in;
//	// make sure to popen and it succeeds
	std::string tmpcmd = filename;
	tmpcmd.append(" ");
	tmpcmd.append(tmpfile);
	tmpcmd.append(" | grep -v \"c\"");
	const char *cmd = (char*)tmpcmd.c_str();;

//	FILE* pipe = popen("find . -type f", "r");
//
//	    io::stream_buffer<io::file_descriptor_source> fpstream(fileno(pipe));
//	    std::istream in(&fpstream);
//
//	    std::string line;
//	    while (in)
//	    {
//	        std::getline(in, line);
//	        std::cout << line << std::endl;
//	    }



	if(!(in = popen(cmd, "r"))){
			// error handling
		}

//	int var = 0;
//	while(fscanf(in,"%d",var)>0) {
//		std::cout << "pos: " << var;
//	}

	std::vector<int> model;

	int c;
	do {
	      c = std::fgetc (in);
	      if (c == 'c') {
	    	  while (c != '\n' && c != EOF)
	    		  c = std::fgetc (in);
	    	  continue;
	      }

	      if (c == 's') {
	    	  std::fgetc (in);
	    	  c = std::fgetc (in);
	    	  if (c == 'S') {
	    		  modelFound = true;
//	    		  std::cout << "SAT";
	      	  } else if (c == 'U') {
	      		  std::fgetc (in);
	      		  c = std::fgetc (in);
	      		  if (c == 'S') {
	      			modelFound = false;
	      		  } else {
	      		  externalError = true;
	      		  modelFound = false;
	      		  }
	    	  } else {
	    		  externalError = true;
	    		  modelFound = false;
	    	  }

	    	  while (c != '\n' && c != EOF)
	    		  c = std::fgetc (in);

	    	  continue;
	      }

	      if (c == 'v') {
	    	  std::fgetc(in);
	    	  std::ostringstream var;
	    	  bool polarity = true;
	    	  while(c != EOF && c != '\n') {
	    		  c = std::fgetc(in);
	    		  if (c == '-') {
	    			  polarity = false;
	    			  continue;
	    		  }
	    		  if (isspace(c)) {
	    			  int ivar = boost::lexical_cast<int>( var.str() );
	    			  if (polarity && ivar !=0) {
	    				  model.push_back(ivar);
//	    				  resModel.push_back(abstr_l_True);
//	    				  std::cout << "pos: " << var.str();
	    			  }
	    			  else if (ivar != 0){
	    				  ivar = ivar * (-1);
//	    				  model.push_back(ivar);
//	    				  resModel.push_back(abstr_l_False);
//	    				  std::cout << "neg: " << var.str();
	    			  }
	    			  var.str("");
	    			  polarity = true;
	    			  continue;
	    		  }

//	    		  if (c == '1')
//	    			  int y = 1;
	    		  int x = c - '0';
//	    		  std::string s = boost::lexical_cast <std::string> (c);
//	    		  std::cout << s;
//	    		  std::cout << "pos: " <<  a;

	    		  var << x;
	    	  }
	      }
//	    	  continue;



//	      {
//	    	  int x = 0;
//
//
//	    	  std::fscanf(in,"$d",&x);
//	    	  while (c != '\n' && c != EOF) {
//	    		  if (c == '-') {
//	    			  while (c != '\n' && c != EOF && c != ' ')
//	    				  c = std::fgetc (in);
//	    			  continue;
//	    		  }
//	    		  std::stringstream var;
//	    		  var << c;
//	    		  while (c != '\n' && c != EOF && c != ' ') {
//	    			  c = std::fgetc (in);
//	    			  var << c;
//	    		  }
//	    		  std::cout << "pos: " << var.str() << " ";
//	    		  c = std::fgetc(in);
//	    	  }
//	      }

//	    	  skipline(in);
//	      std::cout << c;
//	      if (c )
//	      if (c == '$') n++;
	      // idea: set polarity positive
	      // if encounter - -=> negative
	      // number => var until space/newline/EOF
	    } while (c != EOF);

	std::sort(model.begin(),model.end());

	std::vector<int>::iterator iter = model.begin();


	resModel.clear();
	if (modelFound) {
		for (int i = 1;i<=maxVar;i++) {
//			int comp = *iter;
			if (iter != model.end()) {
				if (i == (*iter)) {
					resModel.push_back(abstr_l_True);
					iter++;
					continue;
				} else if ((i * (-1)) == (*iter)) {
					resModel.push_back(abstr_l_False);
					iter++;
					continue;
				}
			}
			resModel.push_back(abstr_l_False);
		}
	}

//	resModel.pop_back();
//	int z = resModel.size();

	pclose(in	);

//	std::fstream fileStream(in);


//	boost_stream stream(fileno(in));
////	stream.set_auto_close(false); // https://svn.boost.org/trac/boost/ticket/3517
//	std::string mystring;
//	while(std::getline(fileStream,mystring)) {
//		// read all lines
//			// if they start with v or s
//			// if s, then sat/unsat?
//			// if v tokenize and extract everything except trailing 0
//			// increment all vars -> assignment
//	}


//	FILE* pipe = popen(cmd, "r");
//
//	boost::iostreams::stream_buffer<boost::iostreams::file_descriptor_source> fpstream(fileno(pipe));
//	    std::istream in(&fpstream);
//
//	    std::string line;
//	    while (in)
//	    {
//	        std::getline(in, line);
//	        std::cout << line << std::endl;
//	    }



//	pclose(pipe);
	// sort if needed.
//
//	Don't forget to pclose later still.
	return true;
}

bool ExternalSolver::parseExternalSolverOutput() {
	// TODO dont forget to store model and decrease the read variables by one!
	return true;
}
