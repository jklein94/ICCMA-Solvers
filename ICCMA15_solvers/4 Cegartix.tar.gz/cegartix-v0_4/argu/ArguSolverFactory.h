/*
 * ArguSolverFactory.h
 *
 *  Created on: Apr 16, 2012
 *      Author: joh
 */

#ifndef ARGUSOLVERFACTORY_H_
#define ARGUSOLVERFACTORY_H_

#include "AbstractSolverWrapper.h"
#include "MinisatWrapper.h"
#include "ClaspWrapper.h"
#include "ExternalSolver.h"

enum ARGU_SOLVER_TYPE { MINISAT_SOLV, CLASP_SOLV, EXTERNAL_SOLV };

class ArguSolverFactory
{
public:
	AbstractSolverWrapper *getSolver();
	void setExternalSolver(std::string filename);
	ARGU_SOLVER_TYPE curOracleType;
	std::string externalSolver;
};

#endif /* ARGUSOLVERFACTORY_H_ */
