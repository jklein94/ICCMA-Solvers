/*
 * AbstractSolverWrapper.cpp
 *
 *  Created on: Apr 16, 2012
 *      Author: joh
 */

#include "MinisatWrapper.h"
#include "stdio.h"
#include "iostream"
#include "string"

// Minisat implementations

MinisatWrapper::MinisatWrapper() {
	maxVar = 0;
	externalError = false;
}

Minisat::Lit MinisatWrapper::getLit(AbstractLit p) {
//	Minisat::Lit litp = Minisat::mkLit(p.x);
	if (p.pol) {
		return Minisat::mkLit(p.x);
	} else {
		return ~Minisat::mkLit(p.x);
	}
//	return litp;
}

bool MinisatWrapper::addClause(AbstractLit p, AbstractLit q) {
//	solver.addClause(getLit(p),getLit(q));
	std::vector<AbstractLit> lits;
	lits.push_back(p);
	lits.push_back(q);
	addClause_(lits);
	return true;
}

bool MinisatWrapper::addClause(AbstractLit p) {
//	solver.addClause(getLit(p));
	std::vector<AbstractLit> lits;
	lits.push_back(p);
	addClause_(lits);
	return true;
}

bool MinisatWrapper::addClause(AbstractLit p, AbstractLit q, AbstractLit r) {
//	solver.addClause(getLit(p),getLit(q),getLit(r));
	std::vector<AbstractLit> lits;
	lits.push_back(p);
	lits.push_back(q);
	lits.push_back(r);
	addClause_(lits);
	return true;
}

bool MinisatWrapper::addClause_(std::vector<AbstractLit>& ps) {
//	Minisat::vec<Minisat::Lit> vec;
//	std::vector<AbstractLit>::iterator it = ps.begin();
//	while(it != ps.end()) {
//		vec.push(getLit(*it));
//		it++;
//	}
	// TODO: empty clauses may be problematic here... we should check for that... but only for next version
	clausesToProcess.push_back(ps);
	return true;
//	return solver.addClause_(vec);
}

int MinisatWrapper::newVar() {
//	solver.newVar();
	maxVar++;
	return true;
}

bool MinisatWrapper::solve() {
	std::vector<AbstractLit> dummy;
	return solveLimited(dummy);
//	return solver.solve();
}

bool MinisatWrapper::solveLimited(std::vector<AbstractLit>& assumps) {
	Minisat::vec<Minisat::Lit> vec;
	std::vector<AbstractLit>::iterator it = assumps.begin();
	while(it != assumps.end()) {
		vec.push(getLit(*it));
		it++;
	}
	solver = new Minisat::Solver();
	for (int m=1;m<=maxVar;m++)
		solver->newVar();

	std::vector<std::vector<AbstractLit> >::iterator itcs = clausesToProcess.begin();
	while (itcs != clausesToProcess.end()) {
		Minisat::vec<Minisat::Lit> vec;
		std::vector<AbstractLit>::iterator itc = (*itcs).begin();
		while(itc != (*itcs).end()) {
			vec.push(getLit(*itc));
			itc++;
		}
		solver->addClause_(vec);
		itcs++;
	}
	solver->simplify();
	Minisat::lbool ret = solver->solveLimited(vec);

	if (ret == l_True) {
		resModel.clear();
//		std::vector<int> model;
		for (int i=0;i<solver->model.size();i++) {
			if (solver->model[i]==l_True)
				resModel.push_back(abstr_l_True);
			else
				resModel.push_back(abstr_l_False);
		}
//		for (int i=0;i<solver->model.size();i++) {
//			if (solver->model[i] == l_True)
//				resModel.push(l_True);
//			else
//				resModel.push(l_False);
//		}
	}
	//std::cout << "Decisions: " << solver->decisions << std::endl;
	delete solver;
	if (ret == l_True)
		return true;
	else
		return false;
}

std::vector<int> MinisatWrapper::model() {
//	std::vector<int> model;
//	for (int i=0;i<resModel.size();i++) {
//	    if (resModel[i]==l_True)
//	    	model.push_back(abstr_l_True);
//	    else
//	    	model.push_back(abstr_l_False);
//	}
	return resModel;
}

bool MinisatWrapper::simplify() {
//	solver.simplify();
	return true;
}

/*Minisat::vec<Minisat::lbool> AbstractSolverWrapper::toVec(std::vector<int> vector) {
	Minisat::vec<Minisat::lbool> vec;
	std::vector<int>::iterator it = vector.begin();
	while(it != vector.end()) {
		vec.push(*it);
	}
	return vec;
}*/

/*std::vector<int> AbstractSolverWrapper::toVector(Minisat::vec<Minisat::lbool> vec) {
	//std::vector<int> vector;
	//for (int i=0;i<vec.size();i++)
	//	vector.push_back(vec[i]);
	//return vector;
	for (int i=start;i<.size();i++) {
	    if (i>max)// || i<start)
	      break;
	    if (solverModel[i]==abstr_l_True)
	      model.push_back(i);
	  }
}*/
