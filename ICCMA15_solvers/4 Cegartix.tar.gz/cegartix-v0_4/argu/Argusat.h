/*
    Project: cegartix
    File:Argusat.h
    Purpose: Holds argu data structures does the SAT-based argu computation
*/

#ifndef ARGUSAT_H
#define ARGUSAT_H

#include "stdio.h"
#include <map>
#include "string"
//#include "mtl/Vec.h"
#include "utils/Options.h"
//#include "core/Solver.h"
//#include "core/SolverTypes.h"
#include "iostream"
#include <vector>
#include <algorithm>
#include "AbstractSolverWrapper.h"
#include "ArguSolverFactory.h"
//#include <clasp/clause.h>
//#include <clasp/clasp_facade.h>

//using namespace Minisat;

// simple logging macro
#define LOGSAT(MSG) do {std::cout << MSG << std::endl;} while (0)
//#define LOG(MSG) do {std::cout << "log:" << MSG << std::endl;} while (0)
#define LOG(MSG)

class Argusat
{
public:
  // constructor
  Argusat(ArguSolverFactory *infactory);
  ~Argusat();

  std::map<std::string,int> argToId; //arg "a" -> 0
  std::map<int,std::string> idToArg; //0 -> "a"
  std::multimap<int,int> idToAttackersId;
  int maxArg; // 0,1,2,3,4,...,n=numberOfArgs, every var above is a range var.
  AbstractSolverWrapper *mainQuery; // contains main query with all learnt stuff. corresponds to phi in paper
  AbstractSolverWrapper *auxQuery; // contains an auxiliary query. Will be added/removed/changed over time.
  int semantics;
  ArguSolverFactory *factory;


  // methods for formula construction
  int solve();

  // constructs the query which only contains the AF and formulae for chosen semantics, e.g. complete does NOT contain cred/skept query.
  int constructSemanticsFormulae(AbstractSolverWrapper *solver);

  // ArgumentSetIterator. Returns the next argument set. e.g. 0,1,2,3,5 -> 0,1,2,3,6, 0,3,11 -> 0,4,5 if 11 is argmax, Assumes a correct set as input
  int nextArgumentSet(std::vector<int>& arguSet);

  // the following functions take a _sorted_ vector of args as input (this is the set S or I) and constructs a vec Lit or adds it directly to the solver

  // for F_S in algorithm
  int argsToLits_range(std::vector<int>& args, std::vector<AbstractLit> &lits);

  // for learning in the first loop
  int argsToLits_learn_range(std::vector<int>& args, AbstractSolverWrapper *solver,bool sat);

  // for psi in the second loop
  int argsToLits_aux(std::vector<int>& args, AbstractSolverWrapper *solver);

  // for phi in the second loop
  int argsToLits_learn(std::vector<int>& args, AbstractSolverWrapper *solver);

  // extracts model from the solver into a new vector, which we can sort and use otherwise.
  int extractModel(std::vector<int> solverModel, std::vector<int> &model);

  // sets limits start and max to 0,maxArg or if we learn range to maxArg+1,2*maxArg+1
  void getLimits(int &start, int &max);

  int getResult(bool result, bool cred, bool externalError);
};

#endif // ARGUSAT_H
