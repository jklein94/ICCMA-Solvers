/*
 * ClaspWrapper.h
 *
 *  Created on: Apr 17, 2012
 *      Author: joh
 */

#ifndef CLASPWRAPPER_H_
#define CLASPWRAPPER_H_

#include "AbstractSolverWrapper.h"
#include <clasp/clasp_facade.h>
#include <clasp/clause.h>
#include <clasp/literal.h>
#include <clasp/shared_context.h>
#include <stack>
#include <vector>

/*
 * Wichtig ist hier, dass vor dem
Hinzufügen von Klauseln die Funktion
SharedContext::startAddConstraints() aufgerufen werden muss.
 */

class ClaspWrapper: public AbstractSolverWrapper
{
public:
	ClaspWrapper();
	//~ClaspWrapper();
	bool addClause(AbstractLit p);
	bool addClause(AbstractLit p, AbstractLit q);
	bool addClause(AbstractLit p, AbstractLit q, AbstractLit r);
	bool addClause_(std::vector<AbstractLit>& ps);
	int newVar();
	bool solve();
	bool solveLimited(std::vector<AbstractLit>& assumps);
	std::vector<int> model();
	bool simplify();
	static Clasp::Literal getLit(AbstractLit lit);
	static char* convertInt(int number);
	Clasp::ClaspFacade *facade;
	Clasp::ClaspConfig *claspconfig;
	//std::stack<Clasp::LitVec> clausesToProcess;
	std::vector<Clasp::LitVec> clausesToProcess;
	std::vector<Clasp::Literal> assumptions;
	std::vector<int> resModel;
	bool modelFound;
	int maxVar;
};

#endif /* CLASPWRAPPER_H_ */
