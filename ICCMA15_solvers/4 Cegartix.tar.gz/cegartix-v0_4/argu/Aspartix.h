#ifndef ASPARTIX_H
#define ASPARTIX_H

#include <argu/Argusat.h>
#include "string.h"
#include "istream"
#include "iostream"
#include <boost/tokenizer.hpp>
#include <boost/algorithm/string/trim.hpp>
#include "stdio.h"
#include "Argusat.h"
//#include "MinisatWrapper.h"

// basically copy from Dimacs.h

// format: arg(X).  att(X,Y). comments: %
// n args, m atts
// we need an int n - then we see for all larger than n that it is a helper var
// for each encountered var, check if it is already in data struct, otherwise add
// for each new var S.newVar
// add it to a lits vector

// hashmap from arg string to arg int second one for backward

// hashmap which results in vector of attackers of arg int

class Aspartix
{
public:

  // parse the input file
  static int parse_ASPARTIX(std::istream* input, Argusat& argu);
  static int addArgument(Argusat &argu,std::string* arg);
  static int addAttack(Argusat &argu,int attacker,int attacked);
};

#endif // ASPARTIX_H
