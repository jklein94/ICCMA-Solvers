/*
 * MinisatWrapper.h
 *
 *  Created on: Apr 16, 2012
 *      Author: joh
 */

#ifndef MINISATWRAPPER_H_
#define MINISATWRAPPER_H_

#include <core/Solver.h>
#include "AbstractSolverWrapper.h"

//#define l_True  (Minisat::lbool((uint8_t)0))
//#define l_False (Minisat::lbool((uint8_t)1))
//#define l_Undef (Minisat::lbool((uint8_t)2))

using namespace Minisat; //fixes issue/workaround with lbool... requires this namespace.

class MinisatWrapper: public AbstractSolverWrapper
{
public:
	MinisatWrapper();
	bool addClause(AbstractLit p);
	bool addClause(AbstractLit p, AbstractLit q);
	bool addClause(AbstractLit p, AbstractLit q, AbstractLit r);
	bool addClause_(std::vector<AbstractLit>& ps);
	int newVar();
	bool solve();
	bool solveLimited(std::vector<AbstractLit>& assumps);
	std::vector<int> model();
	bool simplify();
	Minisat::Solver *solver;
	static Minisat::Lit getLit(AbstractLit lit);
	// for disabling incremental solving:
	std::vector<std::vector<AbstractLit> > clausesToProcess;
	std::vector<int> resModel;
	int maxVar;
};

#endif /* MINISATWRAPPER_H_ */
