/*
 * ArguSolverFactory.cpp
 *
 *  Created on: Apr 16, 2012
 *      Author: joh
 */
#include "ArguSolverFactory.h"

AbstractSolverWrapper *ArguSolverFactory::getSolver() {
	switch (curOracleType) {
		case MINISAT_SOLV:
			return new MinisatWrapper();
			break;
		case CLASP_SOLV:
			return new ClaspWrapper();
			break;
		case EXTERNAL_SOLV:
			return new ExternalSolver(this->externalSolver);
			break;
		default:
			return new MinisatWrapper();
			break;
	}
}

void ArguSolverFactory::setExternalSolver(std::string filename) {
	externalSolver = filename;
}
