/*
 * March_hiWrapper.h
 *
 *  Created on: Jun 1, 2012
 *      Author: joh
 */

#ifndef EXTERNALSOLVER_H_
#define EXTERNALSOLVER_H_

#include "AbstractSolverWrapper.h"
#include "stdio.h"
#include "iostream"
#include "string"
#include <sstream>
//#include <iostream>
#include <fstream>
#include "boost/iostreams/stream.hpp"
#include "boost/iostreams/device/file_descriptor.hpp"
#include "boost/lexical_cast.hpp"

class ExternalSolver: public AbstractSolverWrapper
{
public:
	ExternalSolver(std::string filename);
	//~ClaspWrapper();
	bool addClause(AbstractLit p);
	bool addClause(AbstractLit p, AbstractLit q);
	bool addClause(AbstractLit p, AbstractLit q, AbstractLit r);
	bool addClause_(std::vector<AbstractLit>& ps);
	int newVar();
	bool solve();
	bool solveLimited(std::vector<AbstractLit>& assumps);
	std::vector<int> model();
	bool simplify();
	bool dumpSATinstance(char *tmpfile, std::vector<AbstractLit>& assumps);
	bool executeExternalSolver(char *tmpfile);
	bool parseExternalSolverOutput();
	std::string filename;
	std::vector<std::vector<AbstractLit> > clausesToProcess;
//	std::vector<Clasp::Literal> assumptions;
	std::vector<int> resModel;
	bool modelFound;
	int maxVar;
};


#endif /* EXTERNALSOLVER_H_ */
