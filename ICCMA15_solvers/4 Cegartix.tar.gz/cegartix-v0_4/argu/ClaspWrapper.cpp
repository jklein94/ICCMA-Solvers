/*
 * ClaspWrapper.cpp
 *
 *  Created on: Apr 17, 2012
 *      Author: joh
 */

#include <argu/ClaspWrapper.h>
#include "stdio.h"
#include "iostream"
#include "string"
#include "sstream"

// Clasp implementations

ClaspWrapper::ClaspWrapper() {
	modelFound = false;
	maxVar = 0;
	externalError = false;
}

Clasp::Literal ClaspWrapper::getLit(AbstractLit p) {
//	Clasp::Literal litp;
//	if (p.x>260)
//		std::cout << "t";
	if (p.pol)
		return Clasp::posLit(p.x+1);
	else
		return Clasp::negLit(p.x+1);
//	return litp;
}

bool ClaspWrapper::addClause(AbstractLit p, AbstractLit q) {
	Clasp::LitVec lits;
	lits.push_back(getLit(p));
	lits.push_back(getLit(q));
	clausesToProcess.push_back(lits);
	return true;
}

bool ClaspWrapper::addClause(AbstractLit p) {
	Clasp::LitVec lits;
	lits.push_back(getLit(p));
	clausesToProcess.push_back(lits);
	return true;
}

bool ClaspWrapper::addClause(AbstractLit p, AbstractLit q, AbstractLit r) {
	Clasp::LitVec lits;
	lits.push_back(getLit(p));
	lits.push_back(getLit(q));
	lits.push_back(getLit(r));
	clausesToProcess.push_back(lits);
	return true;
}

bool ClaspWrapper::addClause_(std::vector<AbstractLit>& ps) {
	std::vector<AbstractLit>::iterator it = ps.begin();
	Clasp::LitVec lits;
	while (it != ps.end()) {
		lits.push_back(getLit(*it));
		it++;
	}
	// TODO: empty clauses may be problematic here... we should check for that... but only for next version
	clausesToProcess.push_back(lits);
	return true;
}

int ClaspWrapper::newVar() {
	maxVar++;
	return true;
}

class ArguCallback : public Clasp::ClaspFacade::Callback {
public:
	ClaspWrapper *claspwrapper;
	typedef Clasp::ClaspFacade::Event Event;
	// Called if the current configuration contains unsafe/unreasonable options
	void warning(const char* msg) {}
	// Called on entering/exiting a state
	void state(Event, Clasp::ClaspFacade&)     { }
	// Called for important events, e.g. a model has been found
	void event(const Clasp::Solver& s, Event e, Clasp::ClaspFacade& f) {
		if (e == Clasp::ClaspFacade::event_model) {
			claspwrapper->modelFound = true;
			claspwrapper->resModel.clear();
			std::vector<int> newModel;
//			s.sharedContext()->project()
			for (int i = 1;i<=claspwrapper->maxVar;i++) {
				if (s.isTrue(Clasp::posLit(i)))
					claspwrapper->resModel.push_back(i-1);
			}
//			const Clasp::SymbolTable& symTab = s.sharedContext()->symTab();
//			for (Clasp::SymbolTable::const_iterator it = symTab.begin(); it != symTab.end(); ++it) {
//				if (s.isTrue(it->second.lit)) {
//					claspwrapper->resModel.push_back(it->second.lit.var()-1);
//					//std::cout << it->second.name.c_str() << " ";
//				}
//			}
		}
	}
};

bool ClaspWrapper::solve() {
//	struct IncInput : Clasp::Input {
//		ClaspWrapper *claspwrapper;
//		bool initial;
//		IncInput() : initial(true) {}
//
//		Format format() const { return Clasp::Input::DIMACS; };
//		void addMinimize(Clasp::MinimizeBuilder&, ApiPtr) {};
//		void getAssumptions(Clasp::LitVec& assumps) {};
//
//		bool read(ApiPtr p, int){
//			Clasp::SharedContext *ctx = p.ctx;
//			Clasp::ClauseCreator cc(ctx->master());
//			if (initial) {
//				for (int v = 1; v <= claspwrapper->maxVar; ++v) {
//					ctx->addVar(Clasp::Var_t::atom_var);
//				}
//				initial = false;
//			}
//			ctx->startAddConstraints();
//			std::stack<Clasp::LitVec> *toProcess = &claspwrapper->clausesToProcess;
//			Clasp::LitVec *currentClause;
//			while (!toProcess->empty()) {
//				cc.start();
//				currentClause = &toProcess->top();
//				toProcess->pop();
//				for (Clasp::LitVec::iterator it = currentClause->begin(); it != currentClause->end(); ++it) {
//					cc.add(*it);
//				}
//				cc.end();
//			}
//			return true;
//		};
//	} problem;
//
//	// TODO: check config
//	Clasp::ClaspConfig config;
//	config.eq.noEq();
//	config.enumerate.numModels = 1;
//
//	ArguCallback cb;
//	cb.claspwrapper = this;
//	// solve normal
//	modelFound = false;
//
//	facade.solve(problem,config,&cb);
//	return modelFound;
	std::vector<AbstractLit> assumps;
	return solveLimited(assumps);
}

char* ClaspWrapper::convertInt(int number)
{
   std::stringstream ss;//create a stringstream
   ss << number;//add number to the stream
   const std::string tmp = ss.str();
   char* cstr = (char*)tmp.c_str();
   return cstr;//return a string with the contents of the stream
}

bool ClaspWrapper::solveLimited(std::vector<AbstractLit>& assumps) {
	// incremental config structure

	assumptions.clear();
	std::vector<AbstractLit>::iterator assumpsit = assumps.begin();

	while (assumpsit != assumps.end()) {
		assumptions.push_back(getLit(*assumpsit));
		assumpsit++;
	}
//	if (!assumps.empty())

	// TODO apply assumptions

	struct IncrementalConfig : public Clasp::IncrementalControl {
		IncrementalConfig() : maxSteps(static_cast<uint32>(-1)), minSteps(1), stopUnsat(false)  {}
		uint32  maxSteps;
		uint32  minSteps;
		bool    stopUnsat;
		void initStep(Clasp::ClaspFacade&) {}
		bool nextStep(Clasp::ClaspFacade& f) {
//			Clasp::ClaspFacade::Result stopRes = stopUnsat ? Clasp::ClaspFacade::result_unsat : Clasp::ClaspFacade::result_sat;
//			return --maxSteps && ((minSteps > 0 && --minSteps) || f.result() != stopRes);
			//TODO: clasp works differently with incremental solving... have to remove it
			return false;
		}
	} inc;

	struct IncInput : Clasp::Input {
		ClaspWrapper *claspwrapper;
		bool initial;
		IncInput() : initial(true) {}

		Format format() const { return Clasp::Input::DIMACS; };
		void addMinimize(Clasp::MinimizeBuilder&, ApiPtr) {};
		void getAssumptions(Clasp::LitVec& assumps) {
//				assumps.clear();
////				Clasp::SharedContext *ctx = &claspwrapper->claspconfig->ctx;
////				assumps.push_back(ctx->symTab().find(1)->lit);
//				std::vector<Clasp::Literal>::iterator it = claspwrapper->assumptions.begin();
//				while (it != claspwrapper->assumptions.end()) {
//					int x = (*it).var();
////					assumps.push_back(*it);
//					it++;
//					if (x == 258)
//						x = 258;
//				}
//				int size = assumps.size();
//				size++;
		};

		bool read(ApiPtr p, int){
			Clasp::SharedContext *ctx = p.ctx;
			Clasp::ClauseCreator cc(ctx->master());
			if (initial) {
//				ctx->symTab().startInit();
				for (int v = 1; v <= claspwrapper->maxVar; ++v) {
					Clasp::Var c = ctx->addVar(Clasp::Var_t::atom_var);
//					char *test = "v";//convertInt(v-1);
//					ctx->symTab().addUnique(c, "v").lit = Clasp::Literal(c, true);
				}
//				ctx->symTab().endInit(Clasp::SymbolTable::map_direct, claspwrapper->maxVar+1);
				initial = false;
			}
			ctx->startAddConstraints();
//			std::stack<Clasp::LitVec> *toProcess = &claspwrapper->clausesToProcess;
			std::vector<Clasp::LitVec>::iterator itv = claspwrapper->clausesToProcess.begin();
			Clasp::LitVec currentClause;
			while (itv != claspwrapper->clausesToProcess.end()) {
				cc.start();
				currentClause = *itv;
				for (Clasp::LitVec::iterator it = currentClause.begin(); it != currentClause.end(); it++) {
					cc.add(*it);
				}
				cc.simplify();
				cc.end();
//				toProcess->pop();
				itv++;
			}

			// add assumptions here
			std::vector<Clasp::Literal>::iterator ita = claspwrapper->assumptions.begin();
			while (ita != claspwrapper->assumptions.end()) {
				cc.start();
				cc.add(*ita);
				cc.simplify();
				cc.end();
				ita++;
			}
			return true;
		};
	} problem;

	// TODO: check config
	Clasp::ClaspConfig config;
	config.eq.noEq();
	config.enumerate.numModels = 1;
	claspconfig = &config;

	ArguCallback cb;
	cb.claspwrapper = this;
	problem.claspwrapper = this;
	// solve incremental
	modelFound = false;

	facade = new Clasp::ClaspFacade;
	facade->solveIncremental(problem,config,inc,&cb);
	delete facade;
	return modelFound;
}

std::vector<int> ClaspWrapper::model() {
	std::vector<int> newModel;
	std::sort(resModel.begin(),resModel.end());
	std::vector<int>::iterator resModelIt = resModel.begin();
	int comp = 0;
	if (resModelIt == resModel.end())
		comp = -1;
	else
		comp = *resModelIt;

	for (int i = 0;i<maxVar;i++) {
		if (comp == i) {
			newModel.push_back(abstr_l_True);
			comp = *(++resModelIt);
		}
		else {
			newModel.push_back(abstr_l_False);
//			comp = *(++resModelIt);
		}
	}
	return newModel;
}

// not needed for clasp
bool ClaspWrapper::simplify() {
	return true;
}

