#include "argu/Argusat.h"
//#include "simp/SimpSolver.h"

#define CNF_CF 0x01
#define CNF_ADM 0x02
#define CNF_COMP 0x04
#define CNF_RANGE_VARS 0x08
#define LEARN_RANGE 0x10
//#define LEARN_N_RANGE 0x20
//#define ALL 0x3F

//define semantics
/*
 * CNF_CF         ... adds clauses for conflict-freeness
 * CNF_ADM        ... adds remaning clauses for admissibility
 * CNF_COMP       ... adds remaining clauses for complete
 * CNF_RANGE_VARS ... adds clauses for range
 * LEARN_RANGE    ... learns range clauses instead of normal variables
 *
 */
#define SEM_PREF  CNF_CF + CNF_ADM + CNF_COMP + CNF_RANGE_VARS
#define SEM_SEMI  CNF_CF + CNF_ADM + CNF_COMP + CNF_RANGE_VARS + LEARN_RANGE
#define SEM_STAGE CNF_CF +                      CNF_RANGE_VARS + LEARN_RANGE

// depending on cred/skept change the output
#define RESULTACCEPTANCE(RESULT,CRED) (CRED) ? RESULT : !RESULT

//=================================================================================================
// Options:
static const char* _cat = "ARGU";

static Minisat::StringOption opt_arg_argument     (_cat, "argument",     "Argument for query.", "0");
static Minisat::StringOption opt_arg_semantics    (_cat, "semantics",    "Semantics: pref,semi,stage", "pref");
static Minisat::StringOption opt_arg_mode         (_cat, "mode",         "Reasoning mode: cred(olous), skept(ical), enum(eration), or first (extension found)", "skept");
static Minisat::IntOption    opt_arg_depth        (_cat, "depthArg",     "Depth of shortcuts (-1 for off, otherwise up to 2).", 1, Minisat::IntRange(-1,2));

Argusat::Argusat(ArguSolverFactory *infactory) :
    maxArg (-1) // highest ID of arguments (-1 if no args are present)
{
	factory = infactory;
}

Argusat::~Argusat()
{
	delete mainQuery;
	delete factory;
}

int Argusat::solve() {
	//Clasp::ClauseCreator nc;
	//Clasp::ProgramBuilder api;
	//api.startProgram(ctx);
	//api.setAtomName(1, "a");
	//api.Incremental
  /*
    datastructures:
    formulae (= solvers)
    basicQuery (phi init)
    mainQuery for second loop (contains all learned stuff)
    tempQuery for second loop containing cred/skept Query, and PSI

    first while loop
    array F_S contains range unit vars and is initialized with ArgumentSetIterator
    d_curr = 1 initially
    idea: generate a F_S with d_current
      with d-1,d-2,d-3,...,0
      mkLit out of these (be careful, need range vars)
      run SAT (BasicQuery + F_S + Cred/skept Query)
    after that next set is easily generated, increment first element of F_S, if at max, then increase last, if at max, incr last but one, etc...

    first if
    second if


  */
	bool externalError = false;

  // get semantics
  std::string s_semantics = (std::string)opt_arg_semantics;
  if (s_semantics.compare("pref")==0) {
    semantics = SEM_PREF;
    LOG("Semantics: Preferred");
  } else if (s_semantics.compare("semi")==0) {
    semantics = SEM_SEMI;
    LOG("Semantics: Semi-stable");
  } else if (s_semantics.compare("stage")==0) {
    semantics = SEM_STAGE;
    LOG("Semantics: Stage");
  } else {
    LOGSAT("Unknown Semantics: " << semantics);
    exit(1);
  }

  // query (reasoning mode)
  std::string queryArg = (std::string)opt_arg_argument, mode = (std::string)opt_arg_mode;
  if (mode.compare("skept")!=0 && mode.compare("cred")!=0 && mode.compare("enum")!=0 && mode.compare("first")!=0) {
    LOGSAT("ERROR: unknown reasoning mode: " << mode);
    exit(1);
  }
  if (mode.compare("cred")==0 && semantics==SEM_PREF) {
    LOGSAT("Credulous mode for preferred semantics not supported");
    exit(1);
  }

  AbstractLit queryLit;
  bool cred = false;
  
  // for skept/cred we set queryLit
  if (mode.compare("skept")==0 || mode.compare("cred")==0) {
    if(queryArg.compare("")!=0) {
      if (argToId.count(queryArg)>0) {
	if (mode.compare("skept")==0) {
	  queryLit = ~mkAbstrLit(argToId[queryArg]);
	  cred = false;
	} else {
	  queryLit = mkAbstrLit(argToId[queryArg]);
	  cred = true;
	}
      } else {
	LOGSAT("Argument for query (" << queryArg << ") is not part of AF");
	exit(1);
      }
    }
  }

  // get depth
  int depth = (int)opt_arg_depth;
  LOG("Depth: " << depth);

  LOG("Start Algorithm");
  /*
    Algorithm according to paper Wolfgang Dvorak, Matti Jaervisalo
  */

  /*
    Initialization
    Main datastructures:
    mainQuery, auxQuery of type SimpSolver
    first stores the "phi" in the paper, i.e. the main formulae. It is never removed or weakened, we only add formulae
    the second stores auxiliary queries, usually denoted by psi in the paper. auxQuery may often be removed and newly instantiated
  */

  // initialize phi, i.e. the basic formulae for semantics in the mainquery
  // note: the query for desired skept/cred argument is added here, but for all other queries the argument is given as an argument to the solver
  LOG("Initialization");
  mainQuery = factory->getSolver(); // construct mainQuery
  constructSemanticsFormulae(mainQuery);    // typical construction. the argument solver gets the basic clauses for the chosen semantics
  
  if (mode.compare("skept")==0 || mode.compare("cred")==0) {
    mainQuery->addClause(queryLit);             // add the query literal
  }
  int firstloop=0, secondloop=0, satcalls=0; // counters just for statistics

  /*
    First While Loop ("shortcuts")
  */
  LOG("First while loop");
  auxQuery = factory->getSolver();
  constructSemanticsFormulae(auxQuery);
  int currentArg = -1,curDepth=0, queryInt = argToId[queryArg];
  // complSet: complementary set, stores vars which should not be in; whiteset: stores vars which should be later taken in two-element sets
  std::vector<int> complSet, whiteSet;
  //set.push_back(0);
  std::vector<AbstractLit> f_s;
  std::vector<int>::iterator it1,it2;

  // for preferred we do a simple check
  if (semantics == SEM_PREF && depth>=0) {
    // add cnf for all attackers of queryArg
    std::multimap<int,int>::iterator it;
    std::vector<int>::iterator itL;
    std::vector<AbstractLit> lits_attackers;
    std::vector<int> attackers;
    it = idToAttackersId.find(queryInt);
    if(it != idToAttackersId.end()) {
      do {
        std::pair<int,int> att =(*it);
        lits_attackers.push_back(mkAbstrLit(att.second));
        attackers.push_back(att.second);
        it++;
      } while (it != idToAttackersId.upper_bound(queryInt));
    }
    auxQuery->addClause_(lits_attackers);
    satcalls++;
    if (auxQuery->solve()) {
      externalError = auxQuery->externalError;
      delete auxQuery;
      LOGSAT("terminated in first (1) loop");
      LOGSAT("SAT calls: " << satcalls << " first loop: " << firstloop << " second loop: " << secondloop);
      return getResult(true,cred,externalError);
    } else {
      // learn
	  if (auxQuery->externalError) {
		delete auxQuery;
		return getResult(false,false,true);
      }
      itL = attackers.begin();
      while (itL != attackers.end()) {
        mainQuery->addClause(~mkAbstrLit(*itL));
        itL++;
      }
    }
  } else { // for semi and stage we do a more sophisticated check
    while (curDepth <= depth) {
      firstloop++;
      f_s.clear();
      argsToLits_range(complSet,f_s);
      f_s.push_back(queryLit);
      auxQuery->simplify();

      // check
      satcalls++;
      if (auxQuery->solveLimited(f_s) == true) {
        // accept
    	externalError = auxQuery->externalError;
        delete auxQuery;
        LOGSAT("terminated in first (1) loop");
        LOGSAT("SAT calls: " << satcalls << " first loop: " << firstloop << " second loop: " << secondloop);
        return getResult(true,cred,externalError);;
      } else {
    	if (auxQuery->externalError) {
    	  delete auxQuery;
    	  return getResult(false,false,true);
    	}
        // learn and update set

        // learn
        f_s.clear();
        argsToLits_range(complSet,f_s);
        auxQuery->simplify();

        satcalls++;
        if (auxQuery->solveLimited(f_s) == true) {

          // learn TRUE
          argsToLits_learn_range(complSet,mainQuery,true);
          if (currentArg==-1) {
        	externalError = auxQuery->externalError;
            LOGSAT("terminated in first (1) loop");
            LOGSAT("SAT calls: " << satcalls << " first loop: " << firstloop << " second loop: " << secondloop);
            return getResult(false,cred,externalError);
          }
        } else {
          // learn FALSE
          argsToLits_learn_range(complSet,mainQuery,false);
          if (currentArg >=0 && currentArg <=maxArg)
            whiteSet.push_back(currentArg);
        }
        if (auxQuery->externalError) {
          delete auxQuery;
          return getResult(false,false,true);
        }
      }

      // next set
      // all one - element sets
      if (currentArg < maxArg) {
        currentArg++;
        complSet.clear();
        complSet.push_back(currentArg);
        if (curDepth==0)
          curDepth++;
      } else {
        if (currentArg == maxArg) { // TODO was just "=" before... i.e. was only executed at most twice... could have some effects..
          // init
          currentArg = maxArg+1;
          it1 = whiteSet.begin();
          it2 = whiteSet.begin();
          curDepth++;
          if (it1 == whiteSet.end())
            break;
        }

        if (++it2 == whiteSet.end()) {
          if (++it1 == whiteSet.end())
            break;
        }

        complSet.clear();
        complSet.push_back(*it1);
        complSet.push_back(*it2);

        // do the iterator thing

      }

      /*if (auxQuery->solveLimited(dummy2) == l_True) {
        // accept
        delete auxQuery;
        LOGSAT("accept in first loop");
        return l_True;
      } else {
        // learn and update set

        // learn
        f_s.clear();
        argsToLits_range(set,f_s);
        //auxQuery->simplify();
        delete auxQuery;
        auxQuery = new SimpSolver;
        constructSemanticsFormulae(auxQuery);
        // test: dont use assumps
        for (int k=0;k<=f_s.size()-1;k++)
          auxQuery->addClause(f_s[k]);

        if ((semantics==SEM_PREF) || (auxQuery->solveLimited(dummy2) == l_True)) { // TODO add for preferred no check necessary
          // learn TRUE
          argsToLits_learn_range(set,mainQuery,true);
        } else {
          // learn FALSE
          argsToLits_learn_range(set,mainQuery,false);
        }

        if (nextArgumentSet(set)==0) {
          curDepth++;
          if (curDepth>depth) break;
          set.clear();
          for (int i=0;i<=curDepth-1;i++)
            set.push_back(i);
        }
      }
    }*/
    }
  }

  /*
    Second While Loop
  */
  LOG("Second while loop");

  std::vector<AbstractLit> dummy, vecQuery; // vecQuery contains only the argument for cred/skept acceptance
  
  if (mode.compare("skept")==0 || mode.compare("cred")==0) {
    vecQuery.push_back(queryLit);
  }
  
 
  std::vector<int> model;

  while (mainQuery->solveLimited(dummy) == true) {
	if (mainQuery->externalError) {
		return getResult(false,false,true);
	}
    satcalls++;
    secondloop++;
    // init aux Query
    LOG("Init auxQuery");
    delete auxQuery;
    auxQuery = factory->getSolver();
    constructSemanticsFormulae(auxQuery);

    // extract model
    LOG("Extraxt model from mainQuery");
    model.clear();
    extractModel(mainQuery->model(), model);

    // sort
    LOG("Sort model");
    std::sort(model.begin(),model.end());

    // construct rest of psi formula
    LOG("Add remaining formulae to auxQuery");
    argsToLits_aux(model,auxQuery);

    // inner while loop
    LOG("Inner while loop start");
    satcalls++;

    auxQuery->simplify();
    while (auxQuery->solveLimited(vecQuery) == true) {
    //while (auxQuery->solve()== true) {
      // update model
      if (auxQuery->externalError) {
    	  delete auxQuery;
    	  return getResult(false,false,true);
      }
      LOG("Update Model");
      model.clear();
      extractModel(auxQuery->model(), model);
      std::sort(model.begin(),model.end());

      // add to auxQuery
      LOG("Add to auxQuery");
      auxQuery->simplify();
      argsToLits_aux(model,auxQuery);
      auxQuery->simplify();
    }

    if (auxQuery->externalError) {
    	delete auxQuery;
  	  return getResult(false,false,true);
    }
    // auxQuery with cred/skept argument is unsat
    delete auxQuery;
    auxQuery = factory->getSolver();
    constructSemanticsFormulae(auxQuery);
    argsToLits_aux(model,auxQuery);

    // first and enum modes
    if (mode.compare("first")==0) {
       std::cout << "[";
       
       for (int i=0;i<model.size();i++) {
	  if (model[i]>maxArg)
	    continue;
	  std::cout << idToArg[model[i]];
	  std::cout << ",";
       }
       std::cout << "]" << std::endl;
       
       return getResult(false,false,externalError);
    } else if (mode.compare("enum")==0) {
      
      if (auxQuery->externalError) {
    	  delete auxQuery;
    	return getResult(false,false,true);
      }
      // learn from model
      //model.clear();
      //extractModel(auxQuery->model(), model);
      std::cout << "[";
      for (int i=0;i<model.size();i++) {
	  if (model[i]>maxArg)
	    continue;
	  std::cout << idToArg[model[i]];
	  std::cout << ",";
       }
      std::cout << "]";
      
      std::sort(model.begin(),model.end());
      // learn
      argsToLits_learn(model,mainQuery);
      continue;
    }
    
    // check if psi is unsat
    satcalls++;
    if (auxQuery->solveLimited(dummy) == false) {
      LOGSAT("terminated in second (2) loop");
      externalError = auxQuery->externalError;
      delete auxQuery;
      LOGSAT("SAT calls: " << satcalls << " first loop: " << firstloop << " second loop: " << secondloop);
      return getResult(true,cred,externalError);;
    } else {
      if (auxQuery->externalError) {
    	  delete auxQuery;
    	return getResult(false,false,true);
      }
      // learn from model
      model.clear();
      extractModel(auxQuery->model(), model);
      std::sort(model.begin(),model.end());
      // learn
      argsToLits_learn(model,mainQuery);
    }

  }
  externalError = mainQuery->externalError;
  // no success, we reject
  LOGSAT("terminated in second (2) loop");
  if (secondloop == 0) {satcalls++;} // if we do not enter second loop, then we had at least one additional satcall
  LOGSAT("SAT calls: " << satcalls << " first loop: " << firstloop << " second loop: " << secondloop);
  delete auxQuery;
  return getResult(false,cred,externalError);;

  /*
  // preliminary second while loop of algo
  lbool ret = solver->solveLimited(dummy);
  while(ret) { // while phi is SAT

    // extract model I of phi and construct psi^Ivv
    for (int arg = 0;arg<=maxArg;arg++) {
      // copy solver model into an array and sort, then for each arg, do the SEM- psi^I
    }

    // while psi^I and q is sat
    // find a model I2
    // update I with I2

    // if psi^I is unsat (without q) then learnv
  } */
}

int Argusat::constructSemanticsFormulae(AbstractSolverWrapper *solver) {
  std::vector<AbstractLit> lits_adm, lits_range_attackers, lits_comp;
  std::multimap<int,int>::iterator it,itAdm;
  //int sem =0;

  // declare variables for solver, for now just here, more efficient would be below when we actually add them to the cnf
  for (int arg = 0;arg<=(2*maxArg)+1;arg++) solver->newVar();

  // for each argument
  for (int arg = 0;arg<=maxArg;arg++) {

    // range: add arg var and its range var, and add directly -xa v xa'
    lits_range_attackers.clear();
    lits_range_attackers.push_back(mkAbstrLit(arg));
    lits_range_attackers.push_back(~mkAbstrLit(arg+maxArg+1)); // range var
    if (semantics & CNF_RANGE_VARS) solver->addClause(~mkAbstrLit(arg),mkAbstrLit(arg+maxArg+1)); // also -xa v xa'

    // complete
    lits_comp.clear();
    lits_comp.push_back(mkAbstrLit(arg+maxArg+1));

    // for each attacker of arg
    it = idToAttackersId.find(arg);
    if(it != idToAttackersId.end()) {
      do {
        std::pair<int,int> att =(*it);

        // conflict -free: for each attacker (i.e. each attack) add clause -a v -b
        AbstractLit attacked = ~mkAbstrLit(att.first);
        AbstractLit attacker = ~mkAbstrLit(att.second);
        if (semantics & CNF_CF) solver->addClause(attacked,attacker);

        // complete
        lits_comp.push_back(~mkAbstrLit(att.second+maxArg+1));

        // range
        lits_range_attackers.push_back(mkAbstrLit(att.second));
        if (semantics & CNF_RANGE_VARS) solver->addClause(~mkAbstrLit(att.second),mkAbstrLit(arg+maxArg+1));

        // admissibility
        lits_adm.clear();
        lits_adm.push_back(~mkAbstrLit(att.first));
        itAdm = idToAttackersId.find((*it).second);
        if(itAdm != idToAttackersId.end()) {
          do {
            AbstractLit defender = mkAbstrLit((*itAdm).second);
            lits_adm.push_back(defender);
            itAdm++;
          } while (itAdm != idToAttackersId.upper_bound((*it).second));
        }
        if (semantics & CNF_ADM) solver->addClause_(lits_adm);
        it++;
      } while (it != idToAttackersId.upper_bound(arg));
    }

    // range: add clause
    if (semantics & CNF_RANGE_VARS) solver->addClause_(lits_range_attackers);

    // complete
    if (semantics & CNF_COMP) solver->addClause_(lits_comp);
  }

  return 0;
}

int Argusat::nextArgumentSet(std::vector<int> &arguSet) {

  int j = 0;
  // from last to first
  for (int i=arguSet.size()-1;i>=0;i--) {

    // if we have reached the max-j
    if (arguSet[i] == maxArg - j) {
      // go to next
      j++;
      // else we found the first element to increase
    } else {
      // set values starting from i to arguSet.size()-1 to content of i, i+1, i+2 ...
      j=arguSet[i]+1;
      for (int t=i;t<=arguSet.size()-1;t++) {
        arguSet[t]=j;
        j++;
      }
      return 1;
    }
  }

  return 0;
}

int Argusat::argsToLits_aux(std::vector<int> &args, AbstractSolverWrapper *solver) {
  std::vector<int>::iterator it;
  it = args.begin();
  int comp = -1; // comparison variable if i equal to this then contained in model
  if (it != args.end())
    comp = *it;

  std::vector<AbstractLit> disjunctiveClause;
  // for each argument
  int start=0,max=0;
  // for LEARN_RANGE we just look at range variables
  getLimits(start,max);
  for (int i=start;i<=max;i++) {
    if (comp == i) {
      // i is in model
      solver->addClause(mkAbstrLit(i));
      it++;
      if (it != args.end())
        comp = *it;
    } else {
      // i is not in model
      AbstractLit add = mkAbstrLit(i);
      disjunctiveClause.push_back(add);
    }
  }
  solver->addClause_(disjunctiveClause);
  return 0;
}

int Argusat::argsToLits_learn(std::vector<int> &args, AbstractSolverWrapper *solver) {
  std::vector<int>::iterator it;
  it = args.begin();
  int comp = -1; // comparison variable if i equal to this then contained in model
  if (it != args.end())
    comp = *it;

  std::vector<AbstractLit> disjunctiveClause;
  // for each argument

  int start=0,max=0;
  // for LEARN_RANGE we just look at range variables
  getLimits(start,max);

  for (int i=start;i<=max;i++) {
    if (comp == i) {
      // i is in model
      it++;
      if (it != args.end())
        comp = *it;
    } else {
      // i is not in model
      disjunctiveClause.push_back(mkAbstrLit(i));
    }
  }
  solver->addClause_(disjunctiveClause);
  return 0;
}

int Argusat::argsToLits_learn_range(std::vector<int> &args, AbstractSolverWrapper *solver,bool sat) {
  std::vector<int>::iterator it;
  it = args.begin();
  int comp = -1; // comparison variable if i equal to this then contained in model
  if (it != args.end())
    comp = *it;

  int start=0,max=maxArg;
  std::vector<AbstractLit> disjunctiveClause;

  for (int i=start;i<=max;i++) {
    if (comp != i) {
      // i is not in model
      if (!sat) {disjunctiveClause.push_back(~mkAbstrLit(i+maxArg+1));}
    } else {
      // i is in model
      disjunctiveClause.push_back(mkAbstrLit(i+maxArg+1));
      it++;
      if (it != args.end())
        comp = *it;
    }
  }
  solver->addClause_(disjunctiveClause);

  return 0;
}

int Argusat::argsToLits_range(std::vector<int> &args, std::vector<AbstractLit> &lits){
  int start=0,max=maxArg;
  std::vector<int>::iterator it;
  it = args.begin();
  int comp = -1; // comparison variable if i equal to this then contained in model
  if (it != args.end())
    comp = *it;

  for (int i=start;i<=max;i++) {
    if (comp != i) {
      // i is not in model
      lits.push_back(mkAbstrLit(i+maxArg+1));
    } else {
      // i is in model
      lits.push_back(~mkAbstrLit(i+maxArg+1));
      it++;
      if (it != args.end())
        comp = *it;
    }
  }
  return 0;
}

int Argusat::extractModel(std::vector<int> solverModel, std::vector<int> &model) {
  int start=0,max=0;
  // for LEARN_RANGE we just look at range variables
  getLimits(start,max);

  for (int i=start;i<solverModel.size();i++) {
    if (i>max)// || i<start)
      break;
    if (solverModel[i]==abstr_l_True)
      model.push_back(i);
  }

  return 0;
}

void Argusat::getLimits(int &start, int &max) {
  if (semantics & LEARN_RANGE) {
    start = maxArg+1;
    max = maxArg*2+1;
  } else { // learn only arg variables, no range vars
    start = 0;
    max = maxArg;
  }
  return;
}

int Argusat::getResult(bool result, bool cred, bool externalError) {
	if (externalError) {
		return -1;
	} else {
		return RESULTACCEPTANCE(result,cred);
	}
}
