-- | This module re-exports the implicit command line parser.

module System.Console.CmdArgs(module System.Console.CmdArgs.Implicit) where

import System.Console.CmdArgs.Implicit
