A command line application written on top of the Dung library satisfying the 
ICCMA guidelines.