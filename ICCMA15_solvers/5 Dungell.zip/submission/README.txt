------ Installation and usage instructions ------
1. Install GHC 7.8.4 or newer (this should include cabal 1.18 needed for the cabal sandboxing) 
2. Run make or compile.bat dependent on OS to build the executable. 
3. The executable should appear in this folder. Otherwise you can find it in /dist/build/dungell_iccma/ as dungell_iccma.exe or dungell_iccma (or alternatively in .cabal-sandbox\bin)
4. Run the executable using the probo standard command-line arguments.