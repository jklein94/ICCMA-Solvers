#!/bin/bash
java -jar $(dirname $0)/LamatzSolver-v0.1.jar $*