/**
 * @file 		StableSemantics.h
 * @author 		Federico Cerutti <federico.cerutti@acm.org>
 * @copyright	MIT
 */

#ifndef STABLESEMANTICS_H_
#define STABLESEMANTICS_H_

#include "CompleteSemantics.h"

class StableSemantics: public CompleteSemantics
{
	typedef CompleteSemantics super;
public:
	bool compute(Argument *arg = NULL, bool firstonly = false);
	bool credulousAcceptance(Argument *arg);
	bool skepticalAcceptance(Argument *arg);
	SetArguments *someExtension();
	/**
	 * @see CompleteSemantics#CompleteSemantics
	 */
	StableSemantics(AF *the_af, Encoding enc) :
			super(the_af, enc)
	{
		for (SetArgumentsIterator arg = this->af->begin(); arg != this->af->end(); arg++)
					this->sat_pigreek.appendOrClause(OrClause(1, (*arg)->NotUndecVar()));
	}
	;

	virtual ~StableSemantics();
};

#endif /* STABLESEMANTICS_H_ */
