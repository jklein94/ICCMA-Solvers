/**
 * @file 		CompleteSemantics.h
 * @author 		Federico Cerutti <federico.cerutti@acm.org>
 * @copyright	MIT
 */


#ifndef COMPLETESEMANTICS_H_
#define COMPLETESEMANTICS_H_

#include "Semantics.h"

class CompleteSemantics: public Semantics
{
	typedef Semantics super;
protected:
	void add_non_emptiness();
	void add_some_undec();
public:
	/**
	 * @see Semantics#Semantics
	 */
	CompleteSemantics(AF *the_af, Encoding enc) :
			super(the_af, enc)
	{
	}
	;
	bool credulousAcceptance(Argument *arg);
	bool skepticalAcceptance(Argument *arg);
	virtual ~CompleteSemantics();
	bool compute(Argument *arg = NULL, bool firstonly=false);
	SetArguments *someExtension();
};

#endif /* COMPLETESEMANTICS_H_ */
