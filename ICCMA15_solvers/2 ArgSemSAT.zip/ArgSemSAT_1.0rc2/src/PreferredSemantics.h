/**
 * @file 		PreferredSemantics.h
 * @author 		Federico Cerutti <federico.cerutti@acm.org>
 * @copyright	MIT
 */

#ifndef PREFERREDSEMANTICS_H_
#define PREFERREDSEMANTICS_H_

#include "CompleteSemantics.h"

class PreferredSemantics: public CompleteSemantics
{
	typedef CompleteSemantics super;
public:
	PreferredSemantics(AF *the_af, Encoding enc);
	virtual ~PreferredSemantics();
	bool compute(Argument *arg = NULL, bool firstonly = false);
	bool credulousAcceptance(Argument *arg);
	bool skepticalAcceptance(Argument *arg);
	SetArguments *someExtension();

};

#endif /* PREFERREDSEMANTICS_H_ */
