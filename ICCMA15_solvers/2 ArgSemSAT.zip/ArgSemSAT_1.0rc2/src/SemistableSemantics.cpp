/**
 * @file 		SemistableSemantics.cpp
 * @class 		SemistableSemantics
 * @brief 		Class for the semi stable semantics
 * @author 		Federico Cerutti <federico.cerutti@acm.org>
 * @copyright	MIT
 */

#include "SemistableSemantics.h"

/**
 * @brief Computing semantics extensions
 */
void SemistableSemantics::compute()
{
	super::compute();
	vector<Labelling>::iterator it;
	bool erased = false;
	do
	{
		erased = false;

		for (it = this->labellings.begin(); it != this->labellings.end();it++)
		{
			vector<Labelling>::iterator inner;
			for (inner = this->labellings.begin(); inner != this->labellings.end(); inner++)
			{
				if (inner == it)
					continue;

				if ((*it).undecargs()->is_subset((*inner).undecargs()))
				{
					this->labellings.erase(inner);
					erased = true;
					break;
				}
			}
			if (erased)
				break;
		}
	} while (erased);
}


SemistableSemantics::~SemistableSemantics()
{
	// TODO Auto-generated destructor stub
}

