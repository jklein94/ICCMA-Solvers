/**
 * @file 		misc.cpp
 * @brief 		Miscellanea functions
 * @author 		Federico Cerutti <federico.cerutti@acm.org>
 * @copyright	MIT
 */

#include "argsemsat.h"
#include <sys/stat.h>

/**
 * @brief 				Function checking the existence of a file
 * @param[in] filename	Pointer to a `const char` containing the name of the file
 * @retval bool
 */
bool fexists(const char *filename)
{
	struct stat buffer;
	return (stat(filename, &buffer) == 0);
}

void printArray(const string arr[], int dim)
{
	int i = 0;
	cout << "[";
	for (i = 0; i < dim; i++)
	{
		cout << arr[i];
		if (i != dim - 1)
			cout << ",";
	}
	cout << "]" << endl;
}

bool isInArray(string el, const string arr[], int dim)
{
	int i = 0;
	for (i = 0; i < dim; i++)
	{
		if (arr[i].compare(el) == 0)
			return true;
	}
	return false;
}

/**
 * @brief				Function for parsing the parameters
 * @details				This function does not return any value. It fills global variables according to
 * 						the received parameters.
 * @param[in] argc		`int` containing the numbers of parameters
 * @param[in] argv		List of parameters
 * @retval int			  0: everything is fine
 * 						 10: exit the program
 * 						-10: error
 * 						-20: unable to perform the desired query
 */
int parseParams(int argc, char *argv[])
{
	//default
	satsolver = string(path) + "/" + defaultsolver;
	if (argc == 1)
	{
		authorInfo(hgrev);
		return PARSE_EXIT;
	}

	for (int k = 1; k < argc; k++)
	{
		if (string("-d").compare(argv[k]) == 0)
			debug = true;
		else if (string("--formats").compare(argv[k]) == 0)
		{
			printArray(acceptedformats, NUM_FORMATS);
			return PARSE_EXIT;
		}
		else if (string("--problems").compare(argv[k]) == 0)
		{
			printArray(acceptedproblems, NUM_PROBLEMS);
			return PARSE_EXIT;
		}
		else if (string("--help").compare(argv[k]) == 0)
		{
			showHelp(hgrev);
			return PARSE_EXIT;
		}
		else if (string("-f").compare(argv[k]) == 0)
		{
			inputfile = string(argv[++k]);
		}
		else if (string("-a").compare(argv[k]) == 0)
		{
			argumentDecision = string(argv[++k]);
		}
		else if (string("-fo").compare(argv[k]) == 0)
		{
			if (!isInArray(string(argv[++k]), acceptedformats, NUM_FORMATS))
			{
				return PARSE_UNABLE;
			}
		}
		else if (string("-p").compare(argv[k]) == 0)
		{
			string p = string(argv[++k]);
			if (!isInArray(p, acceptedproblems, NUM_PROBLEMS))
			{
				return PARSE_UNABLE;
			}

			size_t dash = p.find("-");
			if (dash == string::npos)
			{
				return PARSE_ERROR;
			}
			problem = p.substr(0, dash);
			semantics = p.substr(dash + 1);
		}
		else if (string("--ExtEnc").compare(argv[k]) == 0)
		{
			try
			{
				global_enc = Encoding(string(argv[++k]));
			} catch (exception &e)
			{
				cout << e.what() << endl;
				return PARSE_ERROR;
			}
		}
		else if (string("--sat").compare(argv[k]) == 0)
		{
			satsolver = string(argv[++k]);
		}
		else
		{
			cout << "Unrecognised parameter: " << argv[k] << endl;
			return PARSE_ERROR;
		}
	}
	return true;
}

void authorInfo(const char *rev)
{
	cout << "ArgSemSAT " << rev << endl;
	cout << "Federico Cerutti <federico.cerutti@acm.org>" << endl;
	cout << "Mauro Vallati <mauro.vallati@hud.ac.uk>" << endl;
	cout << "Massimiliano Giacomin <massimiliano.giacomin@unibs.it>" << endl;

}

/**
 * @brief			Function for printing on screen a disclaimer and a brief help
 * @param[in] rev	The version of this software
 * @retval	void
 */
void showHelp(const char *rev)
{
	cout << rev << endl;

	cout
			<< "ArgSemSAT Copyright (C) 2012-2015" << endl
			<< "Federico Cerutti <federico.cerutti@org>" << endl
			<< "Mauro Vallati <m.vallati@hud.ac.uk>" << endl
			<< "Massimiliano Giacomin <massimiliano.giacomin@unibs.it>" << endl
			<< endl;
	cout << "This program comes with ABSOLUTELY NO WARRANTY" << endl;
	cout << "This is free software, under the MIT license" << endl;

	cout << "#### Running" << endl;
	cout << "./ArgSemSAT <param1> ... <paramN>" << endl;
	cout << "--help\t\t\t this help" << endl;
	cout << "-d \t\t\t *HIGH* level of debug (very slow, very dense output)"
			<< endl;
	cout << "-f <filename>\t\t input file name for a problem" << endl;
	cout << "-fo <format>\t\t format of the input file" << endl;
	cout << "-p <problem>\t\t problem to be solved" << endl;
	cout << "-a <additional>\t\t argument to check the acceptance" << endl;
	cout << "--formats\t\t list of supported file types" << endl;
	cout << "--problems\t\t list of supported problems" << endl;
	cout
			<< "--ExtEnc <CIr><CIl><COr><COl><CUr><CUl> sequence of 6 booleans without spaces: by default 101010"
			<< endl;
	cout << "--sat\t\t\t SAT solver full path: by default " << path << "/"
			<< defaultsolver << endl;

	return;
}

bool parse_solution_aspartix(set<set<string> > *preferred, const char *file)
{
	ifstream infile;
	infile.open(file);
	if (infile.good() == false)
		return false;

	string inLine;
	while (getline(infile, inLine))
	{
		int start = 0;
		int pos = 0;
		set<string> sol_asp = set<string>();

		while (((int) (pos = inLine.find("in(", start))) != ((int) string::npos))
		{
			string arg = inLine.substr(pos + 3,
					inLine.find(")", pos + 3) - (pos + 3));
			sol_asp.insert(arg);
			start = pos + 4;
		}
		(*preferred).insert(sol_asp);
	}
	set<set<string> >::iterator it;
	for (it = preferred->begin(); it != preferred->end(); it++)
	{
		set<string>::iterator inner;
		cout << "{";
		for (inner = (*it).begin(); inner != (*it).end(); inner++)
		{
			cout << (*inner) << " ";
		}
		cout << "}" << endl;
	}
	return true;
}
