/**
 * @file 		argsemsat.h
 * @author 		Federico Cerutti <federico.cerutti@acm.org>
 * @copyright	MIT
 */

#ifndef _ArgSemSAT_H
#define	_ArgSemSAT_H

#include <cmath>
#include <cstdio>
#include <fstream>
#include <cstdlib>
#include <stdlib.h>
#include <vector>
#include <array>
#include <time.h>

#include <algorithm>
#include <iostream>
#include <sstream>
#include <cstring>
#include <string>
#include <cassert>
#include <set>

#define DIMBUFFER 100000

using namespace std;

#define HG(a) static const char *hgrev = a;

#define PUBLIC_RELEASE "1.0rc2"
#ifndef PUBLIC_RELEASE
#include "hgversion.h"
#else
#define HG(a) static const char *hgrev = a;
HG("Version: " PUBLIC_RELEASE);
#endif

#include "AF.h"
#include "OrClause.h"
#include "SATFormulae.h"
#include "SetArguments.h"
#include "Labelling.h"
#include "Semantics.h"
#include "CompleteSemantics.h"
#include "PreferredSemantics.h"
#include "GroundedSemantics.h"
#include "StableSemantics.h"
#include "SemistableSemantics.h"
#include "Encoding.h"

extern bool debug;
extern bool externalsat;
extern string satsolver;
extern string inputfile;
extern string semantics;
extern string problem;
extern Encoding global_enc;
extern string defaultsolver;
extern string path;
extern string argumentDecision;

//const string precosat = "PRECOSAT";
//const string glucose = "GLUCOSE";

const string complete_string_const = "CO";
const string preferred_string_const = "PR";
//const string preferred_df_string_const = "preferred-df";
const string grounded_string_const = "GR";
//const string grounded_poly_string_const = "grounded-poly";
const string stable_string_const = "ST";
//const string semistable_string_const = "semistable";


const string credulous = "DC";
const string skeptical = "DS";
const string enumerateall = "EE";
const string enumeratesome = "SE";

const string acceptedformats [] = {"apx"};
#define NUM_FORMATS 1
const string acceptedproblems [] = {"DC-CO",
									"DC-GR",
									"DC-PR",
									"DC-ST",
									"DS-CO",
									"DS-GR",
									"DS-PR",
									"DS-ST",
									"EE-CO",
									"EE-GR",
									"EE-PR",
									"EE-ST",
									"SE-CO",
									"SE-GR",
									"SE-PR",
									"SE-ST"
									};
#define NUM_PROBLEMS 16

#define PARSE_CONTINUE 0
#define PARSE_EXIT 10
#define PARSE_ERROR -10
#define PARSE_UNABLE -20

//extern int (*SatSolver)(stringstream *, int, int, vector<int> *);

extern bool manualopt;
extern time_t start;

bool parse_solution_aspartix(set<set<string> > *, const char *);

int
parseParams(int argc, char *argv[]);

void showHelp(const char *);
void authorInfo(const char *);
void printArray(const string [], int dim);
bool isInArray(string, const string[], int);

#endif	/* _ArgSemSAT_H */

int precosat_lib(stringstream *the_cnf, int num_var, int num_cl, vector<int> *result);

int glucose_lib(stringstream *the_cnf, int num_var, int num_cl, vector<int> *result);
