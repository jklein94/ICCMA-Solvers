/**
 * @file 		StableSemantics.cpp
 * @class 		StableSemantics
 * @brief 		Class for the stable semantics
 * @author 		Federico Cerutti <federico.cerutti@acm.org>
 * @copyright	MIT
 */

#include "StableSemantics.h"

/**
 * @brief Computing semantics extensions
 */
bool StableSemantics::compute(Argument *arg, bool firstonly)
{
	return super::compute(arg, firstonly);
	//if (this->labellings.size() == 1 && this->labellings.at(0).inargs()->empty() && this->af->numArgs() != 0)
	//	this->labellings.clear();
}

bool StableSemantics::credulousAcceptance(Argument *arg)
{
	return super::credulousAcceptance(arg);
}

bool StableSemantics::skepticalAcceptance(Argument *arg)
{
	this->cleanlabs();
	SATFormulae compute = SATFormulae(3 * this->af->numArgs());
	this->sat_pigreek.clone(&compute);

	compute.appendOrClause(OrClause(1, arg->OutVar()));

	Labelling res = Labelling();
	if (this->satlab(compute, &res, false))
		return false;

	compute = SATFormulae(3 * this->af->numArgs());
	this->sat_pigreek.clone(&compute);

	res = Labelling();
	return this->satlab(compute, &res, false);

}

SetArguments *StableSemantics::someExtension()
{
	SetArguments *ret = super::someExtension();
	if (ret == NULL || (ret->empty() && this->af->numArgs() != 0))
		return NULL;
	else
		return ret;
}

StableSemantics::~StableSemantics()
{
	// TODO Auto-generated destructor stub
}

