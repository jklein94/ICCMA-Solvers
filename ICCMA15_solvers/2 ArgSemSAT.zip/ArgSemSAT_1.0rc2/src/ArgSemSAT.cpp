/**
 * @file 		ArgSemSAT.cpp
 * @brief 		Main file
 * @author 		Federico Cerutti <federico.cerutti@acm.org> and
 * 				Mauro Vallati <m.vallati@hud.ac.uk>
 * @copyright	MIT
 */

#include "argsemsat.h"
#include <unistd.h>
#include <libgen.h>

/**
 * @brief Configuration variables
 */
bool debug = false;
bool externalsat = true;
string satsolver = "";
string defaultsolver = "satsolver -model";
bool manualopt = false;
string inputfile;
string semantics;
string problem;
Encoding global_enc("101010");
string path;
string argumentDecision;

int (*SatSolver)(stringstream *, int, int, vector<int> *) = NULL;

time_t start;

#ifndef UNIT_TEST

void printbooleanprobo(bool res)
{
	if (res)
		cout << "YES" << endl;
	else
		cout << "NO" << endl;
}

/**
 * @brief 	Main
 * @retval int	The return value can be:
 * 				* `-127`: Missing parameters
 * 				* `-1`: Unable to parse the AF file
 * 				* `-126`: Something goes wrong
 * 				* `-125`: Wrong SAT Solver
 * 				* `0`: SUCCESS!!!
 *
 */
int main(int argc, char *argv[])
{
	char buf[2048];
	readlink("/proc/self/exe", buf, 2047);
	path = string(dirname(buf));

	time(&start);

	int p = parseParams(argc, argv);

	if (p == PARSE_EXIT)
	{
		return 0;
	}
	if (p == PARSE_ERROR || p == PARSE_UNABLE)
	{
		showHelp(hgrev);
		return -127;
	}

	AF framework = AF();
	if (!framework.readFile(inputfile))
	{
		showHelp(hgrev);
		return -1;
	}

	if (semantics.compare(complete_string_const) == 0)
	{
		CompleteSemantics comp = CompleteSemantics(&framework, global_enc);
		if (problem.compare(enumerateall) == 0)
		{
			comp.compute();
			cout << comp << endl;
		}
		else if (problem.compare(credulous) == 0)
		{
			printbooleanprobo(
					comp.credulousAcceptance(
							framework.getArgumentByName(argumentDecision)));
		}
		else if (problem.compare(skeptical) == 0)
		{
			printbooleanprobo(
					comp.skepticalAcceptance(
							framework.getArgumentByName(argumentDecision)));
		}
		else if (problem.compare(enumeratesome) == 0)
		{
			cout << (*(comp.someExtension())) << endl;
		}

	}
	else if (semantics.compare(preferred_string_const) == 0)
	{
		PreferredSemantics pref = PreferredSemantics(&framework, global_enc);
		if (problem.compare(enumerateall) == 0)
		{
			pref.compute();
			cout << pref << endl;
		}
		else if (problem.compare(credulous) == 0)
		{
			printbooleanprobo(
					pref.credulousAcceptance(
							framework.getArgumentByName(argumentDecision)));
		}
		else if (problem.compare(skeptical) == 0)
		{
			printbooleanprobo(
					pref.skepticalAcceptance(
							framework.getArgumentByName(argumentDecision)));
		}
		else if (problem.compare(enumeratesome) == 0)
		{
			cout << (*(pref.someExtension())) << endl;
		}
	}
	else if (semantics.compare(grounded_string_const) == 0)
	{
		GroundedSemantics ground = GroundedSemantics(&framework, global_enc);
		if (problem.compare(enumerateall) == 0)
		{
			ground.compute();
			cout << ground << endl;
		}
		else if (problem.compare(credulous) == 0)
		{
			printbooleanprobo(
					ground.credulousAcceptance(
							framework.getArgumentByName(argumentDecision)));
		}
		else if (problem.compare(skeptical) == 0)
		{
			printbooleanprobo(
					ground.skepticalAcceptance(
							framework.getArgumentByName(argumentDecision)));
		}
		else if (problem.compare(enumeratesome) == 0)
		{
			cout << (*(ground.someExtension())) << endl;
		}
	}
	else if (semantics.compare(stable_string_const) == 0)
	{
		StableSemantics stab = StableSemantics(&framework, global_enc);
		if (problem.compare(enumerateall) == 0)
		{
			stab.compute();
			cout << stab << endl;
		}
		else if (problem.compare(credulous) == 0)
		{
			printbooleanprobo(
					stab.credulousAcceptance(
							framework.getArgumentByName(argumentDecision)));
		}
		else if (problem.compare(skeptical) == 0)
		{
			printbooleanprobo(
					stab.skepticalAcceptance(
							framework.getArgumentByName(argumentDecision)));
		}
		else if (problem.compare(enumeratesome) == 0)
		{
			SetArguments *ret = stab.someExtension();
			if (ret == NULL)
				printbooleanprobo(false);
			else
				cout << (*(ret)) << endl;
		}
	}/*
	 else if (semantics.compare(semistable_string_const) == 0)
	 {
	 SemistableSemantics semistab = SemistableSemantics(&framework,
	 global_enc);
	 semistab.compute();
	 Semantics::iterator it;
	 for (it = semistab.begin(); it != semistab.end(); it++)
	 {
	 cout << *((*it).inargs()) << endl;
	 }

	 }
	 */

	return 0;
}
#endif
