/**
 * @file 		PreferredSemantics.cpp
 * @class 		PreferredSemantics
 * @brief 		Class for the preferred semantics for an AF
 * @author 		Federico Cerutti <federico.cerutti@acm.org>
 * @copyright	MIT
 */

#include "PreferredSemantics.h"

/**
 * @see CompleteSemantics#CompleteSemantics
 */
PreferredSemantics::PreferredSemantics(AF *the_af, Encoding enc) :
		super(the_af, enc)
{
}

/**
 * @brief                       This is the function that in TAFA-13 is described by Algorithm 1
 * @details                     This function has been rewritten for adhering to Algorithm 1 of TAFA-13, but the one used for
 *                                      the empirical evaluation in TAFA-13 was slightly different as it adopts some straightforward optimisations
 */
bool PreferredSemantics::compute(Argument *arg, bool firstonly)
{
	this->cleanlabs();
	this->add_non_emptiness();
	SATFormulae cnf = SATFormulae(3 * this->af->numArgs());
	this->sat_pigreek.clone(&cnf);
	do
	{
		Labelling prefcand = Labelling();
		SATFormulae cnfdf = SATFormulae(3 * this->af->numArgs());
		cnf.clone(&cnfdf);

		while (true)
		{
			Labelling res = Labelling();
			if (!this->satlab(cnfdf, &res))
			{
				break;
			}

			if (debug)
			{
				cout << endl;
				cout << "{";
				SetArgumentsIterator it;
				for (it = res.inargs()->begin(); it != res.inargs()->end();
						it++)
				{
					cout << (*it)->getName() << " ";
				}
				cout << "}" << endl;
			}
			bool emptyundec = res.undecargs()->empty();

			res.clone(&prefcand);

			SetArgumentsIterator iter;
			if (!emptyundec)
			{
				for (iter = res.inargs()->begin(); iter != res.inargs()->end();
						iter++)
				{
					cnfdf.appendOrClause(OrClause(1, (*iter)->InVar()));
				}
			}


			OrClause remaining = OrClause();
			for (iter = res.outargs()->begin(); iter != res.outargs()->end();
					iter++)
			{
				if (!emptyundec)
				{
					cnfdf.appendOrClause(OrClause(1, (*iter)->OutVar()));
				}
				remaining.appendVariable((*iter)->InVar());
			}

			OrClause remaining_df = OrClause();
			for (iter = res.undecargs()->begin();
					iter != res.undecargs()->end(); iter++)
			{
				remaining.appendVariable((*iter)->InVar());

				if (!emptyundec)
				{
					remaining_df.appendVariable((*iter)->InVar());
				}
			}

			if (!emptyundec)
			{
				cnfdf.appendOrClause(remaining_df);
			}

			cnf.appendOrClause(remaining);

			if (emptyundec)
				break;
		}

		if (prefcand.empty())
			break;

		if (arg != NULL)
		{
			if (prefcand.inargs()->exists(arg) == false)
				return false;
		}
		else
		{
			this->labellings.push_back(prefcand);
		}

		if (firstonly)
		{
			if (this->labellings.empty() && arg == NULL)
			{
				this->labellings.push_back(Labelling());
			}
			return true;
		}

		if (prefcand.inargs()->cardinality() == this->af->numArgs())
			break;

	} while (true);

	if (this->labellings.empty() && arg == NULL)
	{
		this->labellings.push_back(Labelling());
	}
	return true;
}

bool PreferredSemantics::credulousAcceptance(Argument *arg)
{
	return super::credulousAcceptance(arg);
}

bool PreferredSemantics::skepticalAcceptance(Argument *arg)
{
	if (this->credulousAcceptance(arg) == false)
		return false;
	return this->compute(arg);
}

SetArguments *PreferredSemantics::someExtension()
{
	this->compute(NULL, true);
	return this->labellings.at(0).inargs();
}

PreferredSemantics::~PreferredSemantics()
{
	// TODO Auto-generated destructor stub
}

