/**
 * @file 		SemistableSemantics.h
 * @author 		Federico Cerutti <federico.cerutti@acm.org>
 * @copyright	MIT
 */

#ifndef SEMISTABLESEMANTICS_H_
#define SEMISTABLESEMANTICS_H_

#include "CompleteSemantics.h"

class SemistableSemantics: public CompleteSemantics
{
	typedef CompleteSemantics super;
public:
	void compute();
	/**
	 * @see CompleteSemantics#CompleteSemantics
	 */
	SemistableSemantics(AF *the_af, Encoding enc) :
			super(the_af, enc)
	{
	}
	;
	virtual ~SemistableSemantics();
};

#endif /* SEMISTABLESEMANTICS_H_ */
