/**
 * @file 		Semantics.h
 * @author 		Federico Cerutti <federico.cerutti@acm.org>
 * @copyright	MIT
 */


#ifndef SEMANTICS_H_
#define SEMANTICS_H_

#include "AF.h"
#include "Labelling.h"
#include "SATFormulae.h"
#include "Encoding.h"
#include <vector>
#include <iostream>
#include <sstream>

extern bool debug;
using namespace std;

extern int (*SatSolver)(stringstream *, int, int, vector<int> *);

class Semantics
{
protected:
	AF *af; //!< @brief The Argumentation Framework considered
	Encoding encoding; //!< @brief The chosen encoding @see Semantics#Semantics
	SATFormulae sat_pigreek; //!< @brief The Sat Formulae as described in TAFA-13 filled in by the constructor Semantics#Semantics
	vector<Labelling> labellings; //!<@brief Attribute that contains the computed extensions
	int complete_labelling_SAT_constraints();
	bool satlab(SATFormulae, Labelling *, bool results=true);
	void cleanlabs();
public:
	typedef vector<Labelling>::const_iterator iterator;
	Semantics(AF *, Encoding);
	virtual ~Semantics();
	iterator begin() const;
	iterator end() const;
	string toString() const;
};

ostream& operator<<(ostream& , const Semantics& );


#endif /* SEMANTICS_H_ */
