==================================================
                        ZENN
==================================================

(1) For building,
./build.sh

(2) For running,
./zenn -ms=2 -gmr -recover=0 -safe_low=2 -safe_high=60 -var_luby=2 -phase_decay -glue_decay=0.800 -sinn_decay=0.990 BENCHNAME



