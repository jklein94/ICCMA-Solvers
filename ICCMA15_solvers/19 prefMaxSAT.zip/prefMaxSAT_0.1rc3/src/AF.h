/*
 * AF.h
 *
 *  Created on: 18 Feb 2015
 *      Author: geryo
 */

#include <stdexcept>
#include <iostream>
#include <sstream>
#include <vector>
#include <string>

using namespace std;

#ifndef AF_H_
#define AF_H_

class AF
{
private:
	unsigned int numArgs_;
	int* data_;
public:
	AF();
	AF(unsigned numArgs);
	AF(AF const& m);               // Copy constructor
	AF& operator= (AF const& m);   // Assignment operator
	int& operator()(unsigned arg1, unsigned arg2);
	int operator()(unsigned arg1, unsigned arg2) const;
	unsigned int getNumArgs() const;

	vector<unsigned int> they_attack_me(unsigned int arg) const;
	vector<unsigned int> i_attack_them(unsigned int arg) const;
	string printMaxSat();

	~AF();

	friend ostream &operator<<(ostream &output, const AF &D)
	{
		for (unsigned i = 0; i < D.getNumArgs(); i++)
		{
			output << i << " -> {";

			vector<unsigned int >  i_attack_them =D. i_attack_them(i);
			for (vector<unsigned int>::iterator it =  i_attack_them.begin(); it !=  i_attack_them.end(); it++)
				output << (*it) << " ";
			output << "}\n";
		}
		return output;
	}

};

#endif /* AF_H_ */
