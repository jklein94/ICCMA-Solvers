#include <string>
#include <fstream>
#include <iostream>
#include <vector>
#include <stdexcept>
#include <unistd.h>
#include <libgen.h>
#include "help.h"

string weight = "1000000";

string int_to_string(int number)
{
	char arrret[20148];
	sprintf(arrret, "%d", number);
	return string(arrret);
}

#include "lib_pstreams/pstream.h"

#include <stdexcept>

#define PSTREAMS_VERSION_MAJOR PSTREAMS_VERSION & 0xff00
#define PSTREAMS_VERSION_MINOR PSTREAMS_VERSION & 0x00f0
#define PSTREAMS_VERSION_PATCHLEVEL PSTREAMS_VERSION & 0x000f

#ifndef SLEEP_TIME
// increase these if your OS takes a while for processes to exit
# if defined (__sun) || defined(__APPLE__)
#  define SLEEP_TIME 2
# else
#  define SLEEP_TIME 1
# endif
#endif

using namespace std;
using namespace redi;

#if 0
// specialise basic_pstreambuf<char>::sync() to add a delay, allowing
// terminated processes to finish exiting, making it easier to detect
// possible writes to closed pipes (which would raise SIGPIPE and exit).
template <>
int
basic_pstreambuf<char>::sync()
{
	std::cout.flush();  // makes terminated process clean up faster.
	sleep(SLEEP_TIME+3);
	std::cout.flush();// makes terminated process clean up faster.
	return !exited() && empty_buffer() ? 0 : -1;
}
#endif

// explicit instantiations of template classes
template class redi::basic_pstreambuf<char>;
template class redi::pstream_common<char>;
template class redi::basic_ipstream<char>;
template class redi::basic_opstream<char>;
template class redi::basic_pstream<char>;
template class redi::basic_rpstream<char>;

#include "AF.h"

using namespace std;

const char *hgrev = "0.1rc3";

const string credulous = "DC";
const string skeptical = "DS";
const string enumerateall = "EE";
const string enumeratesome = "SE";

const string acceptedformats[] =
{ "apx" };
#define NUM_FORMATS 1
const string acceptedproblems[] =
{ //"DC-CO",
  //"DC-GR",
  //"DC-PR",
  //"DC-ST",
  //"DS-CO",
  //"DS-GR",
  //"DS-PR",
  //"DS-ST",
  //"EE-CO",
  //"EE-GR",
		"EE-PR" //,
		//"EE-ST",
		//"SE-CO",
		//"SE-GR",
		//"SE-PR",
		//"SE-ST"
		};
#define NUM_PROBLEMS 1

#define PARSE_CONTINUE 0
#define PARSE_EXIT 10
#define PARSE_ERROR -10
#define PARSE_UNABLE -20

//conf
bool debug = false;
bool externalsat = true;
string satsolver = "";
string defaultsolver = "maxsat";
bool manualopt = false;
string inputfile;
string semantics;
string problem;
string path;
string argumentDecision;

vector<string> arguments = vector<string>();

// use this only to avoid problem with AFs not declaring all the arguments at the beginning
// it must be a vector of arrays, each array has two elements
vector<vector<int> > attacks = vector<vector<int> >();

AF framework;

string numArgtoName(int i)
{
	if (i < 0 || i >= (int) arguments.size())
	{
		throw runtime_error("Trying to access an argument that does not exist");
	}
	return arguments.at(i);
}

int nameArgtoNum(string arg)
{
	for (int i = 0; i < (int) arguments.size(); i++)
	{
		if (arguments.at(i).compare(arg) == 0)
			return i;
	}
	throw runtime_error("No such argument in the database");
}

string trim(string s)
{
	size_t init = s.find_first_not_of(" ");
	size_t end = s.find_last_not_of(" ");

	if (init == string::npos)
		init = 0;

	if (end == string::npos)
		end = s.size();

	return s.substr(init, end - init + 1);
}

bool readFile(string file)
{
	string inLine;
	ifstream infile;
	infile.open(file.c_str());
	if (!infile.good())
		return false;

	size_t init = 0;
	do
	{
		getline(infile, inLine);

		if (debug)
			cerr << inLine << endl;

		if (!inLine.empty())
		{
			if ((init = inLine.find("arg")) != string::npos)
			{

				size_t open = inLine.find("(", init + 3);

				if (open == string::npos)
					return false;

				size_t close = inLine.find(")", open + 1);

				if (close == string::npos)
					return false;

				if (debug)
				{
					cerr << inLine.substr(open + 1, close - open - 1)
							<< "; init " << open + 1 << "; close " << close - 1
							<< endl;
					cerr << trim(inLine.substr(open + 1, close - open - 1))
							<< endl;
				}

				arguments.push_back(inLine.substr(open + 1, close - open - 1));

			}
			else if ((init = inLine.find("att")) != string::npos)
			{

				size_t open = inLine.find("(", init + 3);

				if (open == string::npos)
					return false;

				size_t comma = inLine.find(",", open + 1);

				if (comma == string::npos)
					return false;

				size_t close = inLine.find(")", comma + 1);

				if (close == string::npos)
					return false;

				if (debug)
				{
					cerr << trim(inLine.substr(open + 1, comma - open - 1))
							<< endl;
					cerr << trim(inLine.substr(comma + 1, close - comma - 1))
							<< endl;
				}

				string source = trim(inLine.substr(open + 1, comma - open - 1));
				string target = trim(
						inLine.substr(comma + 1, close - comma - 1));

				vector<int> attack = vector<int>();
				attack.push_back(nameArgtoNum(source));
				attack.push_back(nameArgtoNum(target));
				attacks.push_back(attack);

			}
		}
	} while (!infile.eof());

	if (debug)
	{
		for (vector<string>::iterator it = arguments.begin();
				it != arguments.end(); it++)
			cerr << (*it) << ", ";
		cerr << endl;

		for (vector<vector<int> >::iterator it = attacks.begin();
				it != attacks.end(); it++)
			cerr << (*it)[0] << " -> " << (*it)[1] << endl;
		cerr << endl;
	}
	infile.close();

	framework = AF(arguments.size());

	for (vector<vector<int> >::iterator it = attacks.begin();
			it != attacks.end(); it++)
	{
		framework((*it).at(0), (*it).at(1)) = 1;
	}

	return true;
}

void printArray(const string arr[], int dim)
{
	int i = 0;
	cout << "[";
	for (i = 0; i < dim; i++)
	{
		cout << arr[i];
		if (i != dim - 1)
			cout << ", ";
	}
	cout << "]" << endl;
}

bool isInArray(string el, const string arr[], int dim)
{
	int i = 0;
	for (i = 0; i < dim; i++)
	{
		if (arr[i].compare(el) == 0)
			return true;
	}
	return false;
}

void authorInfo(const char *rev)
{
	cout << "prefMaxSAT " << rev << endl;
	cout << "Mauro Vallati <mauro.vallati@hud.ac.uk>" << endl;
	cout << "Federico Cerutti <federico.cerutti@acm.org>" << endl;
	cout << "Wolfgang Faber <wf@wfaber.com>" << endl;
	cout << "Massimiliano Giacomin <massimiliano.giacomin@unibs.it>" << endl;

}

/**
 * @brief			Function for printing on screen a disclaimer and a brief help
 * @param[in] rev	The version of this software
 * @retval	void
 */
void showHelp(const char *rev)
{
	cout << rev << endl;

	cout
			<< "prefMaxSAT Copyright (C) 2015" << endl
			<< "Mauro Vallati <m.vallati@hud.ac.uk>" << endl
			<< "Federico Cerutti <federico.cerutti@org>" << endl
			<< "Wolfgang Faber <wf@wfaber.com>" << endl
			<< "Massimiliano Giacomin <massimiliano.giacomin@unibs.it>" << endl
			<< endl;
	cout << "This program comes with ABSOLUTELY NO WARRANTY" << endl;
	cout << "This is free software, under the MIT license" << endl;

	cout << "#### Running" << endl;
	cout << "./prefMaxSAT <param1> ... <paramN>" << endl;
	cout << "--help\t\t\t this help" << endl;
	cout << "-d \t\t\t *HIGH* level of debug (very slow, very dense output)"
			<< endl;
	cout << "-f <filename>\t\t input file name for a problem" << endl;
	cout << "-fo <format>\t\t format of the input file" << endl;
	cout << "-p <problem>\t\t problem to be solved" << endl;
	cout << "-a <additional>\t\t argument to check the acceptance" << endl;
	cout << "--formats\t\t list of supported file types" << endl;
	cout << "--problems\t\t list of supported problems" << endl;
	cout << "--sat\t\t\t SAT solver full path: by default " << path << "/"
			<< defaultsolver << endl;

	return;
}

/**
 * @brief				Function for parsing the parameters
 * @details				This function does not return any value. It fills global variables according to
 * 						the received parameters.
 * @param[in] argc		`int` containing the numbers of parameters
 * @param[in] argv		List of parameters
 * @retval int			  0: everything is fine
 * 						 10: exit the program
 * 						-10: error
 * 						-20: unable to perform the desired query
 */
int parseParams(int argc, char *argv[])
{
	//default
	satsolver = string(path) + "/" + defaultsolver;
	if (argc == 1)
	{
		authorInfo(hgrev);
		return PARSE_EXIT;
	}

	for (int k = 1; k < argc; k++)
	{
		if (string("-d").compare(argv[k]) == 0)
			debug = true;
		else if (string("--formats").compare(argv[k]) == 0)
		{
			printArray(acceptedformats, NUM_FORMATS);
			return PARSE_EXIT;
		}
		else if (string("--problems").compare(argv[k]) == 0)
		{
			printArray(acceptedproblems, NUM_PROBLEMS);
			return PARSE_EXIT;
		}
		else if (string("--help").compare(argv[k]) == 0)
		{
			showHelp(hgrev);
			return PARSE_EXIT;
		}
		else if (string("-f").compare(argv[k]) == 0)
		{
			inputfile = string(argv[++k]);
		}
		else if (string("-a").compare(argv[k]) == 0)
		{
			argumentDecision = string(argv[++k]);
		}
		else if (string("-fo").compare(argv[k]) == 0)
		{
			if (!isInArray(string(argv[++k]), acceptedformats, NUM_FORMATS))
			{
				return PARSE_UNABLE;
			}
		}
		else if (string("-p").compare(argv[k]) == 0)
		{
			string p = string(argv[++k]);
			if (!isInArray(p, acceptedproblems, NUM_PROBLEMS))
			{
				return PARSE_UNABLE;
			}

			size_t dash = p.find("-");
			if (dash == string::npos)
			{
				return PARSE_ERROR;
			}
			problem = p.substr(0, dash - 1);
			semantics = p.substr(dash + 1);
		}
		else if (string("--sat").compare(argv[k]) == 0)
		{
			satsolver = string(argv[++k]);
		}
		else
		{
			cout << "Unrecognised parameter: " << argv[k] << endl;
			return PARSE_ERROR;
		}
	}
	return true;
}

bool satlab(string sat, vector<int> *extension)
{

	const pstreams::pmode all3streams = pstreams::pstdin | pstreams::pstdout
			| pstreams::pstderr;

	pstream ps;
	ps.open(satsolver, all3streams);

	if (debug)
	{
		cerr << sat << endl;
	}

	ps << sat << peof;

	string buf;
	int retsat = 0; //neither sat nor unsat by default
	//vector<int> lastcompfound = vector<int>();
	while (getline(ps.out(), buf))
	{
		if (debug)
			cerr << buf << endl;

		if (buf.empty())
			continue;

		if (buf.at(0) == 'c')
			continue;

		if (buf.at(0) == 's')
		{
			if (buf.find("UNSAT") != string::npos)
				retsat = 20; //unsat
			else
				retsat = 10; //sat
		}

		if (buf.at(0) == 'v')
		{
			istringstream vars(buf.substr(2));
			int temp = 0;
			while (1)
			{
				vars >> temp;
				if (vars.eof())
					break;

				if (debug)
				{
					cerr << temp << endl;
				}

				extension->push_back(temp);
			}
		}

	}

	ps.clear();
	ps.close();

	if (debug)
	{
		cerr << "Extension: " << endl;
		for (vector<int>::iterator ext = extension->begin();
				ext != extension->end(); ext++)
		{
			cerr << (*ext) << " ";
		}
	}

	if (retsat == 0 || (retsat == 10 && extension->empty())) // || !fexists(satsolver.c_str()))
	{
		throw runtime_error(
				"Cannot communicate with SAT or SAT error \n" + satsolver + "\n"
						+ sat);
	}

	if (debug)
		cout << retsat;

	if (retsat != 20)
	{
		return true;
	}
	return false;
}

int main(int argc, char *argv[])
{

	char buf[2048];
	readlink("/proc/self/exe", buf, 2047);
	path = string(dirname(buf));

	//debug = true; //uncomment to enable some debug messages on cerr

	int p = parseParams(argc, argv);

	if (p == PARSE_EXIT)
	{
		return 0;
	}
	if (p == PARSE_ERROR || p == PARSE_UNABLE)
	{
		showHelp(hgrev);
		return -127;
	}

	if (debug)
		cerr << inputfile << endl;

	if (!readFile(inputfile))
	{
		showHelp(hgrev);
		return -1;
	}

	vector<vector<int> > solutions = vector<vector<int> >();

	string maxsat = framework.printMaxSat();

	bool sat = true;

	do
	{
		vector<int> an_extension = vector<int>();
		sat = satlab(maxsat, &an_extension);
		if ((!sat && solutions.empty()) || sat)
			solutions.push_back(an_extension);

		if (sat && !an_extension.empty())
		{
			string solution_negated = weight + " ";
			string other_extensions = weight + " ";
			for (vector<int>::iterator it = an_extension.begin();
					it != an_extension.end(); it++)
			{
				if (debug)
					cerr << (*it) << " ";

				solution_negated += int_to_string(-1 * (*it)) + " ";
				if ((*it) < 0)
				{
					other_extensions += int_to_string(-1 * (*it)) + " ";
				}
			}

			if (debug)
				cerr << endl;

			maxsat += solution_negated + "0\n";
			maxsat += other_extensions + "0\n";

		}

	} while (sat);

	cout << "[";
	for (vector<vector<int> >::iterator ext = solutions.begin();
			ext != solutions.end(); ext++)
	{
		if ((*ext).empty())
			cout << "[]";
		else
		{
			cout << "[";
			bool first = true;
			for (vector<int>::iterator arg = (*ext).begin();
					arg != (*ext).end(); arg++)
			{
				if ((*arg) > 0)
				{
					if (!first)
						cout << ",";

					cout << numArgtoName((*arg) - 1);
					first = false;
				}
			}
			cout << "]";
			if (ext + 1 != solutions.end())
				cout << ",";
		}

	}
	cout << "]" << endl;
}
