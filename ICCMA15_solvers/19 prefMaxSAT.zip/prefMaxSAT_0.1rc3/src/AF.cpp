/*
 * AF.cpp
 *
 *  Created on: 18 Feb 2015
 *      Author: geryo
 */

#include "AF.h"
#include "help.h"

extern string weight;

AF::AF()
{
	numArgs_ = 0;
}

AF::AF(unsigned numargs) :
		numArgs_(numargs)
{
	if (numargs == 0)
		throw runtime_error("no arguments?");
	data_ = new int[numargs * numargs]();
	for (unsigned int i = 0; i < numargs * numargs; i++)
		data_[i] = 0;
}

AF::AF(AF const& m)
{
	numArgs_ = m.getNumArgs();
	data_ = new int[numArgs_ * numArgs_]();
	for (unsigned int i = 0; i < numArgs_; i++)
	{
		for (unsigned int j = 0; j < numArgs_; j++)
		{
			(*this)(i, j) = m(i, j);
		}
	}
}
AF& AF::operator=(AF const& m)
{
	numArgs_ = m.getNumArgs();
	data_ = new int[numArgs_ * numArgs_]();
	for (unsigned int i = 0; i < numArgs_; i++)
	{
		for (unsigned int j = 0; j < numArgs_; j++)
		{
			(*this)(i, j) = m(i, j);
		}
	}
	return *this;
}

AF::~AF()
{
	delete[] data_;
}

int& AF::operator()(unsigned row, unsigned col)
{
	if (row >= numArgs_ || col >= numArgs_)
		throw runtime_error("Argument subscript out of bounds");
	return data_[numArgs_ * row + col];
}

int AF::operator()(unsigned row, unsigned col) const
{
	if (row >= numArgs_ || col >= numArgs_)
		throw runtime_error("const Argument subscript out of bounds");
	return data_[numArgs_ * row + col];
}

unsigned AF::getNumArgs() const
{
	return this->numArgs_;
}

vector<unsigned int> AF::they_attack_me(unsigned int arg) const
{
	vector<unsigned int> ret = vector<unsigned int>();
	for (unsigned int i = 0; i < this->numArgs_; i++)
	{
		if ((*this)(i, arg) == 1)
			ret.push_back(i);
	}
	return ret;
}

vector<unsigned int> AF::i_attack_them(unsigned int arg) const
{
	vector<unsigned int> ret = vector<unsigned int>();
	for (unsigned int i = 0; i < this->numArgs_; i++)
	{
		if ((*this)(arg, i) == 1)
			ret.push_back(i);
	}
	return ret;
}

string AF::printMaxSat()
{
	string codifica="";
	int numero_clausole=0;

	//main cycle
	vector<unsigned int> attack_me;
	vector<unsigned int> attack_them;
	vector<unsigned int> support;

	string forza_vero=weight + " ";
	for (unsigned int i = 0; i < this->numArgs_; i++){
		forza_vero+=int_to_string(i+1)+" ";
		attack_me=they_attack_me(i);
		attack_them=i_attack_them(i);
		//soft-clause for maximising
		codifica+="1 "+int_to_string(i+1)+" 0\n";
		numero_clausole++;
		//no one is attacking me :)
		if(attack_me.size()==0){
			codifica+=weight+" "+int_to_string(i+1)+" 0\n";
			numero_clausole++;
		}
		else{
			for(int h=0; h < attack_me.size(); h++){
				support=they_attack_me(attack_me[h]);
				if (support.size() == 1 && support[0] == i)
					continue;
				codifica+=weight+ " -"+int_to_string(i+1);
				for(int j=0; j < support.size(); j++)
							codifica+=" "+int_to_string(support[j]+1);
				codifica+=" 0\n";
				numero_clausole++;
			}
		}
		

		//let have some relationships with those that I attack
		for(int h=0; h < attack_them.size(); h++){
			codifica+=weight+" -"+int_to_string(i+1)+" -"+int_to_string(attack_them[h]+1)+" 0\n";
			numero_clausole++;
		}
	}

	forza_vero+="0\n";
	codifica+=forza_vero;
	numero_clausole++;
	codifica="c \nc comments Partial Max-SAT\np wcnf "+int_to_string(this->numArgs_)+" "+int_to_string(numero_clausole)+" "+weight+"\n"+codifica;

	return codifica;

}
