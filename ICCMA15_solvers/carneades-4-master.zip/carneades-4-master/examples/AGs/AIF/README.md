These files are argument graphs represented in the JSON serialization
of the Argument Interchange Format (AIF).  The files are from the
AraucariaDB corpus available at:

http://www.arg.dundee.ac.uk/aif-corpora/

For further information about AIF, see:

- http://www.argumentinterchange.org/developers
- http://www.arg-tech.org/index.php/projects/
