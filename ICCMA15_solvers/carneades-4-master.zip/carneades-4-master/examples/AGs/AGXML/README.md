These files are argument graphs from the annotated corpus of
"Argumentative Microtexts" Github project. The files are represented
in XML using the schema defined by the developers of the corpus.
For further information, see:

    https://github.com/peldszus/arg-microtext
