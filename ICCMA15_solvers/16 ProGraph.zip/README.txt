The submitted solver supports apx format files and solves the DC-ST and SE-ST problems.
The solver is best in cases when a solution is possible, in case the answer is NO it may take very long time to reach that conclusion.

For the compiling, swi-prolog is needed, it is free and can be downloaded from their site http://www.swi-prolog.org/Download.html or installed from the terminal using the following commands. Any stable version should be ok. 
In Ubuntu the following sripts should do:
%sudo apt-add-repository ppa:swi-prolog/stable
%sudo apt-get update
%sudo apt-get install swi-prolog

The solver contains a single file icmaa_final.pl, all the source code rezides in it.
Compile using one of the following commands or using ./build
user$ swipl -O -o GrozaSerban --quiet -g main -c icmaa_final.pl
or
user$ swipl -o solver --quiet -g main -c icmaa_final.pl
the first one optimizes the code.

Run solver with the required parameters, for details consult
http://argumentationcompetition.org/2015/iccma15notes_v3.pdf

Solver developed by Groza Serban, student at Technical University Of Cluj Napoca.
