#!/bin/bash
javac -Xlint:unchecked *.java
