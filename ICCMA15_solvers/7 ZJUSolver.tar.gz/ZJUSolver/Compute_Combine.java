
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

/**
 * 
 * @author beishui
 */
public class Compute_Combine {
	public ArrayList GetLabellings(HashSet[] Sub, HashSet[] U,
			HashSet[] Parents, HashSet[] Children, int maxlev) {

		// compute the labellings of layer 0
		ArrayList Comb0;
		// System.out.println("pre-U[0]="+U[0]);
		// System.out.println("pre-Sub[0]="+Sub[0]);
		// 初始化各根节点(U[0] sub[0])标记
		Comb0 = new ComputeLayer0().getLabellingsOfLayer0(Sub[0], U[0],
				Parents, Children);
		// System.out.println("!!!Comb0="+Comb0);

		// compute the labellings of layer 1-maxlev
		for (int i = 1; i <= maxlev; i++) {
			Iterator itc = Comb0.iterator();
			// 每次要遍历之前所有的结果，可能能优化！！！
			ArrayList Comb2 = new ArrayList();
			while (itc.hasNext()) {
				ThreeTuple<HashSet, HashSet, HashSet> L0 = (ThreeTuple<HashSet, HashSet, HashSet>) itc
						.next();
				// System.out.println("L0="+L0);
				ArrayList Comb1;
				// System.out.println("subi="+Sub[i]+" ui="+U[i]);
				Comb1 = new ComputeLayeri().getLabellingsOfLayeri(Sub[i], U[i],
						L0, Parents, Children);
				// System.out.println("Comb1="+Comb1);
				Comb2.addAll(Comb1);
			}
			Comb0.clear();
			Comb0 = (ArrayList) Comb2.clone();
			// System.out.println("Comb0="+Comb0);
			Comb2.clear();
		}
		// System.out.println("Comb0="+Comb0);
		return Comb0;
	}
}
