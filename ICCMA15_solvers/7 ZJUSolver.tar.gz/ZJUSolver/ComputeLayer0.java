/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;


/**
 *
 * @author beishui
 */
public class ComputeLayer0 {
public ArrayList getLabellingsOfLayer0(HashSet Sub0, HashSet U0, HashSet[] Parents, HashSet[] Children){ 
	//？？？为什么要先计算U0和Sub0
    HashSet h;
    ArrayList Comb = new ArrayList(); 
    ArrayList Comb1 = new ArrayList();  // to store the middle data
   
    
    
    // if U0 is not empty, compute the labelling of U0
    //System.out.println("U0="+U0);
    //计算U0基语义
    if(!U0.isEmpty()){
    	ThreeTuple<HashSet, HashSet, HashSet> groundedlabelling;
    	HashSet in1, out1, undec1;
    	in1 = new HashSet();
      	out1 = new HashSet();
      	undec1 = new HashSet();
      	ThreeTuple<HashSet, HashSet, HashSet> L1 = new ThreeTuple<HashSet, HashSet, HashSet>(in1, out1, undec1);
      	//System.out.println("L1="+L1);
      	//System.out.println("U0="+U0);
      	groundedlabelling = new FingGroundedLabellings().GetGroundedLabellings(L1, Parents, Children, U0);
      	Comb.add(groundedlabelling);
      	//System.out.println("groundedlabelling"+groundedlabelling);
    } 
    
    //if Sub0 is not empty, compute the labellings of each SCC in Sub0
    //计算sub0优先语义
    Iterator it = Sub0.iterator();
    for(int i=0; i<Sub0.size(); i++){
	    HashSet s;
	    s = (HashSet)it.next();
	    
	    HashSet in, out, undec;
	    out = new HashSet();
	    undec = new HashSet();
	    //全部初始化成in
	    in = (HashSet)s.clone();
	    ThreeTuple<HashSet, HashSet, HashSet> L = new ThreeTuple<HashSet, HashSet, HashSet>(in, out, undec);  
	    HashSet[] labellings;
	    labellings = new HashSet[Sub0.size()+1];
	  
	    HashSet Candidatelabellings;
	    Candidatelabellings = new HashSet();
	    HashSet Condition, ConditionUndec;
	    Condition = new HashSet();
	    ConditionUndec = new HashSet();
	    
////测试加入基语义
//	    HashSet tin = new HashSet();
//	    HashSet tout = new HashSet();
//	    HashSet tundec = new HashSet();
//	    ThreeTuple<HashSet, HashSet, HashSet> tL = new ThreeTuple<HashSet, HashSet, HashSet>(tin, tout, tundec);
//	    ThreeTuple<HashSet,HashSet,HashSet> tlabelling;
//      tlabelling=new FingGroundedLabellings().GetGroundedLabellings(tL,Children,Parents,s,true);
//      System.out.println("tlb="+tlabelling);
        
	    labellings[i] = new FindPreferredLabellings().GetLabellings(L, Children, Parents, Candidatelabellings, Condition, ConditionUndec);
	     
	    if(!Comb.isEmpty()){
	    //存在U0基语义，将U0基语义与sub0的优先语义合在一起
	    	Iterator it1 = Comb.iterator();
	    		while(it1.hasNext()){
			        ThreeTuple<HashSet, HashSet, HashSet> L3;
			        L3 = (ThreeTuple<HashSet, HashSet, HashSet>)it1.next();
			          
			        HashSet Cin, Cout, Cundec;  
			        Iterator it2 = labellings[i].iterator();
			        while(it2.hasNext()){
				        ThreeTuple<HashSet, HashSet, HashSet> L4;
				        L4 = (ThreeTuple<HashSet, HashSet, HashSet>)it2.next();
				        Cin = (HashSet)L3.first.clone();
				        Cout = (HashSet)L3.second.clone();
				        Cundec = (HashSet)L3.third.clone();
				        Cin.addAll(L4.first);
				        Cout.addAll(L4.second); 
				        Cundec.addAll(L4.third); 
				  
				        ThreeTuple<HashSet, HashSet, HashSet> L5 = new ThreeTuple<HashSet, HashSet, HashSet>(Cin, Cout, Cundec);
				        Comb1.add(L5);
			        } 
		    	}
		    	Comb.clear();
		    	Comb = (ArrayList)Comb1.clone();
		    	Comb1.clear();
	    }
	    else{
	    	Comb.addAll(labellings[i]);
	    }
	} 
    return Comb;  
}
}
