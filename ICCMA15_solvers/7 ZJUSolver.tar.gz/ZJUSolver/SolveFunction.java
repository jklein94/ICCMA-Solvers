

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;

public class SolveFunction {
	public  String versionInfo()
	{
		return "ZJUSolver 1.0\nQianle Guo, Beishui Liao";
	}
	
	public Collection<Problem> supportedProblems() {
		Collection<Problem> problems = new HashSet<Problem>();
		for(Problem problem: Problem.values())
			problems.add(problem);
		return problems;
	}
	
	public Collection<FileFormat> supportedFormats() {
		Collection<FileFormat> formats = new HashSet<FileFormat>();
		for(FileFormat f: FileFormat.values())
			formats.add(f);
		return formats;
	}

	public void solve(Problem problem, File input, FileFormat format, String additionalParameters) throws IOException {

		if(problem.subProblem().equals(Problem.SubProblem.EE)){
			ArrayList result = new ArrayList();
			if(problem.semantics().equals(Semantics.PR))
				result=new Execute().ExecutePR(input,format);
			if(problem.semantics().equals(Semantics.GR))
				result=new Execute().ExecuteGR(input,format);
			Writer.WriteEE(result);
			return;
		}
		
		if(problem.subProblem().equals(Problem.SubProblem.EL)){
			ArrayList result = new ArrayList();
			if(problem.semantics().equals(Semantics.PR))
				result=new Execute().ExecutePR(input,format);
			if(problem.semantics().equals(Semantics.GR))
				result=new Execute().ExecuteGR(input,format);
			Writer.WriteEL(result);
			return;
		}		
		// for the remaining problems we need an additional parameter, so check whether
		// this is not null

		System.out.println("Problem unknown");
	}
}
