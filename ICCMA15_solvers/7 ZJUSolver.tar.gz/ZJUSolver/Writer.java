
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

/**
 * Writes an abstract argumentation framework into a file
 * of a specific format.
 * 
 * @author Matthias Thimm
 */
public abstract class Writer {
	
	/**
	 * Retrieves the writer for the given file format.
	 * @param f some file format
	 * @return a writer or null if the format is not supported.
	 */
//	public static Writer getWriter(FileFormat f){
//		if(f.equals(FileFormat.TGF))
//			return new TgfWriter();
//		if(f.equals(FileFormat.APX))
//			return new ApxWriter();
//		return null;
//	}
	
	/**
	 * Writes the given collection of arguments into a string of the form
	 * [arg1,...,argn].
	 * @param args some collection of arguments
	 * @return a string representation of the collection of arguments
	 */
	
	
	public static boolean WriteHash(HashSet<?> x){
		Iterator<?> it=x.iterator();
			if(!x.isEmpty()){
			boolean flag1=true;
			System.out.print("[");
			while(it.hasNext()){
				if(!flag1)
					System.out.print(",");
				int t=(Integer) it.next();
				System.out.print(DealFile.getString(t));
				flag1=false;
				}
			System.out.print("]");
			return true;
			}
		return false;
	}
	
	public static void WriteEL(ArrayList args){
		Iterator<ThreeTuple<HashSet, HashSet, HashSet>> it=args.iterator();
		for(int i=0;i<args.size();i++){
			System.out.print("[");
			ThreeTuple<HashSet, HashSet, HashSet> temp=it.next();
			HashSet<?> in=temp.first;
			HashSet<?> out=temp.second;
			HashSet<?> und=temp.third;
			if(!WriteHash(in))
					System.out.print("[]");
			System.out.print(",");
			if(!WriteHash(out))
				System.out.print("[]");
			System.out.print(",");
			if(!WriteHash(und))
				System.out.print("[]");
			System.out.println("]");
		}
	}
	
	public static void WriteEE(ArrayList args){
		Iterator<ThreeTuple<HashSet, HashSet, HashSet>> it=args.iterator();
		System.out.print("[");
		for(int i=0;i<args.size();i++){
			if(i!=0)
				System.out.print(",");
			
			ThreeTuple<HashSet, HashSet, HashSet> temp=it.next();
			HashSet<?> in=temp.first;
			if(!WriteHash(in))
					System.out.print("[]");
		}
		System.out.println("]");
	}
}
