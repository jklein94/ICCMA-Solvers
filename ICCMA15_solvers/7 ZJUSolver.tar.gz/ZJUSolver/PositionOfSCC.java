

import java.util.HashSet;
import java.util.Iterator;

/**
 *
 * @author beishui
 */
//算出每个连通分支处于第几层，用lv表示
public class PositionOfSCC {
    public int[] getPosition(HashSet SCCS, HashSet[] sccpar, HashSet[] S, int[][] attacks, boolean[] nontriv){
int[] lv, maxlevel;
lv = new int[SCCS.size()+1];
//System.out.println("guo");
HashSet[]  back1;
back1 = new HashSet[SCCS.size()+1]; //to save the middle results
int sccNumber = SCCS.size();
HashSet E = null;
int Count =0;
for(int i=0; i<sccNumber; i++){ //initialize back
back1[i] = new HashSet();
back1[i] = (HashSet)sccpar[i].clone();
//System.out.println("back1["+i+"]="+back1[i]); 
}
HashSet D; //the SCC to be handled
while(SCCS.isEmpty()==false){  // If SCCS is not empty, then tack an SCC from SCCS
  if(E==null){                  // or the SCC is one of the parents of the previously treated SCC
     D = (HashSet)SCCS.iterator().next(); // take an SCC from SCCS
    // System.out.println("D="+D);
     } 
  else{D=E;//D的父集合不为空，所以换为D的父点E
   // System.out.println("D=E="+D);
  }
  //System.out.println("SCCS="+SCCS);
  
  for(int m=0; m<sccNumber; m++){ //check which SCC is D
   // System.out.println("S["+m+"]="+S[m]); 
	//System.out.println("D:"+D+",num="+m);
    if(D==S[m]){
    	//System.out.println("S["+m+"]="+S[m]);
    	//System.out.println("back1["+m+"]="+back1[m]); //???为什么back1输出总是空
    	//System.out.println("pre-back1["+m+"]="+back1[m]);
    	//System.out.println(m+":"+back1[1]+"|"+back1[2]+"|"+back1[3]);
    	back1[m].remove(null); 
    	//System.out.println("post-back1["+m+"]="+back1[m]);
    	if(back1[m].isEmpty()){    //check whether the set of SCC parents of D is empty
    		//如果back1[m]为空，则D之前的（父辈的）联通分支都已处理过
    		//System.out.println("sccpar["+m+"]="+sccpar[m]); 
    		//System.out.println(m+":"+back1[1]+"|"+back1[2]+"|"+back1[3]);
    		sccpar[m].remove(null); 
    		if(sccpar[m].isEmpty()){   //check whether D is an initial SCC
    			//如果sccpar[m]为空，则D为初始连通分支，因为一步结束只删除了back1中的父节点，伪善sccpar中的
    			//System.out.println("m="+m); 
    			//System.out.println("sccpar-back["+m+"]="+sccpar[m]); 
    			lv[m] = Count;
    		}
    		else{
    			//System.out.println("guo"); 
    			lv[m] = 0; //initialize lv[m]
    			Iterator it4 = sccpar[m].iterator();
    			maxlevel = new int[sccpar[m].size()+1];//
    			for(int u=1; u<=sccpar[m].size(); u++){ //take each SCC parent of D
    				HashSet U = (HashSet)it4.next(); // U is a parent of D
    				//System.out.println("sccpar["+m+"]="+sccpar[m]); 
	                //System.out.println("U="+U);
	                maxlevel[u]=0; //initialize maxlevel[u]
	                for(int v=0; v<sccNumber; v++){  // check that which SCC is U
	                	if(U==S[v]){
	                		//System.out.println("U="+S[v]);
	                		//boolean NonD = new Nontrivial().nontrivial(D, attacks);
	                		//boolean NonU = new Nontrivial().nontrivial(U, attacks);
	                		if(nontriv[m]){  // if D is nontrivial 
	                			//  System.out.println(D+"is not trivial");
	                			lv[m] = Math.max(lv[m], lv[v]+1);//如果D是强连通分支而非单点，层级加一，即与父块划分开
	                		}
	                		else{
	                			//   System.out.println(D+"is trivial");
	                			if(nontriv[v]){ //if U is nontrivial
	                				//    System.out.println(U+"is not trivial"); 
	                				lv[m] = Math.max(lv[m], lv[v]+1);//如果D的父块是强连通分支而非单点，层级加一，即与父块划分开
	                			}
	                			else{
	                				//    System.out.println(U+"is trivial"); 
	                				lv[m] = Math.max(lv[m], lv[v]);
	                			}       
	                		}
	                	}
	                }
    			}
             
           }
       
       //System.out.println("level["+m+"]="+lv[m]);
       SCCS.remove(D);
       //System.out.println("Remove"+D);
       E = null;
       for(int n=0; n<sccNumber; n++){
          back1[n].remove(D);
         // System.out.println("back1["+n+"]="+ back1[n]);
          
       }
       //？？？可以break
       }
    	
   
    else{
    	//D的父集合不为空，所以换为D的父点E
       E=(HashSet)back1[m].iterator().next(); //take a parent of D
       //System.out.println("not empty");
    }
}
}
//System.out.println("post-SCCS="+SCCS);
}
    
return lv;    
}
}
