

import java.util.HashSet;
import java.util.Iterator;

/**
 *
 * @author beishui
 */
public class FingGroundedLabellings {
    public ThreeTuple<HashSet,HashSet,HashSet> GetGroundedLabellings(ThreeTuple<HashSet,HashSet,HashSet> L, HashSet[] P, HashSet[] C, HashSet A){
    	//P parent C children A initU
    
    	
    HashSet in, out, undec, in1, out1, undec1;
    
    in = L.first;
    out = L.second;
    //System.out.println("guo L!!!=" + L);
    //System.out.println("A=" +A);
  
    A.removeAll(in); //
    Iterator it1 = in.iterator();

    //把所有in节点的子节点改为out
    while(it1.hasNext()){
	    int k = (Integer)it1.next();
	    A.removeAll(C[k]);
	    out.addAll(C[k]);
    } 
    //System.out.println("in=" +in);
    //System.out.println("!A=" +A);   
    
    boolean eq;
    
    do{
    	
    	//System.out.println("guo1"); 
    	in1 = (HashSet)in.clone();
    	Iterator it = A.iterator();
    	//HashSet RM;
    	//RM = new HashSet();
    	//System.out.println("RM="+RM);
    	
    	for(int i=0; i<A.size(); i++){
    		
    		//System.out.println("guo2"); 
    		int x=(Integer)it.next();
    		
    		//System.out.println("P["+x+"]="+P[x]); 
    		//父节点不存在或者父节点为out，则将x改为in
    		
    		if(P[x].isEmpty()|out.containsAll(P[x])){
    			
    			//System.out.println("guo3"); 
    			in.add(x);
    			//RM.removeAll(C[x]);
    			//System.out.println("Pre-C{"+x+"]="+C[x]); 
    			//将x的子节点改为out
    			C[x].retainAll(A);
    			//System.out.println("Post-C{"+x+"]="+C[x]); 
    			out.addAll(C[x]);

    		}
    		else{
    			HashSet inCopy = (HashSet)in.clone();
    			inCopy.retainAll(P[x]);
    			if(!inCopy.isEmpty()){
    				out.add(x);
    			}
        
    		}
    
    	}
    	eq = new SetEqual().Equal(in, in1);   
    } while(!eq);
    
    A.removeAll(in);
    A.removeAll(out);
    L.third=A;
    //System.out.println("The Grounded labelling is  "+L);
    return L;
    }
}
