/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

/**
 *
 * @author beishui
 */
public class ComputeLayeri {
    public ArrayList getLabellingsOfLayeri(HashSet Subi, HashSet U,ThreeTuple<HashSet, HashSet, HashSet> L0, HashSet[] Parents, HashSet[] Children){ 
    //Subi当前的强连通分支中节点的集合    Ui当前的点强连通分支中节点的集合     L0之前计算的labelling结果集合
    HashSet h;
    ArrayList Comb = new ArrayList(); 
    ArrayList Comb1 = new ArrayList();  // to store the middle data
   
    //f Ui is not empty, compute the labelling of U0
    HashSet Ui = (HashSet)U.clone();
    //ystem.out.println("Ui="+Ui);
    if(!Ui.isEmpty()){
    	ThreeTuple<HashSet, HashSet, HashSet> groundedlabelling;
    	//compute the affecting arguments
    	Iterator itu = Ui.iterator();
    	HashSet Affecting = new HashSet();
    	while(itu.hasNext()){
	        int x = (Integer)itu.next(); //x is an argument of Ui
	        //System.out.println("x="+x);
	        HashSet P;
	        P = (HashSet)Parents[x].clone();
	        P.removeAll(Ui); // the outside parents of argument x
	        Affecting.addAll(P);
    	}
	    //将Ui的父节点都加入Ui
	    Ui.addAll(Affecting); //add the affecting arguments to Ui
	    //System.out.println("post-Ui="+Ui);
	      
	    //get the labeling of affecting arguments
	    HashSet in1, out1, undec1;
	    in1 = (HashSet)L0.first.clone();
	    in1.retainAll(Affecting);
	    out1 = (HashSet)L0.second.clone();
	    out1.retainAll(Affecting);
	    undec1 = (HashSet)L0.third.clone();
	    undec1.retainAll(Affecting);
	    
	    ThreeTuple<HashSet, HashSet, HashSet> L1 = new ThreeTuple<HashSet, HashSet, HashSet>(in1, out1, undec1);
	    //System.out.println("L1="+L1);
	      
	    groundedlabelling = new FingGroundedLabellings().GetGroundedLabellings(L1, Parents, Children, Ui);
	    //System.out.println("groundedlabelling="+groundedlabelling);
	    Comb.add(groundedlabelling);
	} 
/////////////////////////
	//if Subi is not empty, compute the labellings of each SCC in Sub0
	Iterator it = Subi.iterator();
	for(int i=0; i<Subi.size(); i++){
		
	    HashSet s; //a subset of arguments in layer i
	    s = (HashSet)it.next();
	    //System.out.println("s="+s);
	    /////////compute the set of outside parents of the set s
	    Iterator its = s.iterator();
	    HashSet sAffecting = new HashSet();
	    //求出L-，即把s中所有节点的父节点加入sAffecting
	    while(its.hasNext()){
		    int y = (Integer)its.next(); //y is an argument of s
		    HashSet Ps;
		    Ps = (HashSet)Parents[y].clone();
		    //System.out.println("Ps="+Ps);
		    Ps.removeAll(s); // the outside parents of argument y
		    //System.out.println("post-Ps="+Ps);
		    sAffecting.addAll(Ps);
	    }
	    //System.out.println("sAffecting="+sAffecting);
	    
        HashSet in, out, undec;
        out = (HashSet)L0.second.clone(); //the status of arguments in L0
        out.retainAll(sAffecting);
        undec = (HashSet)L0.third.clone();
        undec.retainAll(sAffecting);
        //把s中所有节点改为in
        in = (HashSet)s.clone();
        //把s父节点中的in加入IN中
        HashSet I, J;
        I = (HashSet)L0.first.clone();
        I.retainAll(sAffecting);
        in.addAll(I); 
      
        J = (HashSet)L0.third.clone();
        J.retainAll(sAffecting);
        //System.out.println("Conditioning undec="+J);
      
    
        ThreeTuple<HashSet, HashSet, HashSet> L = new ThreeTuple<HashSet, HashSet, HashSet>(in, out, undec);
        //System.out.println("L="+L);
      
        HashSet[] labellings;
        labellings = new HashSet[Subi.size()+1];
    
        HashSet Candidatelabellings;
        Candidatelabellings = new HashSet();
        //System.out.println("Candidatelabellings: "+Candidatelabellings);
//测试加入基语义算法
//        ThreeTuple<HashSet,HashSet,HashSet> tlabelling;
//        tlabelling=new FingGroundedLabellings().GetGroundedLabellings(L,Children,Parents,Subi);
        System.out.println("Subi="+Subi);
        labellings[i] = new FindPreferredLabellings().GetLabellings(L, Children, Parents, Candidatelabellings, I, J);
        //？？？为什么preferlabelling只返回一个
      
        //System.out.println("labellings["+i+"]: "+labellings[i]);
      
        if(!Comb.isEmpty()){
        	//该lv下存在基标记，合并基标记与当前求出的优先标记
	        Iterator it1 = Comb.iterator();
	        while(it1.hasNext()){
	        	ThreeTuple<HashSet, HashSet, HashSet> L3;
	        	L3 = (ThreeTuple<HashSet, HashSet, HashSet>)it1.next();
	          
	        	HashSet Cin, Cout, Cundec;  
	        	Iterator it2 = labellings[i].iterator();
	        	while(it2.hasNext()){
	        		ThreeTuple<HashSet, HashSet, HashSet> L4;
	        		L4 = (ThreeTuple<HashSet, HashSet, HashSet>)it2.next();
	
	        		Cin = (HashSet)L3.first.clone();
	        		Cout = (HashSet)L3.second.clone();
	        		Cundec = (HashSet)L3.third.clone();
	        		Cin.addAll(L4.first);
	        		Cout.addAll(L4.second); 
	        		Cundec.addAll(L4.third); 
	    
	        		ThreeTuple<HashSet, HashSet, HashSet> L5 = new ThreeTuple<HashSet, HashSet, HashSet>(Cin, Cout, Cundec);
	        		//System.out.println("L5: "+L5); 
	        		Comb1.add(L5);
	        	} 
	        }
	        Comb.clear();
	        Comb = (ArrayList)Comb1.clone();
	        Comb1.clear();
	        //System.out.println("!!!");
        }
        else{
        Comb.addAll(labellings[i]);
        }
    }

   /*  Iterator itc = Comb.iterator();
     if(Comb.isEmpty()){
     System.out.println("!!!!!!!");
     }
     
     while(itc.hasNext()){
       System.out.println("Labelling: "+itc.next().toString()); 
    
     }*/
    
   //   System.out.println("here");
   //   System.out.println("L0="+L0);
   //   System.out.println("Comb="+Comb);
      
    //combine the extensions of layer i-1 to those of layer i
    ArrayList Comb2 = new ArrayList(); 
    // ArrayList Comb3 = new ArrayList();  // to store the middle data
    Iterator it3 = Comb.iterator();
    HashSet Cin1, Cout1, Cundec1;  
    while(it3.hasNext()){ //take a labelling from Comb
        ThreeTuple<HashSet, HashSet, HashSet> L8; //used to store the labelling
        L8 = (ThreeTuple<HashSet, HashSet, HashSet>)it3.next();
        Cin1 = (HashSet)L0.first.clone();
        Cout1= (HashSet)L0.second.clone();
        Cundec1 = (HashSet)L0.third.clone();
        Cin1.addAll(L8.first);//HashSet使用add重复的自动只选一个
        Cout1.addAll(L8.second);
        Cundec1.addAll(L8.third); 
        
        ThreeTuple<HashSet, HashSet, HashSet> L9 = new ThreeTuple<HashSet, HashSet, HashSet>(Cin1, Cout1, Cundec1);
        //System.out.println("L9: "+L9); 
        Comb2.add(L9);
    }
    //System.out.println("Comb2: "+Comb2); 
    return Comb2;   
    }
}
