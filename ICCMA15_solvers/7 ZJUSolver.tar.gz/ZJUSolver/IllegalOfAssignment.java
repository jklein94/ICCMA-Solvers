

import java.util.HashSet;
import java.util.Iterator;

/**
 *
 * @author beishui
 */
public class IllegalOfAssignment {
    // Px denotes the parents of x
	//判断是否为legalin，即没有父节点或者父节点均为空
    public boolean legalIn(ThreeTuple<HashSet,HashSet,HashSet> L, int x, HashSet Px){
    boolean lin =false;
    HashSet In = L.first;
    HashSet Out = L.second;
    if(In.contains(x)){ //x is labelled IN
       // System.out.println("Liao111");
       //  System.out.println("P["+x+"]="+Px);
     if(Px.isEmpty()){ //every y that attacks x is labelled OUT
       //   System.out.println("Liao2");
       lin = true;
     }
     else{
       if(Out.containsAll(Px)){
    //   System.out.println("Liaotest");
    //    System.out.println("P["+x+"]="+Px);
        lin = true;
       }
     }
     
    }
    return lin;
    }
    
    //判断是否是legalout，即父节点没有in
    public boolean legalOut(ThreeTuple<HashSet,HashSet,HashSet> L, int x, HashSet Px){
	    boolean lout=false;
	    HashSet In = L.first;
	    HashSet Out = L.second;
	    
	    if(Out.contains(x)){ //x is labelled OUT
		    // System.out.println(x+" is labeled out");
		    HashSet InCopy = (HashSet)In.clone();
		    InCopy.retainAll(Px);
		    if(!InCopy.isEmpty()){  //there is at least one y that attacks x and Y is labeled IN
		    	lout = true;
		    	// System.out.println(x+" is legal out");
		    }
	    }
	    return lout;
    }
    
    public boolean legalUndec(ThreeTuple<HashSet,HashSet,HashSet> L, int x, HashSet Px){
    boolean lundec=false;
    HashSet In = L.first;
    HashSet Out = L.second;
    HashSet Undec = L.third;
    
    if(Undec.contains(x)){ //x is labelled Undec
      // System.out.println(x+" is labeled Undec");
     HashSet UndecCopy = (HashSet)Undec.clone();
     HashSet InCopy = (HashSet)In.clone();
     InCopy.retainAll(Px);
     if(InCopy.isEmpty()){  //there 
       if(Out.containsAll(Px)){
       }
       else{
       lundec = true;
      // System.out.println(x+" ");
       }
     }
    }
    return lundec;
    }
    
    //判断是否为illegalin，即非legalin
    public boolean IllegalIn(ThreeTuple<HashSet,HashSet,HashSet> L, int x, HashSet Px){
    boolean Ill=false;
    HashSet In = L.first;
    if(In.contains(x)){ //x is labelled IN
     if(!legalIn(L, x, Px)){ //every y that attacks x is labelled OUT
       Ill = true;
     }
    }
    return Ill;
    }
    
    //判断superillegalin，即父节点有legalin或legalundec
    public boolean SuperIllegalIn(ThreeTuple<HashSet,HashSet,HashSet> L, int x, HashSet[] P, HashSet ConditioningIN, HashSet ConditioningUndec){
    boolean SIll=false;
    if(IllegalIn(L, x, P[x])){
	    //System.out.println("here");
	    Iterator it = P[x].iterator();
	    for(int i=0; i<P[x].size(); i++){
	    	int y = (Integer)it.next();
	    	//System.out.println("!!!liao y="+y);
	    		if(legalIn(L, y, P[y])){
	    			//System.out.println("y is legally in");
	    			SIll=true;
	    		}
	    		if(legalUndec(L, y, P[y])){
	    			SIll=true;
	    			//System.out.println(y+ " is legally undec");
	    		}
	    		if(ConditioningIN.contains(y)){
	    			SIll=true;
	    		}
	    		if(ConditioningUndec.contains(y)){
	    			SIll=true;
	    		}
	    
	    }
    } 
    
    return SIll;
    }
    
    //判断是否illegalout，即非legalout
    public boolean IllegalOut(ThreeTuple<HashSet,HashSet,HashSet> L, int x, HashSet Px){
    boolean Ill=false;
    HashSet In = L.first;
    HashSet Out = L.second;
    //System.out.println("Liao1");
    if(Out.contains(x)){ //x is labelled OUT
     if(!legalOut(L, x, Px)){ //every y that attacks x is labelled OUT
    //  System.out.println(x+ " is not legal out");
       Ill = true;
     }
    }
    return Ill;
    }
}
