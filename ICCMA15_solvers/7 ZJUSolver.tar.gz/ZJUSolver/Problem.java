

import java.util.Collection;
import java.util.HashSet;
import java.util.StringTokenizer;



/**
 * This enum contains all supported problems.
 * 
 * @author Matthias Thimm
 */
public enum Problem {

	EE_GR (SubProblem.EE, Semantics.GR),
	EE_PR (SubProblem.EE, Semantics.PR),
	EL_GR (SubProblem.EL, Semantics.GR),
	EL_PR (SubProblem.EL, Semantics.PR);
	
	/**
	 * The actual computational sub-problem.
	 * @author Matthias Thimm
	 */
	public enum SubProblem{
		EE ("Enumerate extension","EE"),
		EL ("Enumerate labeling","EL");
		
		/** The description of the sub-problem. */
		private String description;
		/** The abbreviation of the sub-problem. */
		private String abbreviation;
		
		/**
		 * Creates a new sub-problem
		 * @param description some description.
		 * @param abbreviation the abbreviation of the sub-problem.
		 */
		private SubProblem(String description, String abbreviation){
			this.description = description;
			this.abbreviation = abbreviation;
		}
		/**
		 * Returns the description of the sub-problem.
		 * @return the description of the sub-problem.
		 */
		public String description(){
			return this.description;
		}
		/**
		 * Returns the abbreviation of the sub-problem.
		 * @return the abbreviation of the sub-problem.
		 */
		public String abbreviation(){
			return this.abbreviation;
		}
	};
	
	/** The description of the problem. */
	private SubProblem subProblem;
	/** The semantics for the problem. */
	private Semantics semantics;
		
	/**
	 * Creates a new problem.
	 * @param subProblem the sub-problem
	 * @param semantics the semantics.
	 */
	private Problem(SubProblem subProblem, Semantics semantics){
		this.subProblem = subProblem;
		this.semantics = semantics;
	}
	
	/**
	 * Returns the sub-problem of the problem.
	 * @return the sub-problem of the problem.
	 */
	public SubProblem subProblem(){
		return this.subProblem;
	}
	
	/**
	 * Returns the semantics of the problem.
	 * @return the semantics of the problem.
	 */
	public Semantics semantics(){
		return this.semantics;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Enum#toString()
	 */
	public String toString(){
		return this.subProblem.abbreviation() + "-" + this.semantics.abbreviation();
	}
	
	/**
	 * Returns the problem instance that corresponds to the given abbreviation.
	 * @param s some string representing a problem instance
	 * @return the actual problem
	 */
	public static Problem getProblem(String s){
		s = s.trim();
		for(Problem p: Problem.values())
			if(s.equals(p.toString()))
				return p;		
		return null;
	}
	
	/**
	 * Returns a collection of problems parsed from the given string which
	 * has to be in the format "[problem1,...,problemn]".
	 * @param s some string
	 * @return a collection of problems
	 */
	public static Collection<Problem> getProblems(String s){
		s = s.trim();
		if(!s.startsWith("[") || !s.endsWith("]"))
			throw new IllegalArgumentException("Malformed problem specification: " + s);
		s = s.substring(1, s.length()-1);
		StringTokenizer tokenizer = new StringTokenizer(s, ",");
		Collection<Problem> problems = new HashSet<Problem>();
		while(tokenizer.hasMoreTokens()){
			 problems.add(Problem.getProblem(tokenizer.nextToken()));
		}
		return problems;
	}
}
