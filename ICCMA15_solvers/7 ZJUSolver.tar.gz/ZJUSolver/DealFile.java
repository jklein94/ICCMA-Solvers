import java.util.ArrayList;
import java.util.HashSet;

//gqle
public abstract class DealFile {
	public static ArrayList<String> strSet;
	public static int index;
	
	public static ArrayList<String>[] headnums;
	public static ArrayList<Integer> strlen;
	public static String[] checkList;
	
	public static void init(){
		index=-1;
		strSet=new ArrayList<String>();
	}
	
	public static int initSet(String x){
		strSet.add(x.trim());
		index++;
		return getInt(x);
	}
	
	public static int getInt(String x){
		return strSet.indexOf(x.trim());
	}
	
	public static String getString(int x){
		return strSet.get(x).trim();
	}
}
