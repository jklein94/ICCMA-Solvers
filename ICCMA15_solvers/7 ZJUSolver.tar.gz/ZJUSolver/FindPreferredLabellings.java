

import java.util.HashSet;
import java.util.Iterator;

/**
 *
 * @author beishui
 */
 
public class FindPreferredLabellings {
   HashSet candidatelabellings;
 //  candidatelabellings = new HashSet();
   long begin2 = System.currentTimeMillis();  
    
    public HashSet GetLabellings(ThreeTuple<HashSet,HashSet,HashSet> L, HashSet[] C, HashSet[] P, HashSet Cand, HashSet Condition, HashSet CondUndec){
    candidatelabellings = Cand;     //Condition is the set of conditioning arguments whose status is IN
 //   System.out.println("pre-candidatelabellings =" + candidatelabellings);
    //如果之前找到的答案当前一步大，直接返回
    if(!candidatelabellings.isEmpty()){  //if L is worse than an existing cadidate labelling then prune the search tree
       Iterator it = candidatelabellings.iterator(); //and backtrack to select another argument for performing a transition step
       for(int i=0; i<candidatelabellings.size(); i++){
          ThreeTuple<HashSet,HashSet,HashSet> L1 = (ThreeTuple<HashSet,HashSet,HashSet>)it.next();
          //boolean eq= new SetEqual().Equal(L1.first, L.first);
          if(L1.first.containsAll(L.first)){
             // System.out.println(L1.first+"containsAll"+L.first);
              return candidatelabellings;
          }
       }
    }
    // if the transition sequence has terminated
    HashSet In = L.first;
 //   System.out.println("second");
    HashSet Illin, SIllin;
    Illin = new HashSet();
    SIllin = new HashSet();
    if(!In.isEmpty()){   //get the set of arguments that are illegally IN
     //   System.out.println("Third");
       Iterator Itin = In.iterator();
       for(int i=0; i<In.size(); i++){
          int x = (Integer)Itin.next();
        //   System.out.println("????L= "+L);
          if(new IllegalOfAssignment().IllegalIn(L, x, P[x])){
            //   System.out.println("illigal of "+x);
              if(new IllegalOfAssignment().SuperIllegalIn(L, x, P, Condition, CondUndec)){
              //    System.out.println("condition="+Condition);
                  if(!Condition.contains(x)){
                     SIllin.add(x);
                     Illin.add(x);
                  //  System.out.println("add "+x);
                  }
              }
             else{
                  if(!Condition.contains(x)){  //exclude the conditioning arguments whose status is IN
                  Illin.add(x);
                  }
                 // System.out.println("six");
              }
          }
       }
    //   System.out.println("Illin:"+Illin);
    //    System.out.println("SIllin:"+SIllin);
    }
    
    //L中的in全部合法，检验是否比现有结果candid中更优，替换
    if(Illin.isEmpty()){  //if L does not have an argument that is illegally IN
     //   System.out.println("Illin is Empty");
        if(!candidatelabellings.isEmpty()){
      //    System.out.println("hello");
          Iterator it2 = candidatelabellings.iterator();
          HashSet del = new HashSet(); //in order to invoice the error of deleing a list when it is searched
          for(int i=0; i<candidatelabellings.size(); i++){  
            ThreeTuple<HashSet,HashSet,HashSet> L1 = (ThreeTuple<HashSet,HashSet,HashSet>)it2.next();
        //    System.out.println("L1="+L1);
        //    System.out.println("L="+L);
             // if L1's IN arguments are a strict subset of L's IN arguments
             // then remove L1
            boolean eq1= new SetEqual().Equal(L1.first, L.first);
            if(L.first.containsAll(L1.first)){
            	del.add(L1);
            	//candidatelabellings.remove(L1);
            	//return candidatelabellings;
            }
          }
          candidatelabellings.removeAll(del);
          del.clear();
        }
        // add L as a new candidate
        //System.out.println(L+" will be added to  "+candidatelabellings);
         
         candidatelabellings.add(L);
         
         	//System.out.println("!!candidatelabellings =" + candidatelabellings);
         
    }
    else{
    	//System.out.println("seventh");
    	//存在superillegalin，递归其中一个
    	if(!SIllin.isEmpty()){ //if L has an argument that is super-illegally IN  如果L包含superillegallyin
    		//System.out.println("super-illegally");
    		int x = (Integer)SIllin.iterator().next();
    		//System.out.println("x= "+x);
            HashSet in, out, undec;
            in = (HashSet)L.first.clone();
            out = (HashSet)L.second.clone();
            undec = (HashSet)L.third.clone();
            ThreeTuple<HashSet, HashSet, HashSet> L5 = new ThreeTuple<HashSet, HashSet, HashSet>(in, out, undec);
            //System.out.println("L5= "+L5);
            ThreeTuple<HashSet,HashSet,HashSet> L2 = new TransitionStep().getTransition(L5, x, C, P); 
            //System.out.println("L2= "+L2);
            GetLabellings(L2, C, P, candidatelabellings, Condition, CondUndec);
    	} 
        else{
        	//System.out.println("illegally");
        	//存在illegalin，递归所有
        	if(!Illin.isEmpty()){
	            Iterator it3 = Illin.iterator();
	            for(int i=0; i<Illin.size(); i++){
	            	int y = (Integer)it3.next();
	            	//System.out.println("y="+y);
	            	//System.out.println("!!L is:"+L);
	            	//preserve the state of L
	            	HashSet in1, out1, undec1;
	            	in1 = (HashSet)L.first.clone();
	             	out1 = (HashSet)L.second.clone();
	             	undec1 = (HashSet)L.third.clone();
	             	ThreeTuple<HashSet, HashSet, HashSet> L6 = new ThreeTuple<HashSet, HashSet, HashSet>(in1, out1, undec1);
	             	ThreeTuple<HashSet,HashSet,HashSet> L1 = new TransitionStep().getTransition(L6, y, C, P); 
	             	//System.out.println("L1 is:"+L1);
//测试时间
//	             	long end2 = System.currentTimeMillis();  
//	             	if(end2-begin2>600000){
//	             		HashSet error;
//	             		error = new HashSet();
//	             		System.out.println("exceeds 3...");
//	             		break;
//	             	}
	             	GetLabellings(L1, C, P, candidatelabellings, Condition, CondUndec);
	            }
        	}
        }    
    }
    return candidatelabellings;
    } 
}
