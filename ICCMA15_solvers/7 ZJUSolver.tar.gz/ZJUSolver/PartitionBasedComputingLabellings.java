

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

/**
 *
 * @author beishui
 */
public class PartitionBasedComputingLabellings {
   public ArrayList GetPartionBasedLabellings(int argumentNumber, HashSet Args, int[][]attacks, HashSet[] Parents, HashSet[] Children){
      // int sccsize=0;
       HashSet SCCS, SCCS2;
       HashSet SCC;
       SCCS = new ComputeSCCS().getSCCS(argumentNumber, Args, attacks); //所有强连通分量的集合 size=强连通分支数量
       SCCS2 = (HashSet)SCCS.clone();
   
       //System.out.println("SCCS size:"+SCCS.size());
     //  sccsize = sccsize + SCCS.size();  
       /////////////////////////////////////////
       //get ordered SCCS
       //assigned levels

   
   
       HashSet[] S, C, sccpar;
       S = new HashSet[SCCS.size()+1]; //the set of SCCs 
       C = new HashSet[argumentNumber+1]; //c[x] 为x点所连得的连通分支
       sccpar = new HashSet[SCCS.size()+1]; //the outside parents of each SCC
       int k;
       Iterator it = SCCS.iterator();
       for(int i=0; i<SCCS.size(); i++){
            sccpar[i]= new HashSet();
       }


       for(int i=0; i<SCCS.size(); i++){   //the set of SCCs
	       //System.out.println("pre-S["+i+"]="+S[i]);
	       S[i] = (HashSet)it.next(); //SCCS = {S1, S2, ..., Sn}
	       //System.out.println("S["+i+"]="+S[i]);
	       Iterator it2 = S[i].iterator();
	       for(int j=0; j<S[i].size(); j++){
	          k = (Integer)it2.next(); 
	          C[k] = S[i]; //link each argument to an SCC
	          //System.out.println("C["+k+"]="+C[k]);   
	       }
       }
       //System.out.println("-------------");
       for(int i=0; i<argumentNumber; i++){
         for(int j=0; j<argumentNumber; j++){
	         if(attacks[i][j]==1){
	        	 //System.out.println("attacks["+i+"]["+j+"]="+attacks[i][j]);
	        	 if(C[i]!=C[j]){//i和j不在同一个分支中
		              for(int m=0; m<SCCS.size(); m++){
		                 if(C[j]==S[m]){  
			                 //System.out.println("S["+m+"]="+S[m]);  
			                 sccpar[m].add(C[i]); //the SCCpar of the father SCC 
			                 //sccpar[m]代表了强连通分支SCCS[m]的父强连通分支集合
			                 //System.out.println("sccpar["+m+"]="+sccpar[m]);   
		                 }
		              }
	            }
	         }
         }
       }
       
    //nontrivialness of SCCS
    //检验是单点分量还是一块联通分支
    boolean[] nontriv;
    nontriv = new boolean[SCCS.size()+1];
    for(int i=0; i<SCCS.size(); i++){
	    nontriv[i] = new Nontrivial().nontrivial(S[i], attacks);
	    if(nontriv[i]){
	    // System.out.println(i+" is nontrivial"); 
	     }
    }
   
    //确定每个连通分支的位置，在第几层
    int maxlev=0;
    int[] lv;
    lv = new PositionOfSCC().getPosition(SCCS, sccpar, S, attacks, nontriv);
    for(int i=0; i<SCCS2.size(); i++){  //The the size of SCCS has been changed to zero in the procedure of getPosition
     //System.out.println("level["+i+"]="+lv[i]);  
        maxlev = Math.max(maxlev, lv[i]);
    }
    
    //根据深度分层，把相应的强连通分支放入相应的层数（lv）中
    //Sub强连通分支的分层；U单点的分层；Sub[i]表示第i曾所有的连通分支
    HashSet[] Sub= new SubAF().getNontrivialSubF(SCCS2.size(), lv, nontriv, S, maxlev);
    //sets of trivial arguments in layer 0 - maxlev
    HashSet[] U = new SubAF().getTrivialSubF(SCCS2.size(), lv, nontriv, S, maxlev);
    for(int i=0; i<=maxlev; i++){
     //System.out.println("prepre-U["+i+"]="+U[i]); 

    }
    
    //provide first labelling
    HashSet in, out, undec;
    in = new HashSet();
    out = new HashSet();
    undec = new HashSet();
    for(int i=1; i<=8; i++){
    	//？？？为什么只有8个
    	in.add(i);
    }
    
   
    //compute the labellings of layer 0-maxlev
    ArrayList Comb;
    
    Comb = new Compute_Combine().GetLabellings(Sub, U, Parents, Children, maxlev);
    return Comb;
    }
}

