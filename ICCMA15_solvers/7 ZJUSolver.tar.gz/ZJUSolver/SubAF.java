

import java.util.HashSet;

/**
 *
 * @author beishui
 */
public class SubAF {
public HashSet[] getNontrivialSubF(int SCCSSize, int[] lv, boolean[] nontriv, HashSet[] S, int maxlev){
HashSet[] Sub= new HashSet[maxlev+2];
//System.out.println("guo"); 
for(int i=0; i<=maxlev; i++)
{
   Sub[i] = new HashSet();
}

for(int i=0; i<SCCSSize; i++){
    //System.out.println("test2"); 
    //System.out.println("S["+i+"]="+S[i]); 
    if(nontriv[i]){
    	//System.out.println("S["+i+"] is nontrivial"); 
    Sub[lv[i]].add(S[i]);
    }
    
 
}
//System.out.println("Pre-U0:"+ U0); 
return Sub;
}

public HashSet[] getTrivialSubF(int SCCSSize, int[] lv, boolean[] nontriv, HashSet[] S, int maxlev){
HashSet[] U = new HashSet[maxlev+2];
//System.out.println("guo"); 
for(int i=0; i<=maxlev; i++)
{
   U[i] = new HashSet();
}

for(int i=0; i<SCCSSize; i++){
    if(!nontriv[i]){
    	//System.out.println("level of "+i+"is "+lv[i]); 
    	U[lv[i]].addAll(S[i]);
    	//System.out.println("lv="+lv[i]+"："+S[i]);
    }
    
 
}
//System.out.println("Pre-U0:"+ U0); 
return U;
}

}
