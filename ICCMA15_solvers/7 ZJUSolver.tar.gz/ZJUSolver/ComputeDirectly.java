/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */



import java.util.HashSet;

/**
 *
 * @author beishui
 */
public class ComputeDirectly {
   public HashSet getSemantics(HashSet Args, HashSet[] Children, HashSet[] Parents){
    
  /*  HashSet A=new HashSet();
    for(int i=1; i<=argumentNumber; i++){
    A.add(i);
    }*/
      
 //初始化，建立in、out、und集合     
    HashSet in2, out2, undec2;
    out2= new HashSet();
    undec2 = new HashSet();
    in2 = (HashSet)Args.clone();
    
    ThreeTuple<HashSet, HashSet, HashSet> L = new ThreeTuple<HashSet, HashSet, HashSet>(in2, out2, undec2);
      
    HashSet labellings;
    HashSet Candidatelabellings;
    Candidatelabellings = new HashSet();
    HashSet Condition, ConditionUndec;
    Condition = new HashSet();
    ConditionUndec = new HashSet();
//调用优先函数程序，详见FindPreferredLabellings.java
    labellings = new FindPreferredLabellings().GetLabellings(L, Children, Parents, Candidatelabellings, Condition, ConditionUndec);
      
    
    return labellings;
    
    }
    
}
