

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

public class Execute {

    /**
     * @param args the command line arguments
     * @throws IOException 
     */
public ArrayList ExecutePR(File file,FileFormat type) throws IOException{
    int sumuniquenumber=0;
	GetGraph graph=new GetGraph(file,type);
	int argumentNumber=graph.argslength;

	HashSet[] Parents = new ParentsOfArgument().getParent(graph.attacks,argumentNumber, graph.Args);//parent是父集合，就是攻击的集合
	HashSet[] Children = new ParentsOfArgument().getChildren(graph.attacks,argumentNumber,graph.Args);//children是子集合，就是被攻击的集合
	
		
	////------------------------1分割计算-------------------------------
	////long begin1 = System.currentTimeMillis();  
	////compute the labellings of layer 0-maxlev
	//    ArrayList Comb;
	//    
	//    Comb = new PartitionBasedComputingLabellings().GetPartionBasedLabellings(argumentNumber,graph.Args,graph.attacks, Parents, Children);
	//    
	//   // System.out.println("partit="+Comb);
	//    long end1 = System.currentTimeMillis();  
	//    
	//    System.out.println("partition: " + (end1 - begin1) + " milliseconds");  
	 
	////-------------------------2直接计算-----------------------------
	////调用子框架程序ComputeDirectly，详见ComputeDirectly.java，并测试时间      
	//////compute the preferred simantics directly, without the partition-based method////
	//     long begin2 = System.currentTimeMillis();  
	//     HashSet Comb1;
	//  //   System.out.println("--------------------------------------");
	//  //   System.out.println("     ");  
	//     
	//	     
	//     Comb1 = new ComputeDirectly().getSemantics(graph.Args, Children, Parents);
	//	     Iterator cit1=Comb1.iterator();
	//	     for(int i=0;i<Comb1.size();i++){
	//	    	 System.out.println("i"+cit1.next());
	//	     }
	//  //   System.out.println("direct:"+Comb1);
	//     long end2 = System.currentTimeMillis();  
	//    System.out.println("directly: " + (end2 - begin2) + " milliseconds"); 


	//The unique-status+partition method-begin

    HashSet in1, out1, undec1;
    in1 = new HashSet();
    out1 = new HashSet();
    undec1 = new HashSet();
    
    ThreeTuple<HashSet, HashSet, HashSet> L1 = new ThreeTuple<HashSet, HashSet, HashSet>(in1, out1, undec1);
    ThreeTuple<HashSet, HashSet, HashSet> Unique;
    Unique = new FingGroundedLabellings().GetGroundedLabellings(L1, Parents, Children, graph.Args);
   
    HashSet remain;
    remain = Unique.third;
    sumuniquenumber=sumuniquenumber+remain.size();
     
    HashSet[] Parents1 = new ParentsOfArgument().getParent(graph.attacks, argumentNumber, remain);
    HashSet[] Children1 = new ParentsOfArgument().getChildren(graph.attacks, argumentNumber, remain);
     
    ArrayList Comb31,Comb32;
    
    Comb31 = new PartitionBasedComputingLabellings().GetPartionBasedLabellings(argumentNumber, remain, graph.attacks, Parents1, Children1);
    Comb32 = new ArrayList();

    if(!Comb31.isEmpty()){
		Iterator itcom = Comb31.iterator();
		for(int w=0; w<Comb31.size();w++){
			ThreeTuple<HashSet, HashSet, HashSet> Lw=(ThreeTuple<HashSet, HashSet, HashSet>)itcom.next(); 
			HashSet inw = Lw.first;
			HashSet outw = Lw.second;
			HashSet undecw = Lw.third;
			inw.addAll(Unique.first);
			outw.addAll(Unique.second);
			ThreeTuple<HashSet, HashSet, HashSet> L5 = new ThreeTuple<HashSet, HashSet, HashSet>(inw, outw, undecw);
			Comb32.add(L5); 
		}
    }
    else{
		Comb32.add(Unique); 
    }
		return Comb32;
    }    

public ArrayList ExecuteGR(File file,FileFormat type) throws IOException{
    int sumuniquenumber=0;
	GetGraph graph=new GetGraph(file,type);
	int argumentNumber=graph.argslength;

	HashSet[] Parents = new ParentsOfArgument().getParent(graph.attacks,argumentNumber, graph.Args);//parent是父集合，就是攻击的集合
	HashSet[] Children = new ParentsOfArgument().getChildren(graph.attacks,argumentNumber,graph.Args);//children是子集合，就是被攻击的集合

    HashSet in1, out1, undec1;
    in1 = new HashSet();
    out1 = new HashSet();
    undec1 = new HashSet();
    
    ThreeTuple<HashSet, HashSet, HashSet> L1 = new ThreeTuple<HashSet, HashSet, HashSet>(in1, out1, undec1);
    ThreeTuple<HashSet, HashSet, HashSet> Unique;
    Unique = new FingGroundedLabellings().GetGroundedLabellings(L1, Parents, Children, graph.Args);
   
    HashSet remain;
    remain = Unique.third;
    sumuniquenumber=sumuniquenumber+remain.size();
     
    HashSet[] Parents1 = new ParentsOfArgument().getParent(graph.attacks, argumentNumber, remain);
    HashSet[] Children1 = new ParentsOfArgument().getChildren(graph.attacks, argumentNumber, remain);
     
    ArrayList Comb31=new ArrayList();
    Comb31.add(Unique);
    return Comb31;

    }    
}

