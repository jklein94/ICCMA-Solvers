

import java.util.HashSet;

/**
 *
 * @author beishui
 */
public class Nontrivial {
public boolean nontrivial(HashSet scc, int[][] r){
boolean B = false;
//System.out.println("in trivial()");
/*if(scc==null){
System.out.println("scc=null");
B = true;}
else{*/
if(scc.size()>1){
B = true;
}
else{
    int k = (Integer)scc.iterator().next();//如果是自循环，也划分开来
if(r[k][k]==1){
B = true;
}
}


return B;
}
}
