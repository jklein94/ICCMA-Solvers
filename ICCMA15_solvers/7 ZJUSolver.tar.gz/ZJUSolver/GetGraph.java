
//gqle

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;



public class GetGraph {
HashSet<Integer> Args;
int[][] attacks;
int argslength;
String Type;
	
	public GetGraph(File f,FileFormat type) throws IOException{
		if(type.equals(FileFormat.TGF))
		{
			this.GetGraphTGF(f);
			this.Type="tgf";
		}
		if(type.equals(FileFormat.APX))
		{
			this.GetGraphAPX(f);
			this.Type="apx";
		}
		this.Type="none";
		
	}
	
	public  void GetGraphTGF(File f) throws IOException {
		int max=0;
		int i=0;
		this.Args=new HashSet<Integer>();
		BufferedReader in = new BufferedReader(new FileReader(f));
		String row = null;
		boolean argumentSection = true;
		DealFile.init();
		while ((row = in.readLine()) != null) {
			if(row.trim().equals(""))continue;
			if(row.trim().equals("#")){
				argumentSection = false;
				break;
			}
			if(argumentSection)
			{
				this.argslength++;
				int num=DealFile.initSet(row);
				//记录所有节点中数字最大的，以防节点不是从0开始，这样数组才不会越界。
				if(num>max)
					max=num;
				//System.out.println(num);
				this.Args.add(num);
				i++;
			}
		}
		if(max>i)
			this.argslength=max;
		else
			this.argslength=i;
		this.argslength+=1;
		this.attacks=new int[this.argslength+1][this.argslength+1];
		while ((row = in.readLine()) != null) {
			int atker=DealFile.getInt(row.substring(0, row.indexOf(" ")).trim()); //attacker number
			int atked=DealFile.getInt(row.substring(row.indexOf(" ")+1,row.length()).trim());// attacked number
			//System.out.println(atker+","+atked);
			this.attacks[atker][atked]=1;
		}
		in.close();
	}
	
	public  void GetGraphAPX(File f) throws IOException {
		int max=0;
		int i=0;
		ArrayList<Attack> atks=new ArrayList<Attack>();
		this.Args=new HashSet<Integer>();
		BufferedReader in = new BufferedReader(new FileReader(f));
		String row = null;
		DealFile.init();
		while ((row = in.readLine()) != null) {
			row=row.trim();
			if(row.equals("")) continue;
			if(row.startsWith("arg")){
				row = row.substring(3).trim();
				if(!row.endsWith(".")){
					in.close();
					throw new IOException("\"arg(ARGUMENT).\" expected, found " + row);
				}
				row = row.substring(0,row.length()-1).trim();
				if(!row.startsWith("(") || !row.endsWith(")")){
					in.close();
					throw new IOException("\"arg(ARGUMENT).\" expected, found " + row);
				}
				row = row.substring(1,row.length()-1).trim();							
				int num=DealFile.initSet(row);
				this.Args.add(num);
				i++;
				if(num>i)
					this.argslength=num;
				else
					this.argslength=i;
			}else if(row.startsWith("att")){
				row = row.substring(3).trim();
				if(!row.endsWith(".")){
					in.close();
					throw new IOException("\"att(ARGUMENT,ARGUMENT).\" expected, found " + row);
				}
				row = row.substring(0,row.length()-1).trim();
				if(!row.startsWith("(") || !row.endsWith(")")){
					in.close();
					throw new IOException("\"att(ARGUMENT,ARGUMENT).\" expected, found " + row);
				}
				row = row.substring(1,row.length()-1).trim();
				int attackerInt = DealFile.getInt(row.substring(0, row.indexOf(",")));
				int attackedInt = DealFile.getInt(row.substring(row.indexOf(",")+1, row.length()));
				
				Attack atk=new Attack(attackerInt,attackedInt);			
				atks.add(atk);
			}else{
				in.close();
				throw new IOException("Argument or attack declaration expected, found " + row);
			}	
			
		}
		this.argslength+=1;
		this.attacks=new int[this.argslength+1][this.argslength+1];
		Iterator<Attack> it=atks.iterator();
		while(it.hasNext()){
			Attack atk=it.next();
			this.attacks[atk.atker][atk.atked]=1;
		}
		in.close();
	}
}
