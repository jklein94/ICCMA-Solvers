

/**
 *
 * @author Guo
 */
public class Attack {
    public int atker;
    public int atked;
	
    public Attack(int a, int b) {
       this.atker = a;
       this.atked = b;
	}
    @Override
    public String toString(){
         return "("+this.atker+","+this.atked+")";
      }

}

