

import java.io.File;
import java.io.IOException;
import java.util.Collection;

public class Solver {
	public static void main(String[] args) throws IOException{
//		args = new String[8];
//		args[0] = "--formats";
//		args[1] = "EE-GR";
//		args[2] = "-f";
//		args[3] = "src/examples/rdm20_0.tgf";
//		args[4] = "-fo";
//		args[5] = "tgf";
//		args[6] = "-a";
//		args[7] = "";
		// if no arguments are given just print out the version info
		if(args.length == 0){
			System.out.println(new SolveFunction().versionInfo());
			return;
		}
		// for the parameter "--formats" print out the formats
		if(args[0].toLowerCase().equals("--formats")){
			System.out.println(new SolveFunction().supportedFormats());
			return;
		}
		// for the parameter "--problems" print out the formats
		if(args[0].toLowerCase().equals("--problems")){
			System.out.println(new SolveFunction().supportedProblems());
			return;
		}
		// otherwise parse for a problem
		String p = null, f = null, fo = null, a = null;
		for(int i = 0; i < args.length; i++){
			if(args[i].toLowerCase().equals("-p")){
				p = args[++i];
				continue;
			}
			if(args[i].toLowerCase().equals("-f")){
				f = args[++i];
				continue;
			}
			if(args[i].toLowerCase().equals("-fo")){
				fo = args[++i];
				continue;
			}
			if(args[i].toLowerCase().equals("-a")){
				if(i<args.length-1){
					a = args[++i];
					continue;
				}
			}
		}
		// if some parameter is missing exit with error (additional parameter is optional)
		if(p == null || f == null || fo == null){
			System.out.println("Error: unrecognized command parameters");
			return;
		}
		Problem problem = Problem.getProblem(p);
		FileFormat format = FileFormat.getFileFormat(fo);
		// check if the problem is supported		
		try {
			if(!new SolveFunction().supportedProblems().contains(problem)){
				System.out.println("Error: problem instance not supported");
				System.exit(1);
			}
			if(!new SolveFunction().supportedFormats().contains(format)){
				System.out.println("Error: file format not supported");
				System.exit(1);
			}
			new SolveFunction().solve(problem, new File(f), format, a);
		} catch (NullPointerException e){
			e.printStackTrace();
		} catch (IllegalArgumentException e){
			System.out.println("Error: unforeseen exception \"" + e.getMessage() + "\"");
		} catch (IOException e){
			System.out.println("Error: IO error in reading file " + f);			
		}				
	}
}