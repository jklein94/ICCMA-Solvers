

import java.util.HashSet;
import java.util.Iterator;
import java.util.Stack;

/**
 *
 * @author beishui
 */
public class ComputeSCCS {
    int counter = 0;
   int[] index, lowlink;
   int argn;
   int[][] attacks;
   HashSet SCCS=new HashSet();
   
  
   Stack stack = new Stack();
   
 public HashSet getSCCS(int ArgumentNumer, HashSet Args, int[][] r){
   argn=Args.size();
   index = new int[ArgumentNumer+1];
   lowlink =  new int[ArgumentNumer+1];
   attacks = new int[ArgumentNumer+1][ArgumentNumer+1];
  
   
   for(int i=0; i<ArgumentNumer; i++){
        for(int j=0; j<ArgumentNumer; j++){
           attacks[i][j] = r[i][j]; 
        } 
     }
   Iterator it = Args.iterator();
   for(int i=1; i<=argn; i++){
       int k = (Integer)it.next();
       index[k] = -1;
       lowlink[k] = -1;
      // System.out.println("lowlink"+i+":"+lowlink[i]);
   }
   Iterator it1 = Args.iterator();
   for(int i=0; i<argn; i++){//i=0改不改无所谓
      int k1=(Integer)it1.next();
      if(index[k1]==-1){
       //System.out.println("Test");   
         compSCC(k1, Args);
         
        // System.out.println("compSCC"); 
      }
   }
  // System.out.println(SCCS);
   return SCCS;
   
 }
     
  
   
  public void compSCC(int a, HashSet Args){
  
    // System.out.println("a="+a); 
     stack.push(a);  //push a Set SCCS = new HashSet();on the stack
     index[a] = counter;
     lowlink[a] = index[a];
     counter = counter +1;
   // System.out.println("stacktop"+stack.peek().toString());  
        Iterator it2 = Args.iterator();
        for(int b=0; b<argn; b++){
          int k = (Integer)it2.next();
          if(attacks[a][k]==1){   //if a attacks j
           // System.out.println("index["+b+"]="+index[b]); 
            if(index[k]==-1){
            //System.out.println("b="+b);
            compSCC(k,Args);
           // System.out.println("test3");
            lowlink[a] = Math.min(lowlink[a], lowlink[k]);
            }
            else{
            if(stack.contains(k)){
               // System.out.println("contains b="+b); 
                lowlink[a] = Math.min(lowlink[a], index[k]);
              //  System.out.println("lowlink"+a+"="+lowlink[a]);
            }
          } 
          }
        }
   
        
      //  System.out.println("speciallowlink["+a+"]="+lowlink[a]);
       if(index[a]==lowlink[a]){ 
          HashSet SCC=new HashSet();
          int c = Integer.parseInt(stack.pop().toString());// ？？？为何要转换一次
          SCC.add(c); 
          while(c!=a){
             c = Integer.parseInt(stack.pop().toString());
             SCC.add(c); 
             
             }
         
      //    System.out.println(SCC);
           
           SCCS.add(SCC);
        //  System.out.println("SCCS:"+SCCS);
         }
  }   
}
