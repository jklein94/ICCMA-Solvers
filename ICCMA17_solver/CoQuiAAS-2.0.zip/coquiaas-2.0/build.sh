# !/bin/sh

./configure && make
