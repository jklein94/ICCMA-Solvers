
#error This file is now obsolete. Instead include comstl/error/bad_interface_cast.hpp

/* Compatibility
[<[STLSOFT-AUTO:NO-DOCFILELABEL]>]
[<[STLSOFT-AUTO:NO-UNITTEST]>]
*/

/* ///////////////////////////// end of file //////////////////////////// */