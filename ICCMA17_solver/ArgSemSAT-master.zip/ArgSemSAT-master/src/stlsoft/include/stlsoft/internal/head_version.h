
#ifndef STLSOFT_INCL_STLSOFT_H_STLSOFT
#error This file can only be included implicitly by stlsoft/stlsoft.h; any other use is not supported
#endif

#define STLSOFT_HEAD_VER	_STLSOFT_VER
