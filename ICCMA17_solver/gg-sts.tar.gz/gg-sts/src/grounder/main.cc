/* main.cc */

#include <stdlib.h>
#include <iostream>

using namespace std;

#include "heading.h"
#include "parser.tab.hh"
#include "scanner.h"

// extern int yydebug;
// prototype of bison-generated parser function
int yyparse();

int main(int argc, char **argv)
{
	GG::GG_Scanner *scanner = new GG::GG_Scanner(&std::cin);
	GG::GG_Parser *parser = new GG::GG_Parser(*scanner);
	const int accept(0);
	if(parser->parse() != accept)
	{
		std::cerr << "Parse failed!!\n";
		return -1;
	}
	else
		return 0;
}

