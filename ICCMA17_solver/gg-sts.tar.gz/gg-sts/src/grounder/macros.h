
/* macros.h */

#ifndef _REL_ALGEBRA_MACROS_H
#define _REL_ALGEBRA_MACROS_H

#include "relalgebra.h"


rel_algebra_node macro_unaryTranslator(rel_algebra_node local_unaryTable, int64_t local_firstAvailableNumber);
rel_algebra_node macro_completion_cfe_bound(rel_algebra_node local_attacks01, rel_algebra_node local_attacks10, rel_algebra_node local_cte, rel_algebra_node local_cfd);
rel_algebra_node macro_completion_cte_bound(rel_algebra_node local_arguments, rel_algebra_node local_args02, rel_algebra_node local_attacks10, rel_algebra_node local_attacks21, rel_algebra_node local_cfe, rel_algebra_node local_ctd);
rel_algebra_node macro_completion_cfd_bound(rel_algebra_node local_arguments, rel_algebra_node local_args02, rel_algebra_node local_attacks10, rel_algebra_node local_attacks21, rel_algebra_node local_cfe, rel_algebra_node local_ctd);
rel_algebra_node macro_completion_ctd_bound(rel_algebra_node local_attacks01, rel_algebra_node local_attacks10, rel_algebra_node local_cte);

#endif

