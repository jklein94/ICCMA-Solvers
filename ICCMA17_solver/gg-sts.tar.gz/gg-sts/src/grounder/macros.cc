
#include "macros.h"
#include "generalized-filters.h"


rel_algebra_node macro_unaryTranslator(rel_algebra_node local_unaryTable, int64_t local_firstAvailableNumber)
{
	auto temp_5291 = [=](rel_algebra_node param_1, rel_algebra_node param_2) -> rel_algebra_node
		{
			rel_algebra_node temp_5157 = rel_algebra::trueTable();
			rel_algebra_node temp_5155 = param_1;
			temp_5157 = rel_algebra::join(temp_5157, rel_algebra::complement(temp_5155));
			rel_algebra_node temp_5156 = param_2;
			temp_5157 = rel_algebra::join(temp_5157, rel_algebra::complement(temp_5156));
			temp_5157 = rel_algebra::complement(temp_5157);
			return temp_5157;
		};
	rel_algebra_node temp_5158 = rel_algebra::trueTable();
	temp_5158 = rel_algebra::complement(temp_5158);
	rel_algebra_node temp_5292 = temp_5158;
	auto temp_5286 = [=](rel_algebra_node param_1, rel_algebra_node param_2) -> rel_algebra_node
		{
			rel_algebra_node temp_5271 = rel_algebra::trueTable();
			rel_algebra_node temp_5212 = rel_algebra::trueTable();
			int64_t temp_5188 = 0;
			int64_t temp_5189 = 1;
			int64_t temp_5210 = std::numeric_limits<ValueType>::min();
			int64_t temp_5190 = local_firstAvailableNumber;
			temp_5210 = std::max(temp_5210, temp_5190);
			rel_algebra_node temp_5197 = rel_algebra::trueTable();
			int64_t temp_5195 = 0;
			int64_t temp_5196 = 0;
			rel_algebra_node temp_5201 = rel_algebra::filterLessThanOrEqualTo(temp_5195, temp_5196, temp_5197);
			rel_algebra_node temp_5202 = param_1;
			rel_algebra_node temp_5205 = rel_algebra::complement(rel_algebra::divide(temp_5201, rel_algebra::complement(temp_5202)));
			int64_t temp_5208 = std::numeric_limits<ValueType>::min();
			for (auto local_X = rel_algebra::getUnitIterator(temp_5205); !local_X.atEnd(); ++local_X)
			{
				int64_t temp_5192 = 0;
				int64_t temp_5194 = local_X[temp_5192];
				temp_5208 = std::max(temp_5208, temp_5194);
			}
			temp_5210 = std::max(temp_5210, temp_5208);
			int64_t temp_5211 = temp_5189 + temp_5210;
			rel_algebra_node temp_5216 = rel_algebra::filterEqualTo(temp_5188, temp_5211, temp_5212);
			temp_5271 = rel_algebra::join(temp_5271, temp_5216);
			rel_algebra_node temp_5270 = rel_algebra::trueTable();
			rel_algebra_node temp_5219 = rel_algebra::trueTable();
			int64_t temp_5217 = 0;
			int64_t temp_5218 = 0;
			rel_algebra_node temp_5223 = rel_algebra::filterGreaterThan(temp_5217, temp_5218, temp_5219);
			rel_algebra_node temp_5224 = param_1;
			rel_algebra_node temp_5227 = rel_algebra::complement(rel_algebra::divide(temp_5223, rel_algebra::complement(temp_5224)));
			temp_5270 = rel_algebra::join(temp_5270, rel_algebra::complement(temp_5227));
			rel_algebra_node temp_5269 = rel_algebra::trueTable();
			rel_algebra_node temp_5250 = rel_algebra::trueTable();
			int64_t temp_5228 = 2;
			int64_t temp_5249 = std::numeric_limits<ValueType>::min();
			int64_t temp_5229 = local_firstAvailableNumber;
			temp_5249 = std::max(temp_5249, temp_5229);
			rel_algebra_node temp_5236 = rel_algebra::trueTable();
			int64_t temp_5234 = 0;
			int64_t temp_5235 = 0;
			rel_algebra_node temp_5240 = rel_algebra::filterLessThanOrEqualTo(temp_5234, temp_5235, temp_5236);
			rel_algebra_node temp_5241 = param_1;
			rel_algebra_node temp_5244 = rel_algebra::complement(rel_algebra::divide(temp_5240, rel_algebra::complement(temp_5241)));
			int64_t temp_5247 = std::numeric_limits<ValueType>::min();
			for (auto local_X = rel_algebra::getUnitIterator(temp_5244); !local_X.atEnd(); ++local_X)
			{
				int64_t temp_5231 = 0;
				int64_t temp_5233 = local_X[temp_5231];
				temp_5247 = std::max(temp_5247, temp_5233);
			}
			temp_5249 = std::max(temp_5249, temp_5247);
			rel_algebra_node temp_5254 = rel_algebra::filterEqualTo(temp_5228, temp_5249, temp_5250);
			temp_5269 = rel_algebra::join(temp_5269, temp_5254);
			rel_algebra_node temp_5264 = rel_algebra::trueTable();
			int64_t temp_5255 = 1;
			rel_algebra_node temp_5259 = param_2;
			int64_t temp_5262 = std::numeric_limits<ValueType>::max();
			for (auto local_X = rel_algebra::getUnitIterator(temp_5259); !local_X.atEnd(); ++local_X)
			{
				int64_t temp_5256 = 1;
				int64_t temp_5258 = local_X[temp_5256];
				temp_5262 = std::min(temp_5262, temp_5258);
			}
			int64_t temp_5263 = -temp_5262;
			rel_algebra_node temp_5268 = rel_algebra::filterEqualTo(temp_5255, temp_5263, temp_5264);
			temp_5269 = rel_algebra::join(temp_5269, temp_5268);
			temp_5270 = rel_algebra::join(temp_5270, rel_algebra::complement(temp_5269));
			temp_5270 = rel_algebra::complement(temp_5270);
			temp_5271 = rel_algebra::join(temp_5271, temp_5270);
			return temp_5271;
		};
	rel_algebra_node temp_5272 = rel_algebra::trueTable();
	temp_5272 = rel_algebra::complement(temp_5272);
	rel_algebra_node temp_5287 = temp_5272;
	rel_algebra_node temp_5282 = local_unaryTable;
	for (auto local_X = rel_algebra::getUnitIterator(temp_5282); !local_X.atEnd(); ++local_X)
	{
		rel_algebra_node temp_5277 = rel_algebra::trueTable();
		int64_t temp_5273 = 1;
		int64_t temp_5274 = 0;
		int64_t temp_5276 = local_X[temp_5274];
		rel_algebra_node temp_5281 = rel_algebra::filterEqualTo(temp_5273, temp_5276, temp_5277);
		temp_5287 = temp_5286(temp_5287, temp_5281);
	}
	for (auto local_X = rel_algebra::getUnitIterator(temp_5287); !local_X.atEnd(); ++local_X)
	{
		rel_algebra_node temp_5187 = rel_algebra::trueTable();
		rel_algebra_node temp_5163 = rel_algebra::trueTable();
		int64_t temp_5159 = 0;
		int64_t temp_5160 = 0;
		int64_t temp_5162 = local_X[temp_5160];
		rel_algebra_node temp_5167 = rel_algebra::filterEqualTo(temp_5159, temp_5162, temp_5163);
		temp_5187 = rel_algebra::join(temp_5187, temp_5167);
		rel_algebra_node temp_5173 = rel_algebra::trueTable();
		int64_t temp_5168 = 1;
		int64_t temp_5169 = 1;
		int64_t temp_5171 = local_X[temp_5169];
		int64_t temp_5172 = -temp_5171;
		rel_algebra_node temp_5177 = rel_algebra::filterEqualTo(temp_5168, temp_5172, temp_5173);
		temp_5187 = rel_algebra::join(temp_5187, temp_5177);
		rel_algebra_node temp_5182 = rel_algebra::trueTable();
		int64_t temp_5178 = 2;
		int64_t temp_5179 = 2;
		int64_t temp_5181 = local_X[temp_5179];
		rel_algebra_node temp_5186 = rel_algebra::filterEqualTo(temp_5178, temp_5181, temp_5182);
		temp_5187 = rel_algebra::join(temp_5187, temp_5186);
		temp_5292 = temp_5291(temp_5292, temp_5187);
	}
	return temp_5292;
}

rel_algebra_node macro_completion_cfe_bound(rel_algebra_node local_attacks01, rel_algebra_node local_attacks10, rel_algebra_node local_cte, rel_algebra_node local_cfd)
{
	rel_algebra_node temp_5302 = rel_algebra::trueTable();
	int64_t temp_5300 = 0;
	int64_t temp_5301 = 0;
	rel_algebra_node temp_5306 = rel_algebra::filterLessThanOrEqualTo(temp_5300, temp_5301, temp_5302);
	rel_algebra_node temp_5331 = rel_algebra::trueTable();
	rel_algebra_node temp_5309 = rel_algebra::trueTable();
	rel_algebra_node temp_5307 = local_attacks01;
	temp_5309 = rel_algebra::join(temp_5309, rel_algebra::complement(temp_5307));
	rel_algebra_node temp_5308 = local_attacks10;
	temp_5309 = rel_algebra::join(temp_5309, rel_algebra::complement(temp_5308));
	temp_5309 = rel_algebra::complement(temp_5309);
	temp_5331 = rel_algebra::join(temp_5331, temp_5309);
	rel_algebra_node temp_5330 = rel_algebra::trueTable();
	int64_t temp_5310 = 0;
	int64_t temp_5312 = 1;
	rel_algebra_node temp_5314 = local_cte;
	rel_algebra_node temp_5319 = generalized_filter_rename(temp_5310, temp_5312)(temp_5314);
	temp_5330 = rel_algebra::join(temp_5330, rel_algebra::complement(temp_5319));
	int64_t temp_5320 = 0;
	int64_t temp_5322 = 1;
	rel_algebra_node temp_5324 = local_cfd;
	rel_algebra_node temp_5329 = generalized_filter_rename(temp_5320, temp_5322)(temp_5324);
	temp_5330 = rel_algebra::join(temp_5330, rel_algebra::complement(temp_5329));
	temp_5330 = rel_algebra::complement(temp_5330);
	temp_5331 = rel_algebra::join(temp_5331, temp_5330);
	rel_algebra_node temp_5334 = rel_algebra::complement(rel_algebra::divide(temp_5306, rel_algebra::complement(temp_5331)));
	return temp_5334;
}

rel_algebra_node macro_completion_cte_bound(rel_algebra_node local_arguments, rel_algebra_node local_args02, rel_algebra_node local_attacks10, rel_algebra_node local_attacks21, rel_algebra_node local_cfe, rel_algebra_node local_ctd)
{
	int64_t temp_5344 = 0;
	int64_t temp_5346 = 1;
	rel_algebra_node temp_5348 = local_ctd;
	rel_algebra_node temp_5353 = generalized_filter_rename(temp_5344, temp_5346)(temp_5348);
	rel_algebra_node local_ctd1 = temp_5353;
	rel_algebra_node temp_5407 = rel_algebra::trueTable();
	rel_algebra_node temp_5357 = rel_algebra::trueTable();
	int64_t temp_5355 = 0;
	int64_t temp_5356 = 0;
	rel_algebra_node temp_5361 = rel_algebra::filterLessThanOrEqualTo(temp_5355, temp_5356, temp_5357);
	rel_algebra_node temp_5387 = rel_algebra::trueTable();
	rel_algebra_node temp_5362 = local_ctd1;
	temp_5387 = rel_algebra::join(temp_5387, temp_5362);
	rel_algebra_node temp_5365 = rel_algebra::trueTable();
	int64_t temp_5363 = 0;
	int64_t temp_5364 = 1;
	rel_algebra_node temp_5369 = rel_algebra::filterLessThanOrEqualTo(temp_5363, temp_5364, temp_5365);
	rel_algebra_node temp_5383 = rel_algebra::trueTable();
	rel_algebra_node temp_5370 = local_args02;
	temp_5383 = rel_algebra::join(temp_5383, rel_algebra::complement(temp_5370));
	rel_algebra_node temp_5371 = local_attacks21;
	rel_algebra_node temp_5372 = rel_algebra::complement(temp_5371);
	temp_5383 = rel_algebra::join(temp_5383, rel_algebra::complement(temp_5372));
	int64_t temp_5373 = 0;
	int64_t temp_5375 = 2;
	rel_algebra_node temp_5377 = local_cfe;
	rel_algebra_node temp_5382 = generalized_filter_rename(temp_5373, temp_5375)(temp_5377);
	temp_5383 = rel_algebra::join(temp_5383, rel_algebra::complement(temp_5382));
	temp_5383 = rel_algebra::complement(temp_5383);
	rel_algebra_node temp_5386 = rel_algebra::divide(temp_5369, temp_5383);
	temp_5387 = rel_algebra::join(temp_5387, temp_5386);
	rel_algebra_node temp_5390 = rel_algebra::complement(rel_algebra::divide(temp_5361, rel_algebra::complement(temp_5387)));
	temp_5407 = rel_algebra::join(temp_5407, rel_algebra::complement(temp_5390));
	rel_algebra_node temp_5406 = rel_algebra::trueTable();
	rel_algebra_node temp_5391 = local_arguments;
	temp_5406 = rel_algebra::join(temp_5406, temp_5391);
	rel_algebra_node temp_5394 = rel_algebra::trueTable();
	int64_t temp_5392 = 0;
	int64_t temp_5393 = 0;
	rel_algebra_node temp_5398 = rel_algebra::filterLessThanOrEqualTo(temp_5392, temp_5393, temp_5394);
	rel_algebra_node temp_5402 = rel_algebra::trueTable();
	rel_algebra_node temp_5399 = local_attacks10;
	rel_algebra_node temp_5400 = rel_algebra::complement(temp_5399);
	temp_5402 = rel_algebra::join(temp_5402, rel_algebra::complement(temp_5400));
	rel_algebra_node temp_5401 = local_ctd1;
	temp_5402 = rel_algebra::join(temp_5402, rel_algebra::complement(temp_5401));
	temp_5402 = rel_algebra::complement(temp_5402);
	rel_algebra_node temp_5405 = rel_algebra::divide(temp_5398, temp_5402);
	temp_5406 = rel_algebra::join(temp_5406, temp_5405);
	temp_5407 = rel_algebra::join(temp_5407, rel_algebra::complement(temp_5406));
	temp_5407 = rel_algebra::complement(temp_5407);
	rel_algebra_node temp_5408 = temp_5407;
	return temp_5408;
}

rel_algebra_node macro_completion_cfd_bound(rel_algebra_node local_arguments, rel_algebra_node local_args02, rel_algebra_node local_attacks10, rel_algebra_node local_attacks21, rel_algebra_node local_cfe, rel_algebra_node local_ctd)
{
	int64_t temp_5418 = 0;
	int64_t temp_5420 = 1;
	rel_algebra_node temp_5422 = local_cfe;
	rel_algebra_node temp_5427 = generalized_filter_rename(temp_5418, temp_5420)(temp_5422);
	rel_algebra_node local_cfe1 = temp_5427;
	rel_algebra_node temp_5481 = rel_algebra::trueTable();
	rel_algebra_node temp_5444 = rel_algebra::trueTable();
	rel_algebra_node temp_5429 = local_arguments;
	temp_5444 = rel_algebra::join(temp_5444, temp_5429);
	rel_algebra_node temp_5432 = rel_algebra::trueTable();
	int64_t temp_5430 = 0;
	int64_t temp_5431 = 0;
	rel_algebra_node temp_5436 = rel_algebra::filterLessThanOrEqualTo(temp_5430, temp_5431, temp_5432);
	rel_algebra_node temp_5440 = rel_algebra::trueTable();
	rel_algebra_node temp_5437 = local_attacks10;
	rel_algebra_node temp_5438 = rel_algebra::complement(temp_5437);
	temp_5440 = rel_algebra::join(temp_5440, rel_algebra::complement(temp_5438));
	rel_algebra_node temp_5439 = local_cfe1;
	temp_5440 = rel_algebra::join(temp_5440, rel_algebra::complement(temp_5439));
	temp_5440 = rel_algebra::complement(temp_5440);
	rel_algebra_node temp_5443 = rel_algebra::divide(temp_5436, temp_5440);
	temp_5444 = rel_algebra::join(temp_5444, temp_5443);
	temp_5481 = rel_algebra::join(temp_5481, rel_algebra::complement(temp_5444));
	rel_algebra_node temp_5447 = rel_algebra::trueTable();
	int64_t temp_5445 = 0;
	int64_t temp_5446 = 0;
	rel_algebra_node temp_5451 = rel_algebra::filterLessThanOrEqualTo(temp_5445, temp_5446, temp_5447);
	rel_algebra_node temp_5477 = rel_algebra::trueTable();
	rel_algebra_node temp_5452 = local_cfe1;
	temp_5477 = rel_algebra::join(temp_5477, temp_5452);
	rel_algebra_node temp_5455 = rel_algebra::trueTable();
	int64_t temp_5453 = 0;
	int64_t temp_5454 = 1;
	rel_algebra_node temp_5459 = rel_algebra::filterLessThanOrEqualTo(temp_5453, temp_5454, temp_5455);
	rel_algebra_node temp_5473 = rel_algebra::trueTable();
	rel_algebra_node temp_5460 = local_args02;
	temp_5473 = rel_algebra::join(temp_5473, rel_algebra::complement(temp_5460));
	rel_algebra_node temp_5461 = local_attacks21;
	rel_algebra_node temp_5462 = rel_algebra::complement(temp_5461);
	temp_5473 = rel_algebra::join(temp_5473, rel_algebra::complement(temp_5462));
	int64_t temp_5463 = 0;
	int64_t temp_5465 = 2;
	rel_algebra_node temp_5467 = local_ctd;
	rel_algebra_node temp_5472 = generalized_filter_rename(temp_5463, temp_5465)(temp_5467);
	temp_5473 = rel_algebra::join(temp_5473, rel_algebra::complement(temp_5472));
	temp_5473 = rel_algebra::complement(temp_5473);
	rel_algebra_node temp_5476 = rel_algebra::divide(temp_5459, temp_5473);
	temp_5477 = rel_algebra::join(temp_5477, temp_5476);
	rel_algebra_node temp_5480 = rel_algebra::complement(rel_algebra::divide(temp_5451, rel_algebra::complement(temp_5477)));
	temp_5481 = rel_algebra::join(temp_5481, rel_algebra::complement(temp_5480));
	temp_5481 = rel_algebra::complement(temp_5481);
	rel_algebra_node temp_5482 = temp_5481;
	return temp_5482;
}

rel_algebra_node macro_completion_ctd_bound(rel_algebra_node local_attacks01, rel_algebra_node local_attacks10, rel_algebra_node local_cte)
{
	rel_algebra_node temp_5491 = rel_algebra::trueTable();
	int64_t temp_5489 = 0;
	int64_t temp_5490 = 0;
	rel_algebra_node temp_5495 = rel_algebra::filterLessThanOrEqualTo(temp_5489, temp_5490, temp_5491);
	rel_algebra_node temp_5509 = rel_algebra::trueTable();
	rel_algebra_node temp_5498 = rel_algebra::trueTable();
	rel_algebra_node temp_5496 = local_attacks01;
	temp_5498 = rel_algebra::join(temp_5498, rel_algebra::complement(temp_5496));
	rel_algebra_node temp_5497 = local_attacks10;
	temp_5498 = rel_algebra::join(temp_5498, rel_algebra::complement(temp_5497));
	temp_5498 = rel_algebra::complement(temp_5498);
	temp_5509 = rel_algebra::join(temp_5509, temp_5498);
	int64_t temp_5499 = 0;
	int64_t temp_5501 = 1;
	rel_algebra_node temp_5503 = local_cte;
	rel_algebra_node temp_5508 = generalized_filter_rename(temp_5499, temp_5501)(temp_5503);
	temp_5509 = rel_algebra::join(temp_5509, temp_5508);
	rel_algebra_node temp_5512 = rel_algebra::complement(rel_algebra::divide(temp_5495, rel_algebra::complement(temp_5509)));
	return temp_5512;
}
