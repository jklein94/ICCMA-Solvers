
/* macros.h */

#ifndef _REL_ALGEBRA_MACROS_H
#define _REL_ALGEBRA_MACROS_H

#include "relalgebra.h"



#endif

