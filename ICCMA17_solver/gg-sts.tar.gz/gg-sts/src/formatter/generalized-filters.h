
/* generalized-filters.h */

#ifndef _GENERALIZED_FILTERS_H
#define _GENERALIZED_FILTERS_H

#include "relalgebra.h"



#endif

