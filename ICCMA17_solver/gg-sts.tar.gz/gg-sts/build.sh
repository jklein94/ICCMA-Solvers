#!/bin/bash

cd src/grounder
make clean
make
strip grounder
cp grounder ../../
cd ../..

cd src/sat-to-sat
export MROOT=`pwd`
cd core
make clean
make rs
mv graphsat_static sat-to-sat
strip sat-to-sat
cp sat-to-sat ../../../
cd ../../..

cd src/formatter
make clean
make
strip formatter
cp formatter ../../
cd ../..
