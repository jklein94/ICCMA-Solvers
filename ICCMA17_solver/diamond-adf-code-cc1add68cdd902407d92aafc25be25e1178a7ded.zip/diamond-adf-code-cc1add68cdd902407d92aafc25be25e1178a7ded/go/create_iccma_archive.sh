diamond="goDIAMOND-0.6.6"

# create temporary directory
mkdir $diamond
mkdir $diamond/src
mkdir $diamond/src/diamond
mkdir $diamond/src/diamond/inst

# copy the files with correct paths
cp build.sh $diamond/
cp Makefile $diamond/
cp README.textile $diamond/
cp iccma-diamond.sh $diamond/
cp src/diamond/diamond.go $diamond/src/diamond/
cp -r src/diamond/enc/ $diamond/src/diamond/
cp src/diamond/enc/stgD_iccma.lp $diamond/src/diamond/enc/stgD.lp
cp src/diamond/enc/show_iccma.lp $diamond/src/diamond/enc/show.lp
cp -r src/diamond/inst/iccma2017 $diamond/src/diamond/inst
cp test-iccma2017-instances.sh $diamond/

if [[ $1 == "standalone" ]]
then
    # get archives for complete packaging and offline build
    CLINGO_ARCHIVE_URL=https://github.com/potassco/clingo/releases/download/v5.0.0/clingo-5.0.0-linux-x86_64.tar.gz
    CLINGO_ARCHIVE=clingo-5.0.0-linux-x86_64.tar.gz
    GO_ARCHIVE_URL=https://storage.googleapis.com/golang/go1.7.4.linux-amd64.tar.gz
    GO_ARCHIVE=go1.7.4.linux-amd64.tar.gz
    wget $CLINGO_ARCHIVE_URL
    mv $CLINGO_ARCHIVE $diamond
    wget $GO_ARCHIVE_URL
    mv $GO_ARCHIVE $diamond
    tag="-standalone"
else
    tag=""
fi

# gzip and tar the directory
tar czf $diamond$tag.tgz $diamond/

# remove the temporary directory
rm -rf $diamond/
