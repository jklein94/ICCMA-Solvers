#!/bin/bash

diamond=./iccma-diamond.sh
problems="SE-GR SE-ID EE-CO EE-PR EE-ST EE-SST EE-STG"
instance_dir=src/diamond/inst/iccma2017
solution_dir=$instance_dir/solutions

this=$(pwd)
cd $instance_dir
instances=$(echo *.apx)
cd $this

now=$(date +%Y-%m-%d--%H-%M-%S)
logfile=testrun_$now.log

for instance in $instances
do
    for problem in $problems
    do
	full_instance=$instance_dir/$instance
	diamond_solution=$full_instance.$problem

	if [ ! -e $diamond_solution ]
	then
	    $diamond -fo apx -p $problem -f $full_instance > $diamond_solution
	fi

	# obtain solution file name
	solution=${instance%.*}.$problem
	full_solution=$solution_dir/$solution

	# check whether solution file exists
	if [ ! -e $full_solution ]
	then
	    echo "Error: Instance file name: $full_instance has no solution: $full_solution"
	    printf "Instance file name: %s has no official solution: %s\n" $full_instance $full_solution >> $logfile
	    errors="1"
	else
	    if [ ! -e $diamond_solution ]
	    then
		echo "Error: Instance file name: $full_instance has no diamond solution: $full_solution"
		printf "Instance file name: %s has no diamond solution: %s\n" $full_instance $diamond_solution >> $logfile
		errors="1"
	    else
		# compare the two files
		diamond_line=""
		while read -r line || [[ -n $line ]]
		do
		    diamond_line+=$line
		done < "$diamond_solution"

		official_line=""
		while read -r line || [[ -n $line ]]
		do
		    official_line+=$line
		done < "$full_solution"

		diamond_length=${#diamond_line}
		official_length=${#official_line}

		if [ "$diamond_length" == "$official_length" ]
		then
		    : #echo "LENGTH MATCH: $problem $instance"
		else
		    echo "INCORRECT: $problem $instance"
		    errors="1"
		    printf "Solution length mismatch for %s %s.\nExpected: %s\nObtained: %s\n" $problem $full_instance $official_line $diamond_line >> $logfile
		fi
	    fi
	fi
    done
done

if [ "$errors" == "" ]
then
    echo "################################################################################"
    echo "All tests succeeded!"
    echo "goDIAMOND seems to be working."
    echo "################################################################################"
    exit 0
else
    echo "Some tests failed. See logfile $logfile for details."
    exit 1
fi
