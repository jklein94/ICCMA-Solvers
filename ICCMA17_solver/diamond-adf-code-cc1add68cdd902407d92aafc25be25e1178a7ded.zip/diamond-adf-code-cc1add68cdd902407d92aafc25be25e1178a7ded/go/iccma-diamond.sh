#!/bin/bash
# (c)2014 Federico Cerutti <federico.cerutti@acm.org> --- MIT LICENCE
# Generic script interface to probo http://sourceforge.net/projects/probo/
# Please feel free to customize it for your own solver
# Customised by Hannes Strass, 2016


# function for echoing on standard error
echoerr()
{
	# to remove standard error echoing, please comment the following line
	echo "$@" 1>&2; 
}

################################################################
# C O N F I G U R A T I O N
# 
# this script must be customized by defining:
# 1) procedure for printing author and version information of the solver
#	(function "information")
# 2) suitable procedures for invoking your solver (function "solver");
# 3) suitable procedures for parsing your solver's output 
#	(function "parse_output");
# 4) list of supported format (array "formats");
# 5) list of supported problems (array "problems").

# output information
function information
{
	echo "goDIAMOND 0.6.6"
	echo "Hannes Strass <strass@informatik.uni-leipzig.de>"
	echo "Stefan Ellmauthaler"
}

# how to invoke your solver: this function must be customized
function solver
{
	fileinput=$1	# input file with correct path

	format=$2	# format of the input file (see below)

	problem=$3    	# problem to solve (see below)

	additional=$4	# additional information, i.e. name of an argument


	# dummy output
	echoerr "input file: $fileinput"
	echoerr "format: $format"
	echoerr "problem: $problem"
	echoerr "additional: $additional"

	######################################################################
	## some abbreviations
	this="$(dirname $0)"
	clingo="$this/clingo-5.0.0-linux-x86_64/clingo"
	diamond="$this/src/diamond/diamond -c $clingo -d $this/src/diamond/enc -af -q "
	argument="$additional"

	######################################################################
	## ENUMERATION
	if [ "$format" = "apx" -a "$problem" = "EE-PR" ]
	then
	    $diamond -all -prf "$fileinput"
	elif [ "$format" = "apx" -a "$problem" = "EE-ST" ]
	then
	    $diamond -all -mod "$fileinput"
	elif [ "$format" = "apx" -a "$problem" = "EE-CO" ]
	then
	    $diamond -all -com "$fileinput"
	elif [ "$format" = "apx" -a "$problem" = "EE-GR" ]
	then
	    $diamond -all -mgrd "$fileinput"
	elif [ "$format" = "apx" -a "$problem" = "EE-SST" ]
	then
	    $diamond -all -sem "$fileinput"
	elif [ "$format" = "apx" -a "$problem" = "EE-STG" ]
	then
	    $diamond -all -stg "$fileinput"
	######################################################################
	## EXISTENCE
	elif [ "$format" = "apx" -a "$problem" = "SE-PR" ]
	then
	    $diamond -one -prf "$fileinput"
	elif [ "$format" = "apx" -a "$problem" = "SE-ST" ]
	then
	    $diamond -one -mod "$fileinput"
	elif [ "$format" = "apx" -a "$problem" = "SE-CO" ]
	then
	    $diamond -one -com "$fileinput"
	elif [ "$format" = "apx" -a "$problem" = "SE-GR" ]
	then
	    $diamond -one -mgrd "$fileinput"
	elif [ "$format" = "apx" -a "$problem" = "SE-SST" ]
	then
	    $diamond -one -sem "$fileinput"
	elif [ "$format" = "apx" -a "$problem" = "SE-STG" ]
	then
	    $diamond -one -stg "$fileinput"
	elif [ "$format" = "apx" -a "$problem" = "SE-ID" ]
	then
	    $diamond -one -idl "$fileinput"
	######################################################################
	## CREDULOUS
	elif [ "$format" = "apx" -a "$problem" = "DC-PR" ]
	then # credulous preferred is credulous admissible
	    $diamond -adm -cred -a "$argument" "$fileinput"
	elif [ "$format" = "apx" -a "$problem" = "DC-ST" ]
	then
	    $diamond -mod -cred -a "$argument" "$fileinput"
	elif [ "$format" = "apx" -a "$problem" = "DC-CO" ]
	then
	    $diamond -com -cred -a "$argument" "$fileinput"
	elif [ "$format" = "apx" -a "$problem" = "DC-GR" ]
	then
	    $diamond -mgrd -cred -a "$argument" "$fileinput"
	elif [ "$format" = "apx" -a "$problem" = "DC-SST" ]
	then
	    $diamond -sem -cred -a "$argument" "$fileinput"
	elif [ "$format" = "apx" -a "$problem" = "DC-STG" ]
	then
	    $diamond -stg -cred -a "$argument" "$fileinput"
	elif [ "$format" = "apx" -a "$problem" = "DC-ID" ]
	then
	    $diamond -idl -cred -a "$argument" "$fileinput"
	######################################################################
	## SCEPTICAL
	elif [ "$format" = "apx" -a "$problem" = "DS-PR" ]
	then
	    $diamond -prf -scep -a "$argument" "$fileinput"
	elif [ "$format" = "apx" -a "$problem" = "DS-ST" ]
	then
	    $diamond -mod -scep -a "$argument" "$fileinput"
	elif [ "$format" = "apx" -a "$problem" = "DS-CO" ]
	then # sceptical complete is sceptical grounded
	    $diamond -mgrd -scep -a "$argument" "$fileinput"
	elif [ "$format" = "apx" -a "$problem" = "DS-GR" ]
	then
	    $diamond -mgrd -scep -a "$argument" "$fileinput"
	elif [ "$format" = "apx" -a "$problem" = "DS-SST" ]
	then
	    $diamond -sem -scep -a "$argument" "$fileinput"
	elif [ "$format" = "apx" -a "$problem" = "DS-STG" ]
	then
	    $diamond -stg -scep -a "$argument" "$fileinput"
	elif [ "$format" = "apx" -a "$problem" = "D3" ]
	then
	    $diamond -d3 "$fileinput"
	else
	    echoerr "unsupported format or problem"
	    exit 1
	fi
}


# how to parse the output of your solver in order to be compliant with probo:
# this function must be customized
# probo accepts solutions of the form:
#	[arg1,arg2,...,argN] 		  for extension existence (SE) and argument enumeration (EC, ES)
#	[[arg1,arg2,...,argN],[...],...]  for extension enumeration (EE)
#	YES/NO				  for decision problems (DC, DS)
function parse_output
{
	problem=$1
	solver_output=$2
	this_output=""
	left_delimiter=""

	tregex="t([:alphanum:]*)"
	fregex="f([:alphanum:]*)"
	uregex="u([:alphanum:]*)"
	
	if [[ "$problem" == "SE-PR" || "$problem" == "SE-ST" || "$problem" == "SE-CO" || "$problem" == "SE-GR" || "$problem" == "SE-SST" || "$problem" == "SE-STG" || "$problem" == "SE-ID" ]]
	then
	    # type="SE"
	    # parse either (1) one line and satisfiable, or (2) unsatisfiable
	    # output (1) the extension, or (2) NO
	    this_output="["
	    while IFS= read -r line || [[ -n $line ]]
	    do
		if [[ "$line" == "UNSATISFIABLE" ]]
		then
		    this_output="NO"
		elif [[ "$line" == "SATISFIABLE" ]]
		then
		    # close the open bracket
		    this_output+="]"
		else
		    for atom in $line
		    do
			if [[ $atom =~ $tregex ]]
			then
			    next=${atom:2}
			    this_output+="${left_delimiter}${next%?}" # remove last character, ")", from next, that is, t(atom)
			    left_delimiter=","
			elif [[ "$atom" =~ $fregex || "$atom" =~ $uregex ]]
			then
			    # ignore non-true arguments
			    :
			else
			    echoerr "Parse error: $atom"
			fi
		    done
		fi
	    done <<< "$solver_output"
	elif [[ "$problem" == "EE-PR" || "$problem" == "EE-ST" || "$problem" == "EE-CO" || "$problem" == "EE-GR" || "$problem" == "EE-SST" || "$problem" == "EE-STG" ]]
	then
	    # type="EE"
	    # parse either (1) at least one line and satisfiable, or (2) unsatisfiable
	    # output (1) the extension(s), or (2) the empty list
	    this_output="["
	    while IFS= read -r line || [[ -n $line ]]
	    do
		if [[ "$line" == "UNSATISFIABLE" ]]
		then
		    this_output="[]"
		elif [[ "$line" == "SATISFIABLE" ]]
		then
		    # close the open bracket
		    this_output+="]"
		else
		    this_output+="${left_delimiter}["
		    left_delimiter=","
		    left_delimiter_2=""
		    for atom in $line
		    do
			if [[ $atom =~ $tregex ]]
			then
			    next=${atom:2}
			    this_output+="${left_delimiter_2}${next%?}" # remove last character ")" from next
			    left_delimiter_2=","
			elif [[ "$atom" =~ $fregex || "$atom" =~ $uregex ]]
			then
			    # ignore non-true arguments
			    :
			else
			    echoerr "Parse error: $atom"
			fi
		    done
		    this_output+="]"
		fi
	    done <<< "$solver_output"
	elif [[ "$problem" == "DC-PR" || "$problem" == "DC-ST" || "$problem" == "DC-CO" || "$problem" == "DC-GR" || "$problem" == "DC-SST" || "$problem" == "DC-STG" || "$problem" == "DC-ID" ]]
	then
	    # type="DC"
	    # parse either (1) satisfiable, or (2) unsatisfiable
	    # output (1) YES, or (2) NO
	    while IFS= read -r line || [[ -n $line ]]
	    do
		if [[ "$line" == "UNSATISFIABLE" ]]
		then
		    this_output="NO"
		elif [[ "$line" == "SATISFIABLE" ]]
		then
		    this_output="YES"
		# elif [[ "$line" == "UNKNOWN" ]]
		# then
		#     this_output="YES"
		else
		    echoerr "$0: Parse error: $solver_output"
		fi
	    done <<< "$solver_output"
	elif [[ "$problem" == "DS-PR" || "$problem" == "DS-ST" || "$problem" == "DS-CO" || "$problem" == "DS-GR" || "$problem" == "DS-SST" || "$problem" == "DS-STG" ]]
	then
	    # type="DS"
	    # parse either (1) satisfiable, or (2) unsatisfiable
	    # output (1) NO, or (2) YES
	    while IFS= read -r line || [[ -n $line ]]
	    do
		if [[ "$line" == "UNSATISFIABLE" ]]
		then
		    this_output="YES"
		elif [[ "$line" == "SATISFIABLE" ]]
		then
		    this_output="NO"
		# elif [[ "$line" == "UNKNOWN" ]]
		# then
		#     this_output="NO"
		else
		    echoerr "$0: Parse error: $solver_output"
		fi
	    done <<< "$solver_output"
	elif [[ "$problem" == "D3" ]]
	then
	    # Dung's Triathlon
	    # pause "GROUNDED", followed by the grounded interpretation,
	    # then "STABLE", followed by all stable interpretations,
	    # then "PREFERRED", followed by all preferred interpretations
	    this_output=""
	    left_delimiter=""
	    while IFS= read -r line || [[ -n $line ]]
	    do
		if [[ "$line" == "GROUNDED" ]]
		then
		    this_output+="["
		    left_delimiter=""
		elif [[ "$line" == "STABLE" ]]
		then
		    # finish this list and open the next one
		    this_output+="],["
		    left_delimiter=""
		elif [[ "$line" == "PREFERRED" ]]
		then
		    this_output+="],["
		    left_delimiter=""
		else
		    this_output+="${left_delimiter}["
		    left_delimiter=","
		    left_delimiter_2=""
		    for atom in $line
		    do
			if [[ $atom =~ $tregex ]]
			then
			    next=${atom:2}
			    this_output+="${left_delimiter_2}${next%?}" # remove last character ")" from next
			    left_delimiter_2=","
			elif [[ "$atom" =~ $fregex || "$atom" =~ $uregex ]]
			then
			    # ignore non-true arguments
			    :
			else
			    echoerr "Parse error: $atom"
			fi
		    done
		    this_output+="]"
		fi
		this_output+=""
	    done <<< "$solver_output"
	    this_output+="]"
	else
	    echoerr "Error: Cannot parse solver output: Unknown problem."
	fi

	echo "$this_output"
}

# accepted formats: please comment those unsupported
formats[1]="apx" # "aspartix" format
#formats[2]="tgf" # trivial graph format

# problems that can be accepted: please comment those unsupported
#+------------------------------------------------------------------------+
#|         I C C M A   2 0 1 7   L I S T   O F   P R O B L E M S          |
#|                                                                        |
tasks[1]="DC-CO" 	# Decide credulously according to Complete semantics
tasks[2]="DS-CO" 	# Decide skeptically according to Complete semantics
tasks[3]="SE-CO" 	# Enumerate some extension according to Complete semantics
tasks[4]="EE-CO" 	# Enumerate all the extensions according to Complete semantics
tasks[5]="DC-PR" 	# Decide credulously according to Preferred semantics
tasks[6]="DS-PR" 	# Decide skeptically according to Preferred semantics
tasks[7]="SE-PR" 	# Enumerate some extension according to Preferred semantics
tasks[8]="EE-PR" 	# Enumerate all the extensions according to Preferred semantics
tasks[9]="DC-ST" 	# Decide credulously according to Stable semantics
tasks[10]="DS-ST" 	# Decide skeptically according to Stable semantics
tasks[11]="SE-ST" 	# Enumerate some extension according to Stable semantics
tasks[12]="EE-ST" 	# Enumerate all the extensions according to Stable semantics
tasks[13]="DC-SST" 	# Decide credulously according to Semi-stable semantics
tasks[14]="DS-SST" 	# Decide skeptically according to Semi-stable semantics
tasks[15]="SE-SST" 	# Enumerate some extension according to Semi-stable semantics
tasks[16]="EE-SST" 	# Enumerate all the extensions according to Semi-stable semantics
tasks[17]="DC-STG" 	# Decide credulously according to Stage semantics
tasks[18]="DS-STG" 	# Decide skeptically according to Stage semantics
tasks[19]="EE-STG" 	# Enumerate all the extensions according to Stage semantics
tasks[20]="SE-STG" 	# Enumerate some extension according to Stage semantics
tasks[21]="DC-GR" 	# Decide credulously according to Grounded semantics
tasks[22]="SE-GR" 	# Enumerate some extension according to Grounded semantics
tasks[23]="DC-ID" 	# Decide credulously according to Ideal semantics
tasks[24]="SE-ID" 	# Enumerate some extension according to Ideal semantics
tasks[25]="D3"          # Dung's Triathlon
#|                                                                        |
#|  E N D   O F   I C C M A   2 0 1 7   L I S T   O F   P R O B L E M S   |
#+------------------------------------------------------------------------+

# E N D   O F   C O N F I G U R A T I O N    S E C T I O N
#################################################################

function list_output
{
	declare -a arr=("${!1}")
	check_something_printed=false
	echo -n '['
	for i in ${arr[@]}; 
	do
		if [ "$check_something_printed" = true ];
		then
			echo -n ", "
		fi
		echo -n $i
		check_something_printed=true
	done
        echo ']'
}

function main
{
	if [ "$#" = "0" ]
	then
		information
		exit 0
	fi

	local local_problem=""
	local local_fileinput=""
	local local_format=""
	local local_additional=""

	while [ "$1" != "" ]; do
	    case $1 in
	      "--formats")
		list_output formats[@]
		exit 0
		;;
	      "--problems")
		list_output tasks[@]
		exit 0
		;;
	      "-p")
		shift
		local_problem=$1
		;;
	      "-f")
		shift
		local_fileinput=$1
		;;
	      "-fo")
		shift
		local_format=$1
		;;
	      "-a")
		shift
		local_additional=$1
		;;
	    esac
	    shift
	done

	res=$(solver $local_fileinput $local_format $local_problem $local_additional)

	parse_output $local_problem "$res"
}

main $@
exit 0
