#!/bin/bash

DIAMOND_DIR=src/diamond
DIAMOND_SRC=$DIAMOND_DIR/diamond.go
DIAMOND_EXE=$DIAMOND_DIR/diamond
#CLINGO_ARCHIVE_URL=https://github.com/potassco/clingo/releases/download/v5.1.0/clingo-5.1.0-linux-x86_64.tar.gz
#CLINGO_ARCHIVE=clingo-5.1.0-linux-x86_64.tar.gz
#CLINGO_DIR=clingo-5.1.0-linux-x86_64/
CLINGO_ARCHIVE_URL=https://github.com/potassco/clingo/releases/download/v5.0.0/clingo-5.0.0-linux-x86_64.tar.gz
CLINGO_ARCHIVE=clingo-5.0.0-linux-x86_64.tar.gz
CLINGO_DIR=clingo-5.0.0-linux-x86_64/
CLINGO_BIN=$CLINGO_DIR/clingo
GO_ARCHIVE=go1.7.4.linux-amd64.tar.gz
GO_ARCHIVE_URL=https://storage.googleapis.com/golang/go1.7.4.linux-amd64.tar.gz
GO_DIR=go/
GO_BIN=$GO_DIR/bin/go

# check if diamond is there
if [ ! -e $DIAMOND_EXE ]
then
    # if not, we have to compile it
    # for this, we need go
    if [ ! -e $GO_BIN ]
    then
	# if go is not there, we need to get it
	if [ ! -e $GO_ARCHIVE ]
	then
	    echo "Getting $GO_ARCHIVE ..."
	    wget $GO_ARCHIVE_URL

	    # check success
	    if [ -e $GO_ARCHIVE ]
	    then
		echo "Successfully downloaded go."
	    else
		echo "Failure: Error downloading go!"
		exit 1
	    fi
	fi

	# if we're still in the game then the go archive is there, so unpack it
	echo "Unpacking go ..."
	tar xzvf $GO_ARCHIVE

	# the go executable should be there, but let's check
	if [ -e $GO_BIN ]
	then
	    echo "################################################################################"
	    echo "Successfully unpacked go."
	else
	    echo "Failure: Error getting go!"
	    exit 1
	fi
    fi
    # now we know that at least the go executable is there

    # for diamond to work correctly, we also need clingo
    # check if it's there
    if [ ! -e $CLINGO_BIN ]
    then
	# if it's not there, we need to get it
	# first try the downloaded archive, if there is one
	if [ ! -e $CLINGO_ARCHIVE ]
	then
	    echo "Getting $CLINGO_ARCHIVE ..."
	    wget $CLINGO_ARCHIVE_URL
	    if [ -e $CLINGO_ARCHIVE ]
	    then
		echo "Successfully downloaded clingo"
	    else
		echo "Failure: Error downloading clingo."
		exit 1
	    fi
	fi

	# we have the archive, so let's unpack it
	echo "Unpacking clingo ..."
	tar xzvf $CLINGO_ARCHIVE
	if [ -e $CLINGO_BIN ]
	then
	    echo "################################################################################"
	    echo "Successfully unpacked clingo"
	else
	    echo "Failure: Error unpacking clingo."
	    exit 1
	fi
    fi
    # at this point we know that also clingo is there

    # now finally for compiling diamond
    echo "Building goDIAMOND ..."
    export GOROOT=$(pwd)/$GO_DIR
    $GO_BIN build $DIAMOND_SRC
    mv diamond $DIAMOND_DIR

    if [ ! -e $DIAMOND_EXE ]
    then
	echo "Failure: goDIAMOND could not be built."
	exit 1
    fi
    echo "Successfully built goDIAMOND."
fi

echo "################################################################################"
echo "Complete success!"
echo "goDIAMOND should be ready to rumble."
echo "################################################################################"
