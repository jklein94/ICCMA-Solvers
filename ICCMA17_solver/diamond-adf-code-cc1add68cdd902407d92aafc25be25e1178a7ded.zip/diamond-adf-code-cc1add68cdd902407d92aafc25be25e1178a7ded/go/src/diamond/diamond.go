////////////////////////////////////////////////////////////////////////////////
// 
// Copyright 2016, 2017 Hannes Strass, strass@informatik.uni-leipzig.de
//
// This file is part of diamond.
//
// diamond is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// diamond is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with diamond.  If not, see <http://www.gnu.org/licenses/>.
//
////////////////////////////////////////////////////////////////////////////////
//
// diamond.go
//
// goDIAMOND -- a reimplementation of diamond in go.
// Written with go1.6 on linux/amd64.
//
// Main improvements:
// * No more two-step solver calls, maximisation is handled via disjunctive encodings.
//   All semantics and resoning problems uniformly call clingo once.
// * Improved translation from formula to functional representation.
// * Formula representation of instances is now default.
// * A novel encoding of the three-valued one-step consequence operator for functional-representation ADFs.
// * Extensibility for new semantics via internal data structures.
// * Dedicated implementation of grounded semantics for argumentation frameworks.
// * Dedicated oracle algorithm for ideal semantics for argumentation frameworks.

package main

import (
	"errors"
	"flag"
	"fmt"
	"io"
	"io/ioutil"
	"bufio"
	"log"
	"os"
	"os/exec"
	"strings"
)

// An input format is something that diamond can read input in.
type InputFormat struct {
	// name for internal use
	Name string
	// string to use as command line argument
	CommandLineArgument string
	// description to explain command line argument
	CommandLineDescription string
	// file name of the associated transformation encoding
	// a transformation encoding in this case transforms the input into the default input format
	TransformationEncodingFileNames []string
	// some input formats have associated operators; this field contains the file name of the operator's encoding
	OperatorEncodingFileName string
	// true iff the input of the present instance uses this format
	// only exactly one input format can be used
	Active bool
}

// A semantics is something that diamond can compute interpretations for.
type Semantics struct {
	// name for internal use
	Name string
	// string to use as a command line argument
	CommandLineArgument string
	// description to explain command line argument
	CommandLineDescription string
	// file name of the semantics' associated encoding
	EncodingFileName string
	// true iff the present instance is supposed to compute interpretations for this semantics
	// multiple semantics can be computed for the same input (serially)
	Compute bool
}

// A reasoning mode is a way of producing results.
type ReasoningMode struct {
	// name for internal use
	Name string
	// string to use as a command line argument
	CommandLineArgument string
	// description to explain command line argument
	CommandLineDescription string
	// arguments that are passed to the solver whenever this mode is active
	SolverCallArguments []string
	// some reasoning modes require the creation of temporary files
	// this points to such a file in order to pass its name to the solver
	QueryTempFile *os.File
	// an encoding that hides most of the solver's output and shows only output-relevant atoms
	OutputEncodingFileName string
	// true iff the present instance is supposed to operate in this reasoning mode
	// only exactly one reasoning mode can be active at a time
	Active bool
}

// set the reasoning mode's temporary file
func (m *ReasoningMode) SetQueryTempFile(dir string, s string) {

	var tmpfileName string
	var tmpfileContent string
	
	// create the relevant constraint
	if (m.Name == "one" || m.Name == "all") { return }

	if (m.Name == "cred") {

		// to check whether a statement is credulously accepted, remove all those interpretations where the statement is not true
		// if something remains, the statement is accepted
		tmpfileContent = fmt.Sprintf(":- not t(%s).", s)
		tmpfileName = fmt.Sprintf("cred-%s.lp", s)
	}

	if (m.Name == "scep") {

		// to check whether a statement is sceptically accepted, remove all those interpretations where the statement is true
		// if something remains, the statement is not accepted
		tmpfileContent = fmt.Sprintf(":- t(%s).", s)
		tmpfileName = fmt.Sprintf("scep-%s.lp", s)
	}

	// create a temporary file with the appropriate content
	var e1 error
	m.QueryTempFile, e1 = ioutil.TempFile(dir, tmpfileName)

	if e1 != nil { log.Fatal(e1) }

	_, e2 := m.QueryTempFile.Write([]byte(tmpfileContent))
	if e2 != nil { log.Fatal(e2) }

	e3 := m.QueryTempFile.Close()
	if e3 != nil { log.Fatal(e3) }
}

// return the reasoning mode's temporary file name if one exists
func (m *ReasoningMode) QueryTempFileNames() []string {

	if ( m.Name == "cred" || m.Name == "scep" ) {

		return []string{ m.QueryTempFile.Name() }
	} else {

		return []string{}
	}
}

// delete temporary files
func (m *ReasoningMode) CleanUp() {

	// remove temporary files used for querying
	if ( m.Name == "cred" || m.Name == "scep" ) {
		os.Remove(m.QueryTempFile.Name())
	}
}

// list all necessary diamond encodings here
type Encodings struct {
	cfi string
	nai string
	stg string
	adm string
	com string
	prf string
	sem string
	mod string
	grd string
	idl string
	fnop string
	afop string
	biop string
	trans string
	show string
}

// for each string prefix, Prepend returns a function that prepends an input with prefix
func Prepend(prefix *string) func(string) string {

	return func(s string) string {

		return fmt.Sprintf("%s%s", *prefix, s)
	}
}

// internal data format for computing with AFs
type AF struct {
	Arguments map[string]string
	Attackers map[string][]string
	Attacked map[string][]string
}

func main() {

	// set encoding files to the default encodings used by diamond
	enc := Encodings{
		trans: "pf2fn.lp",
		cfi: "cfi.lp",
		nai: "naiD.lp",
		stg: "stgD.lp",
		adm: "adm.lp",
		com: "com.lp",
		prf: "prfD.lp",
		sem: "semD.lp",
		mod: "mod.lp",
		grd: "grdD.lp",
		idl: "idlD.lp",
		fnop: "fnop.lp",
		afop: "afop.lp",
		biop: "biop.lp",
		show: "show.lp" }

	// deal with command line arguments

	// semantics
	cfi := Semantics{ "conflict-free", "cfi", "Use three-valued conflict-free semantics", enc.cfi, false }
	nai := Semantics{ "naive", "nai", "Use naive semantics", enc.nai, false }
	stg := Semantics{ "stage", "stg", "Use stage semantics", enc.stg, false }
	adm := Semantics{ "admissible", "adm", "Use admissible semantics", enc.adm, false }
	com := Semantics{ "complete", "com", "Use complete semantics", enc.com, false }
	prf := Semantics{ "preferred", "prf", "Use preferred semantics", enc.prf, false }
	sem := Semantics{ "semi-model", "sem", "Use semi-model semantics", enc.sem, false }
	mod := Semantics{ "model", "mod", "Use model semantics", enc.mod, false }
	grd := Semantics{ "grounded", "grd", "Use grounded semantics", enc.grd, false }
	idl := Semantics{ "ideal", "idl", "Use ideal semantics (only available for AF input)", enc.idl, false }

	semantics := [10]*Semantics{ &cfi, &nai, &stg, &adm, &com, &prf, &sem, &mod, &grd, &idl }

	// for each semantics, create a command line switch
	for i := range semantics {

		flag.BoolVar(&semantics[i].Compute, semantics[i].CommandLineArgument, semantics[i].Compute, semantics[i].CommandLineDescription)
	}

	// create a switch for the manual treatment of the grounded semantics
	var manualGrounded bool
	flag.BoolVar(&manualGrounded, "mgrd", false, "Use grounded semantics (alternative, direct implementation)")

	// input formats
	fn := InputFormat{ "functional", "fn", "Input uses functional representation using predicates s/1, ci/1, co/1, ci/3, co/3", []string{}, enc.fnop, false }
	pf := InputFormat{ "formula", "pf", "Input uses propositional formula representation using predicates s/1, ac/2", []string{ enc.trans }, enc.fnop, true }
	bi := InputFormat{ "bipolar", "bi", "Input uses bipolar ADF representation using predicates s/1, ac/2, sup/2, att/2", []string{}, enc.biop, false}
	af := InputFormat{ "aspartix", "af", "Input uses Dung AF representation in ASPARTIX syntax using predicates arg/1, att/2", []string{}, enc.afop, false}
	
	formats := [4]*InputFormat{ &fn, &pf, &bi, &af }

	// for each input format, create a command line switch
	for i := range formats {

		flag.BoolVar(&formats[i].Active, formats[i].CommandLineArgument, formats[i].Active, formats[i].CommandLineDescription)
	}

	// reasoning modes
	one := ReasoningMode{ "one", "one", "Compute one interpretation if one exists", []string{ "hallo", "-V0", "--configuration=jumpy" }, nil, enc.show, false }
	all  := ReasoningMode{ "all", "all", "Compute all interpretations", []string{ "hallo", "-V0", "-n 0", "--configuration=frumpy" }, nil, enc.show, true }
	cred := ReasoningMode{ "cred", "cred", "Credulous reasoning (the statement is credulously accepted iff the answer is SATISFIABLE)", []string{ "hallo", "-V0", "-q" }, nil, enc.show, false }  // TODO: for some reason the Run() command "eats" the first element of the Args list
	scep := ReasoningMode{ "scep", "scep", "Sceptical reasoning (the statment is sceptically accepted iff the answer is UNSATISFIABLE)", []string{ "hallo", "-V0", "-q" }, nil, enc.show, false } // TODO: for some reason the Run() command "eats" the first element of the Args list
	// this mode is only used internally for AF ideal computation and thus does not appear in the list of modes below
	cred_witness := ReasoningMode{ "cred", "cred", "Credulous reasoning, providing a witness for acceptability", []string{ "hallo", "-V0" }, nil, enc.show, false }

	modes := [4]*ReasoningMode{ &one, &all, &cred, &scep }

	// for each reasoning mode, create a command line switch
	for i := range modes {

		flag.BoolVar(&modes[i].Active, modes[i].CommandLineArgument, modes[i].Active, modes[i].CommandLineDescription)
	}

	// additional argument
	var additionalArgument string
	flag.StringVar(&additionalArgument, "a", "", "Argument for credulous/sceptical reasoning")

	// full path to clingo solver
	var clingoPath string
	flag.StringVar(&clingoPath, "c", "/usr/bin/clingo", "Full path to clingo executable")

	// full path to diamond encodings
	var encPath string
	flag.StringVar(&encPath, "d", "enc/", "Full path to diamond encodings directory")

	// initialize the function that will later prepend encodings with their directory path
	Encodify := Prepend(&encPath)

	// verbosity
	var quiet bool
	flag.BoolVar(&quiet, "q", false, "Quiet mode; suppress all output except for models and satisfiability status")

	// Dung's Triathlon
	var dungsTriathlon bool
	flag.BoolVar(&dungsTriathlon, "d3", false, "Compute Dung's Triathlon. Only available for AF input format.")

	// read input and set values
	flag.Parse()

	// check for coherence: is there an input file name?
	var instanceFileName string

	if flag.NArg() < 1 {

		// if no instance was specified, return an error message and exit
		fmt.Println("goDIAMOND v0.6.6")
		fmt.Println("Quick usage: diamond -<semantics> <instance>")
		fmt.Println("Further commands:")
		flag.PrintDefaults()
		
		tooFew := errors.New("Fatal error: No instance file name specified!")
		log.Fatal(tooFew)
	}

	if flag.NArg() > 1 {

		// if more than one argument was given, return an error message and exit
		fmt.Println("goDIAMOND v0.6.6")
		fmt.Println("Quick usage: diamond -<semantics> <instance>")
		fmt.Println("Further commands:")
		flag.PrintDefaults()

		tooMany := errors.New(fmt.Sprintf("Fatal error: Too many arguments: %s", strings.Join(flag.Args(), " ")))
		log.Fatal(tooMany)
	}

	// get instance file name (unique non-flagged argument)
	instanceFileName = flag.Arg(0)

	// check for coherence: does the input file exist?
	file, err := os.Open(instanceFileName) // try to open for read access
	if err != nil {

		log.Fatal(err)

	} else {

		file.Close()
	}

	// check for coherence: input formats
	if ( fn.Active || bi.Active || af.Active ) {

		// if a non-default input format is activated, deactivate the default one
		pf.Active = false
	}

	if ( (fn.Active && bi.Active) || (fn.Active && af.Active) || (bi.Active && af.Active) ) {

		// if more than one non-default input format is activated, complain and exit
		log.Fatal(errors.New("Fatal error: At most one input format can be used!"))
	}

	// check for coherence: reasoning modes
	if ( one.Active || cred.Active || scep.Active ) {

		// if a non-default reasoning mode is activated, deactivate the default one
		all.Active = false
	}

	if ( (one.Active && cred.Active) || (one.Active && scep.Active) || (cred.Active && scep.Active) ) {

		// if more than one non-default reasoning mode is activated, complain and exit
		log.Fatal(errors.New("Fatal error: At most one reasoning mode can be used!"))
	}

	// check for coherence: if credulous/sceptical reasoning requires an argument
	if ( cred.Active || scep.Active ) && additionalArgument == "" {

		// if the argument (via -a) is not given, complain and exit
		log.Fatal(errors.New("Fatal error: Argument whose acceptance should be checked must be specified by the -a flag!"))
	}

	// check if encodings path ends in "/" and add one if not
	if !strings.HasSuffix(encPath, "/") {

		encPath = string(append([]byte(encPath), '/'))
	}

	// check whether ideal semantics is illegally called for non-AF input
	if ( idl.Compute && !af.Active ) {

		log.Fatal(errors.New("Fatal error: ideal semantics can only be used for AF input!"))
		return
	}

	// finally, check if the manual version of grounded semantics is desired and call the respective function if so
	if manualGrounded {

		if !af.Active { log.Fatal(errors.New("Fatal error: -mgrd requires -af!")) }

		grdint := computeGrounded(parseAspartixAF(instanceFileName))

		// if one of the reasoning modes is active, check and return the result, then exit
		if cred.Active {

			if grdint[additionalArgument] == "t" {

				fmt.Printf("SATISFIABLE\n")

			} else {

				fmt.Printf("UNSATISFIABLE\n")
			}

			// we're done, quit the program
			return
		}

		if scep.Active {

			if grdint[additionalArgument] == "t" {

				fmt.Printf("UNSATISFIABLE\n")

			} else {

				fmt.Printf("SATISFIABLE\n")
			}

			// we're done, quit the program
			return
		}

		// output interpretation
		printInterpretation(quiet, true, grdint)

		// we're done, quit the program
		return
	}

	// check if we are using AF input and are to compute for the ideal semantics
	if ( af.Active && idl.Compute ) {

		// prepare oracle calls for AF credulous acceptance admissible
		solverArgs := append(cred_witness.SolverCallArguments,
			Encodify(af.OperatorEncodingFileName),
			Encodify(adm.EncodingFileName),
			Encodify(cred_witness.OutputEncodingFileName),
			instanceFileName)

		inputAF := parseAspartixAF(instanceFileName)

		inadmissible := computeInadmissibleArguments(inputAF, clingoPath, encPath, solverArgs, cred_witness)

		ideal := computeIdealInterpretation(inputAF, inadmissible)

		if cred.Active {

			if ideal[additionalArgument] == "t" {

				fmt.Printf("SATISFIABLE\n")

			} else {

				fmt.Printf("UNSATISFIABLE\n")
			}

			// we're done, quit the program
			return
		}

		// output computed interpretation
		printInterpretation(quiet, true, ideal)

		// we're done, quit the program
		return
	}

	// check if we are to compute Dung's Triathlon
	if dungsTriathlon {

		if !af.Active { log.Fatal(errors.New("Fatal error: Dung's triathlon requires AF input format!")) }

		solverArgsStable := append(all.SolverCallArguments,
			Encodify(af.OperatorEncodingFileName),
			Encodify(mod.EncodingFileName),
			Encodify(all.OutputEncodingFileName),
			instanceFileName)

		solverArgsPreferred := append(all.SolverCallArguments,
			Encodify(af.OperatorEncodingFileName),
			Encodify(prf.EncodingFileName),
			Encodify(all.OutputEncodingFileName),
			instanceFileName)

		// call the dedicated function for computing Dung's Triathlon
		computeDungsTriathlon(instanceFileName, clingoPath, encPath, all, solverArgsStable, solverArgsPreferred, quiet)

		// after this, we're done, so quit the program
		return
	}

	////////////////////////////////////////////////////////////////////////////////
	// now for the main solving part

	// figure out what input format and what reasoning mode we are dealing with

	var format *InputFormat

	for i := range formats {

		if formats[i].Active {

			format = formats[i]
		}
	}

	var mode *ReasoningMode

	for i := range modes {

		if modes[i].Active {

			mode = modes[i]
		}
	}

	// figure out whether solver errors should be passed along to the user
	var errorChannel io.Writer
	if !quiet {

		errorChannel = os.Stderr
	} else {

		errorChannel = nil
	}

	// now solve for the chosen semantics
	mode.SetQueryTempFile("", additionalArgument) // mode.SetQueryTempFile(encPath, additionalArgument)

	for i, transformationEncodingFileName := range format.TransformationEncodingFileNames {

		format.TransformationEncodingFileNames[i] = Encodify(transformationEncodingFileName)
	}

	// remember if some semantics has been specified by the user
	var someSemantics bool

	for i := range semantics {

		// check if the semantics is supposed to be computed
		if semantics[i].Compute {

			someSemantics = true

			solverArgs := append(mode.SolverCallArguments,
				Encodify(format.OperatorEncodingFileName),
				Encodify(semantics[i].EncodingFileName),
				Encodify(mode.OutputEncodingFileName),
				instanceFileName)

			solverArgs = append(solverArgs, format.TransformationEncodingFileNames...)

			command := exec.Cmd{
				Path: clingoPath,
				Args: append(solverArgs, mode.QueryTempFileNames()...),
				Env: nil,
				Dir: "",
				Stdin: os.Stdin,
				Stderr: errorChannel,
				Stdout: os.Stdout}

			if !quiet {

				fmt.Println("--------------------------------------------------------------------------------")
				fmt.Println("semantics:", semantics[i].Name)
				fmt.Println("reasoning mode:", mode.CommandLineDescription)
				fmt.Println("input format:", format.Name)
				fmt.Println("Solver call:", command.Path, strings.Join(command.Args[1:], " ")) // TODO: for some reason the Run() command "eats" the first element of the Args list
				fmt.Println("--------------------------------------------------------------------------------")
			}

			command.Run()

			if !quiet { fmt.Println("--------------------------------------------------------------------------------") }
		}
	}

	// remove temporary files if present
	mode.CleanUp()

	// if no semantics has been specified, complain
	if !someSemantics {

		err := errors.New("Fatal error: No semantics specified!")
		log.Fatal(err)
	}
}

// output a list of interpretations mimicking clingo output syntax
func printInterpretations(quiet bool, sat bool, list [](map[string]string)) {

	if !quiet { fmt.Println("--------------------------------------------------------------------------------") }

	// output the actual truth values
	for _, v := range list {

		for arg, val := range v {

			writeArg(val, arg)
		}

		fmt.Printf("\n")
	}

	// complete the output to mimick clingo output syntax
	if sat { fmt.Printf("SATISFIABLE\n") }

	if !quiet { fmt.Println("--------------------------------------------------------------------------------") }
}

// output an interpretation mimicking clingo output syntax
func printInterpretation(quiet bool, sat bool, v map[string]string) {

	if !quiet { fmt.Println("--------------------------------------------------------------------------------") }

	// output the actual truth values
	for arg, val := range v {

		writeArg(val, arg)
	}

	fmt.Printf("\n")

	// complete the output to mimick clingo output syntax
	if sat { fmt.Printf("SATISFIABLE\n") }

	if !quiet { fmt.Println("--------------------------------------------------------------------------------") }
}

// output an argument in ASP predicate syntax
func writeArg(v, arg string) {

	fmt.Printf("%s(%s) ", v, arg)
}

// parse an AF in aspartix syntax
func parseAspartixAF(fileName string) AF {

	data, err := ioutil.ReadFile(fileName)

	if err != nil {	log.Fatal(err) }

	// manually parse the contents for
	// arguments: arg(<string>).
	// attacks: att(<string>,<string>).
	// comment lines: %<string>\n

	// parsing variables
	var i, next int
	var found bool

	// bookkeeping variables:
	// maps each argument to its current truth value: "u", "t", or "f"
	arguments := make(map[string]string)
	// maps each argument to the list of its attackers
	attackers := make(map[string][]string)
	// maps each argument to the list of arguments attacked by it
	attacked := make(map[string][]string)

	// next indicates where parsing is resumed after an item of interest has been found
	// initially, next == 0 by initialisation

	for next < len(data) {

		// i indicates the current position in the input data
		i = next

		// try to parse a whitespace
		if ( data[i] == ' ' || data[i] == '\t' || data[i] == '\r' || data[i] == '\n' ) {

			// parsed whitespace
			next = i+1

		} else
		// try to parse an argument
		if ( data[i] == 'a' && data[i+1] == 'r' && data[i+2] == 'g' && data[i+3] == '(' ) {

			for j := i+4; j <= len(data); j++ {

				if ( data[j] == ')' && data[j+1] == '.' ) {

					argString := string(data[i+4:j])

					// add argument to bookkeeping if not already present
					arguments[argString] = "u"
					setIfNew(&attackers, argString, nil)
					setIfNew(&attacked, argString, nil)

					// resume scanning at position right after the argument fact
					next = j+2

					// break out of the for loop that looks for the end of the argument declaration
					break
				}
			}
		} else
		// try to parse an attack
		if ( data[i] == 'a' && data[i+1] == 't' && data[i+2] == 't' && data[i+3] == '(' ) {

			// look for the end of the first argument
			for j := i+4; j <= len(data); j++ {

				// try to find a comma
				if data[j] == ',' {

					// record whether we are allowed to break out of the outer for loop
					found = false

					// set string containing first argument of attack predicate
					from := string(data[i+4:j])

					// look for the end of the second argument
					for k := j+1; k <= len(data); k++ {

						// try to find a closing parenthesis and a full stop
						if ( data[k] == ')' && data[k+1] == '.' ) {

							// parsing is successful, so we can break out
							found = true

							// set string containing second argument of attack predicate
							to := string(data[j+1:k])

							// add attacker/attacked to bookkeeping structure
							appendIfThere(&attackers, to, from)
							appendIfThere(&attacked, from, to)

							// resume scanning at position right after the attack fact
							next = k+2

							// break out of the inner for loop looking for the end of the second argument
							break
						}
					}

					// if parsing was successful, break out of the outer for loop
					if found { break }
				}
			}
		} else
		// try to parse a comment line
		if ( data[i] == '%' ) {

			// look for the end of the comment line
			for j := i+1; j < len(data); j++ {

				// try to find a line break
				if ( (data[j] == '\n') ) {

					// resume scanning after the comment line
					next = j+1

					// break out of the foor loop looking for the end of the comment
					break
				}

				// the file ends with a comment
				if ( j >= len(data)-1 ) {

					// set next such that scanning ends altogether
					next = len(data)

					// break out of the for loop looking for the end of the comment
					break
				}
			}
		} else {
			// parsing failed, exit with a fatal error
			parse_err := errors.New(fmt.Sprintf("Fatal error: Parsing error: %s", string(data[i:])))
			log.Fatal(parse_err)
		}
	}

	return AF{ arguments, attackers, attacked }
}

// manual implementation of grounded semantics

func computeGrounded(af AF) map[string]string {

	// compute until nothing changes any more, i.e., a fixpoint is reached
	change := true

	for change {

		// nothing has changed so far
		change = false

		for arg, attackersOfarg := range af.Attackers {

			// if an argument has no attackers, it is accepted
			if len(attackersOfarg) < 1 {
				
				if af.Arguments[arg] == "u" { af.Arguments[arg] = "t" }

				// now something changed
				change = true

				// thus all arguments attacked by arg are F
				for _, attackee := range af.Attacked[arg] {

					if af.Arguments[attackee] == "u" { af.Arguments[attackee] = "f" }

					// for each false argument, remove its attacks
					for _, attackedByAttackee := range af.Attacked[attackee] {

						af.Attackers[attackedByAttackee] = deleteFromSlice(af.Attackers[attackedByAttackee], attackee)
					}

					// remove attacked argument from bookkeeping structures
					delete(af.Attackers, attackee)
					delete(af.Attacked, attackee)
				}

				// remove argument from bookkeeping structures
				delete(af.Attackers, arg)
				delete(af.Attacked, arg)

				// we changed the structure over which the loop runs, so break and restart the loop
				break
			}
		}
	}

	// note that all arguments that have not been assigned a value during the loop must be "u" due to initialisation in parseAspartixAF
	return af.Arguments
}

// initialize value val for key key if the key is not yet in the map m
func setIfNew(m *map[string][]string, key string, val []string) {

	_, ok := (*m)[key]

	if !ok {

		(*m)[key] = val
	}
}

// if m[key] is non-nil, append el; otherwise set m[key] to the singleton {el}
func appendIfThere(m *map[string][]string, key string, el string) {

	val, ok := (*m)[key]

	if ok {
		(*m)[key] = append(val, el)
	} else {
		(*m)[key] = []string{el}
	}
}

// delete the first occurrence of element in the slice *slice
func deleteFromSlice(slice []string, element string) []string {

	for i := 0; i < len(slice); i++ {

		if slice[i] == element {

			slice[i] = slice[len(slice)-1]
			slice = slice[:len(slice)-1]

			return slice
		}
	}

	return slice
}

func computeInadmissibleArguments(af AF, clingoPath string, encPath string, solverArgs []string, cred ReasoningMode) map[string]string {

        af.Arguments = computeGrounded(af)

	// for each argument that is u in the grounded interpretation, check whether it can be credulously accepted for admissible semantics
	for arg, value := range af.Arguments {

		if value == "u" {

			// call clingo to decide credulous admissible acceptance
			accepted, satisfiable := clingoCallAcceptability(clingoPath, encPath, solverArgs, cred, arg)

			// evaluate the answer/witness
			if satisfiable {

				af.Arguments[arg] = "a"

				for _, a := range accepted {

					if af.Arguments[a] == "u" { af.Arguments[a] = "a" }
				}

			} else {

				af.Arguments[arg] = "i"
			}
		}
	}

	return af.Arguments
}

func clingoCallAcceptability(clingoPath string, encPath string, solverArgs []string, cred ReasoningMode, arg string) (map[string]string, bool) {

	var command exec.Cmd
	var stdout io.Reader
	var err error
	var answer string
	// return values:
	var interpretation map[string]string
	var satisfiable bool

	// create temporary file containing the constraint guaranteeing that arg is contained in the returned admissible set, if possible
	cred.SetQueryTempFile("", arg) // cred.SetQueryTempFile(encPath, arg)

	// create command object for external solver call
	command = exec.Cmd{
		Path: clingoPath,
		Args: append(solverArgs, cred.QueryTempFileNames()...),
		Env: nil,
		Dir: "",
		Stdin: nil,
		Stderr: nil,
		Stdout: nil}

	// set up a pipe for reading the command's output
	stdout, err = command.StdoutPipe()

	if err != nil { log.Fatal(err) }

	// start the command after having set up the pipe
	if err = command.Start(); err != nil { log.Fatal(err) }

	// create a scanner object for the command's output
	clingoOutput := bufio.NewScanner(stdout)

	// scan clingo's output
	for clingoOutput.Scan() {

		answer = clingoOutput.Text()

		if answer == "UNSATISFIABLE" {

			satisfiable = false

		} else
		if answer == "SATISFIABLE" {

			satisfiable = true

		} else {

			interpretation = parseClingoOutputLine(answer)
		}
	}

	if err = clingoOutput.Err(); err != nil { log.Fatal(err) }

	// remove temporary file
	cred.CleanUp()

	return interpretation, satisfiable
}

func clingoCallEnumeration(clingoPath string, encPath string, solverArgs []string, all ReasoningMode) [](map[string]string) {

	var command exec.Cmd
	var stdout io.Reader
	var err error
	var answer string
	// return values:
	var interpretation map[string]string
	var interpretations [](map[string]string)

	// create command object for external solver call
	command = exec.Cmd{
		Path: clingoPath,
		Args: solverArgs,
		Env: nil,
		Dir: "",
		Stdin: nil,
		Stderr: nil,
		Stdout: nil}

	// set up a pipe for reading the command's output
	stdout, err = command.StdoutPipe()

	if err != nil { log.Fatal(err) }

	// start the command after having set up the pipe
	if err = command.Start(); err != nil { log.Fatal(err) }

	// create a scanner object for the command's output
	clingoOutput := bufio.NewScanner(stdout)

	// scan clingo's output
	for clingoOutput.Scan() {

		// get the next line of text
		answer = clingoOutput.Text()

		if answer == "UNSATISFIABLE" {

			break

		} else
		if answer == "SATISFIABLE" {

			// nothing to do here

		} else {

			interpretation = parseClingoOutputLine(answer)

			interpretations = append(interpretations, interpretation)
		}
	}

	if err = clingoOutput.Err(); err != nil { log.Fatal(err) }

	return interpretations
}

func parseClingoOutputLine(output string) map[string]string {

	interpretation := make(map[string]string)

	data := []byte(output)

	var i, next int

	for next < len(data) {

		i = next

		// try to parse a t/1 atom
		if ( data[i] == 't' && data[i+1] == '(' ) {

			// first part of atom found, now seek closing parenthesis and (space or end-of-string)
			for j := i+2; j <= len(data); j++ {

				if ( data[j] == ')' && ( j+1 == len(data) || data[j+1] == ' ' ) ) {

					// argument parsed
					argString := string(data[i+2:j])

					// add it to the interpretation
					interpretation[argString] = "t"

					// resume scanning at next position
					next = j+2

					// break out of the for loop that looks for the end of the atom
					break
				}
			}
		} else
		// try to parse a u/1 atom
		if ( data[i] == 'u' && data[i+1] == '(' ) {

			// first part of atom found, now seek closing parenthesis and (space or end-of-string)
			for j := i+2; j <= len(data); j++ {
				
				if ( data[j] == ')' && ( j+1 == len(data) || data[j+1] == ' ' ) ) {

					// argument parsed
					argString := string(data[i+2:j])

					// add it to the interpretation
					interpretation[argString] = "u"

					// resume scanning at next position
					next = j+2
					
					// break out of the for loop that looks for the end of the atom
					break
				}
			}
		} else
		// try to parse a f/1 atom
		if ( data[i] == 'f' && data[i+1] == '(' ) {
			
			// first part of atom found, now seek closing parenthesis and (space or end-of-string)
			for j := i+2; j <= len(data); j++ {

				if ( data[j] == ')' && ( j+1 == len(data) || data[j+1] == ' ' ) ) {

					// argument parsed
					argString := string(data[i+2:j])

					// add it to the interpretation
					interpretation[argString] = "f"

					// resume scanning at next position
					next = j+2

					// break out of the for loop that looks for the end of the atom
					break
				}
			}
		} else {

			log.Fatal(errors.New(fmt.Sprintf("Cannot interpret solver output: %s", string(data[i:]))))
		}

	}

	return interpretation
}

func computeIdealInterpretation(inputAF AF, ideal map[string]string) map[string]string {

	// in "ideal", every argument is mapped to one of "t", "f", "a", "i",
	// depending on whether it is true/false in the grounded interpretation, or
	// credulously acceptable/inacceptable with respect to admissible semantics

	// first, compute a partition of arguments (Dunne, 2009) into:
	// OUT, those that are never credulously admissible (get value "i" in ideal)
	// PSA, those that have only neighbours in OUT (have value "p" in ideal)
	// CA, those that are credulously acceptable and have some neighbour that is also credulously acceptable
	//  (whence not both of them can be in the ideal extension)
	// then, compute a list of all arguments that are either "f" or attacked by some "p" (or "t")
	// now, loop on "ideal"
	//   for each arg with value "p", check whether it is actually defended by the current "t" or "p"
	//    if not, set its status to "i"
	//    if so, keep the status at "p"
	// until a fixpoint obtains
	// walk through "ideal" and for each argument:
	// if it is "p", set it to "t"
	// if it is "i", check whether it has an attacker that is "t"
	// if so, set it to "f"
	// if not, set it to "u"
	// return

	var psa bool

	for arg, val := range ideal {

		if val == "a" {

			// check whether all attackers and all attacked of arg are "i" or "f"
			psa = true

			for _, attackedByArg := range inputAF.Attacked[arg] {

				if ( ideal[attackedByArg] != "i" && ideal[attackedByArg] != "f" ) { psa = false }
			}

			for _, attackerOfArg := range inputAF.Attackers[arg] {

				if ( ideal[attackerOfArg] != "i" && ideal[attackerOfArg] != "f" ) { psa = false }
			}

			if psa { ideal[arg] = "p" }
		}

		// optional debugging message
		// if !quiet { fmt.Printf("ideal[%s]=%s\n", arg, ideal[arg]) }
	}

	// next, compute a list of all arguments that are either "f" or attacked by some "p" (or "t")
	attacked := make(map[string]bool, len(ideal))

	for arg, val := range ideal {

		switch val {

		case "p":
			for _, isAttacked := range inputAF.Attacked[arg] {

				attacked[isAttacked] = true
			}

		case "f":
			attacked[arg] = true
		}
	}

	// now, loop on "ideal"
	// until a fixpoint obtains
	var fixpoint bool
	var defended bool
	var stillAttackedBySomeArg bool

	for !fixpoint {

		fixpoint = true

		//   for each arg with value "p", check whether it is actually defended by the current "t" or "p"
		//    if not, set its status to "i"
		//    if so, keep the status at "p"
		for arg, val := range ideal {

			if val == "p" {

				// assume that arg is defended
				defended = true

				// check whether this is actually the case by checking all its attackers
				for _, attacker := range inputAF.Attackers[arg] {

					// if there is an attacker that is not attacked back, then arg is not defended
					if !attacked[attacker] { defended = false }
				}

				// if arg is not defended by the current set (ideal set candidate), we have to remove it,
				// as it will not be defended by any subset of it
				if !defended {

					// we know that arg is not admissible, but we do not yet know whether it is "f" or "u"
					// this will be determined later
					ideal[arg] = "i"

					// for each argument that is attacked by arg, we have to check whether arg was the only "t" or "p" attacker
					// if so, then the respective attacked argument is not attacked by the ideal set candidate any more
					for _, attackedByArg := range inputAF.Attacked[arg] {

						// assume that attackedByArg is not attacked any more
						stillAttackedBySomeArg = false

						// check whether this is actually the case via iterating over all its attackers
						for _, attackerOfAttackedByArg := range inputAF.Attackers[attackedByArg] {

							if ( ideal[attackerOfAttackedByArg] == "p" || ideal[attackerOfAttackedByArg] == "t" ) {

								stillAttackedBySomeArg = true
							}
						}

						if !stillAttackedBySomeArg { attacked[attackedByArg] = false }
					}

					// we just changed something in the ideal set candidate, so cannot have reached a fixpoint
					fixpoint = false
				}
			}

			// if something changed in the structure we're looping on, break out of the for loop
			if !fixpoint { break }
		}
	}

	// now we have obtained the ideal extension (consisting of those arguments that are "t" and "p")
	// it remains to compute the rest of the ideal interpretation
	// to do this, walk through "ideal" and for each argument:
	//   if it is "p", set it to "t"
	//   if it is "a" or "i", check whether it has an attacker that is "t"
	//     if so, set it to "f"
	//     if not, set it to "u"

	var isAttacked bool

	for arg, val := range ideal {

		switch val {

		case "p":
			ideal[arg] = "t"

		case "a", "i":

			for _, attackerOfArg := range inputAF.Attackers[arg] {

				if ( ideal[attackerOfArg] == "t" || ideal[attackerOfArg] == "p" ) {

					isAttacked = true

					break
				}
			}

			if isAttacked {

				ideal[arg] = "f"

			} else {

				ideal[arg] = "u"
			}
		}
	}

	return ideal
}

func computeDungsTriathlon(instanceFileName string, clingoPath string, encPath string, all ReasoningMode, solverArgsStable []string, solverArgsPreferred []string, quiet bool) {

	var tmpfileContent []byte

	// output separator
	fmt.Println("GROUNDED")

	// manually compute grounded
	grounded := computeGrounded(parseAspartixAF(instanceFileName))

	// output grounded
	printInterpretation(quiet, false, grounded)

	// create a temporary file with a fact for each t/f atom
	for arg, val := range grounded {

		if ( val == "t" || val == "f" ) {

			tmpfileContent = append(tmpfileContent, []byte(fmt.Sprintf("%s(%s).\n", val, arg))...)
		}
	}

	// write temp file contents to file
	tmpfileName := "d3.lp"

	var e1 error
	tempFile, e1 := ioutil.TempFile("", tmpfileName) // ioutil.TempFile(encPath, tmpfileName)

	if e1 != nil { log.Fatal(e1) }

	_, e2 := tempFile.Write(tmpfileContent)
	if e2 != nil { log.Fatal(e2) }

	e3 := tempFile.Close()
	if e3 != nil { log.Fatal(e3) }

	// enumerate all stable
	// output separator
	fmt.Println("STABLE")

	stable := clingoCallEnumeration(clingoPath, encPath, append(solverArgsStable, tempFile.Name()), all)

	var tmpfileLine []byte

	// output stable
	printInterpretations(quiet, false, stable)

	// create constraints avoiding the repeated computation of the stable interpretations in disguise of preferred ones
	for _, stb := range stable {

		// create a constraint for each one
		tmpfileLine = []byte(":- ")

		atomlist := interpretation2atomlist(stb)

		tmpfileLine = append(tmpfileLine, []byte(strings.Join(atomlist, ", "))...)

		tmpfileLine = append(tmpfileLine, []byte(".\n")...)

		tmpfileContent = append(tmpfileContent, []byte(tmpfileLine)...)
	}

	tempFile, e4 := os.OpenFile(tempFile.Name(), os.O_RDWR|os.O_APPEND, 0660)
	if e4 != nil { log.Fatal(e4) }

	_, e5 := tempFile.Write(tmpfileContent)
	if e5 != nil { log.Fatal(e5) }

	e6 := tempFile.Close()
	if e6 != nil { log.Fatal(e6) }

	// output separator
	fmt.Println("PREFERRED")

	// enumerate remaining preferred
	preferred := clingoCallEnumeration(clingoPath, encPath, append(solverArgsPreferred, tempFile.Name()), all)

	// output stable again
	printInterpretations(quiet, false, stable)

	// output remaining preferred
	printInterpretations(quiet, false, preferred)

	os.Remove(tempFile.Name())

	return
}

func interpretation2atomlist(v map[string]string) []string {

	var factlist []string

	for arg, val := range v {

		factlist = append(factlist, fmt.Sprintf("%s(%s)", val, arg))
	}

	return factlist
}
