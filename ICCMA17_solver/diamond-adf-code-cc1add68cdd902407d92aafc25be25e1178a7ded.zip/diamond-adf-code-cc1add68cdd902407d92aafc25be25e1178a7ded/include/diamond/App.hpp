#ifndef DIAMOND_APP_HPP
#define DIAMOND_APP_HPP

namespace diamond{
class App{

};
}

#endif /* DIAMOND_APP_HPP */
