#!/bin/bash

make cmsat
make
