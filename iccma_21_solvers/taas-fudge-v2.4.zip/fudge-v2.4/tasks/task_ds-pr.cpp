/* ============================================================================================================== */
/* == BEGIN FILE ================================================================================================ */
/* ============================================================================================================== */
/*
 ============================================================================
 Name        : task_ds-pr.cpp
 Author      : Matthias Thimm, Federico Cerutti
 Version     : 2.0
 Copyright   : GPL3
 Description : solve functions for DS-PR (deciding skeptical acceptance
               wrt. preferred semantics)
 ============================================================================
 */

// the fudge approach for DS-PR
void solve_dspr(struct TaskSpecification *task, struct AAF* aaf, struct Labeling* grounded){
  // solver_admTest is used for checking whether a single set can be extended
  //       to an admissible set
  // solver_attAdmTest is used for checking whether there is an admissible set
  //       attacking another admissible set
  CaDiCaL::Solver* solver_admTest = sat__init(aaf->number_of_arguments+1);
  CaDiCaL::Solver* solver_attAdmTest = sat__init(2*aaf->number_of_arguments+aaf->number_of_attacks + 1);
  // initialise variables
  int* in_vars = (int*) malloc(aaf->number_of_arguments * sizeof(int));
  int* in_attacked_vars = (int*) malloc(aaf->number_of_arguments * sizeof(int));
  int idx = 1;
  for(int i = 0; i < aaf->number_of_arguments;i++){
    in_vars[i] = idx++;
  }
  // add admissibility clauses
  add_admTestClauses(solver_admTest,in_vars,aaf,grounded);

  //Let's create a new variable outarg <-> \/ task->arg^-
  int outarg = idx++;
  std::vector<int> clause_outarg;
  clause_outarg.push_back(-outarg);
  for (GSList* nodeatt = aaf->parents[task->arg]; nodeatt != NULL; nodeatt = nodeatt->next){
      int idxatt = *(int*)nodeatt->data;
      sat__addClause2(solver_admTest,-in_vars[idxatt], outarg);
      clause_outarg.push_back(in_vars[idxatt]);
  }
  clause_outarg.push_back(0);
  sat__addClauseZTVec(solver_admTest,clause_outarg);

  for(int i = 0; i < aaf->number_of_arguments;i++){
      in_attacked_vars[i] = idx++;
  }
  // initialise solver_attAdmTest
  add_admTestClauses(solver_attAdmTest,in_vars,aaf,grounded);
  add_admTestClauses(solver_attAdmTest,in_attacked_vars,aaf,grounded);
  // add constraints for modelling the attack to the other set
  add_attackClauses(solver_attAdmTest,in_vars,in_attacked_vars,2*aaf->number_of_arguments + 2,aaf,grounded);
  // check if there is an admissible labelling setting task->arg IN
  sat__assume(solver_admTest,in_vars[task->arg]);
  int sat = sat__solve(solver_admTest);
  if(sat == 20){
      printf("NO\n");
      return;
  }
  for(int i = 0; i < aaf->number_of_arguments; i++){
    if(sat__get(solver_admTest,in_vars[i]) < 0){
      sat__add(solver_attAdmTest,in_vars[i]);
    }
  }
  sat__add(solver_attAdmTest,0);
  // check if there is an admissible labelling attacking task->arg
  sat__assume(solver_admTest,outarg);
  sat = sat__solve(solver_admTest);
  if(sat == 10){
      printf("NO\n");
      return;
  }
  // main loop
  sat__addClause1(solver_attAdmTest,in_attacked_vars[task->arg]);
  while(true){
    sat = sat__solve(solver_attAdmTest);
    if(sat == 20){
        printf("YES\n");
        return;
    }
    sat__assume(solver_admTest,in_vars[task->arg]);
    for(int i = 0; i < aaf->number_of_arguments; i++){
      if(sat__get(solver_attAdmTest,in_vars[i]) > 0){
        sat__assume(solver_admTest,in_vars[i]);
      }
    }
    sat = sat__solve(solver_admTest);
    if(sat == 20){
        printf("NO\n");
        return;
    }
    for(int i = 0; i < aaf->number_of_arguments; i++){
      if(sat__get(solver_admTest,in_vars[i]) < 0){
        sat__add(solver_attAdmTest,in_vars[i]);
      }
    }
    sat__add(solver_attAdmTest,0);
  }
}

/* ============================================================================================================== */
/* == END FILE ================================================================================================== */
/* ============================================================================================================== */
