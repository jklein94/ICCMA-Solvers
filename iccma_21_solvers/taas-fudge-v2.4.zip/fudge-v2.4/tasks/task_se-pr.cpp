/* ============================================================================================================== */
/* == BEGIN FILE ================================================================================================ */
/* ============================================================================================================== */
/*
 ============================================================================
 Name        : task_ds-pr.cpp
 Author      : Matthias Thimm, Federico Cerutti
 Version     : 2.0
 Copyright   : GPL3
 Description : solve functions for SE-PR
 ============================================================================
 */

// the fudge approach for SE-PR
void solve_sepr(struct TaskSpecification *task, struct AAF* aaf, struct Labeling* grounded){
  CaDiCaL::Solver* solver = sat__init(aaf->number_of_arguments);
  // initialise variables
  int* in_vars = (int*) malloc(aaf->number_of_arguments * sizeof(int));
  int idx = 1;
  for(int i = 0; i < aaf->number_of_arguments;i++){
    in_vars[i] = idx++;
  }
  // add admissibility clauses
  add_admTestClauses(solver,in_vars,aaf,grounded);
  // add a clause imposing that at least one argument is in the set
  for(int i = 0; i < aaf->number_of_arguments; i++){
    sat__add(solver,in_vars[i]);
  }
  sat__add(solver,0);
  // the current set
  struct RaSet* admSet = raset__init_empty(aaf->number_of_arguments);
  // a temp set
  struct RaSet* temp = raset__init_empty(aaf->number_of_arguments);
  int sat;
  int* clause = (int*) malloc(aaf->number_of_arguments * sizeof(int));
  while(true){
      sat = sat__solve(solver);
      if(sat == 20)
        break;
      int idx = 0;
      for(int i = 0; i < aaf->number_of_arguments; i++){
          if(!raset__contains(admSet,i) && sat__get(solver,in_vars[i]) > 0){
              raset__add(temp,i);
          }else if (sat__get(solver,in_vars[i]) < 0){
            clause[idx++] = in_vars[i];
          }
      }
      sat__addClause(solver,clause,idx);
      for(int i = 0; i < temp->number_of_elements; i++ ){
        raset__add(admSet,temp->elements_arr[i]);
        sat__addClause1(solver,in_vars[temp->elements_arr[i]]);
      }
      raset__reset(temp);
  }
  free(clause);
  raset__print(admSet,aaf->ids2arguments);
  raset__destroy(admSet);
  raset__destroy(temp);
  sat__free(solver);
}

/* ============================================================================================================== */
/* == END FILE ================================================================================================== */
/* ============================================================================================================== */
