/* ============================================================================================================== */
/* == BEGIN FILE ================================================================================================ */
/* ============================================================================================================== */
/*
 ============================================================================
 Name        : sat_cadical.cpp
 Author      : Matthias Thimm
 Version     : 1.0
 Copyright   : GPL3
 Description : Bridge functions to cadical 1.3.1
 ============================================================================
 */

// inits a new solver with a new set of variables
CaDiCaL::Solver* sat__init(int num_vars){
  CaDiCaL::Solver* solver = new CaDiCaL::Solver;
  solver->set("quiet", 1);
  solver->reserve(num_vars);
  return solver;
}

// adds a literal (clause must be terminated by 0)
void sat__add(CaDiCaL::Solver* solver, int var){
  solver->add(var);
}

// assume literal
void sat__assume(CaDiCaL::Solver* solver, int lit){
  solver->assume(lit);
}

// adds clauses
void sat__addClause1(CaDiCaL::Solver* solver, int var){
  solver->add(var);
  solver->add(0);
}

// adds clauses
void sat__addClause2(CaDiCaL::Solver* solver, int var1, int var2){
  solver->add(var1);
  solver->add(var2);
  solver->add(0);
}

// adds clauses
void sat__addClause3(CaDiCaL::Solver* solver, int var1, int var2, int var3){
  solver->add(var1);
  solver->add(var2);
  solver->add(var3);
  solver->add(0);
}

// adds clauses
void sat__addClause(CaDiCaL::Solver* solver, int* clause, int num){
  for(int i = 0; i < num; i++)
    solver->add(clause[i]);
  solver->add(0);
}

void sat__addClauseZTVec(CaDiCaL::Solver* solver, std::vector<int> clause){
  int i = 0;
  do{
    solver->add(clause[i]);
  }while(clause[i++] != 0);
}

// adds clauses
void sat__addClauseZT(CaDiCaL::Solver* solver, int* clause){
  int i = 0;
  do{
    solver->add(clause[i]);
  }while(clause[i++] != 0);
}

// solve the problem
int sat__solve(CaDiCaL::Solver* solver){
  return solver->solve();
}

// get value of var (positive=true, negative=false)
int sat__get(CaDiCaL::Solver* solver, int var){
  return solver->val(var);
}

// free memory
void sat__free(CaDiCaL::Solver* solver){
  delete solver;
}

/** prints the clause */
void printClause(int* clause, int num, int* in_vars, struct AAF* aaf){
  printf("<");
  char isFirst = TRUE;
  for(int i = 0; i < num; i++){
    if(isFirst)
      isFirst = FALSE;
    else printf(",");
    for(int j = 0; j < aaf->number_of_arguments; j++){
      if(in_vars[j] == clause[i])
        printf("%s", aaf->ids2arguments[j]);
      else if(in_vars[j] == -clause[i])
        printf("-%s", aaf->ids2arguments[j]);
    }
  }
  printf(">\n");
}

 /** prints the model of the given kissat solver */
void printModel(CaDiCaL::Solver* solver, int* in_vars, struct AAF* aaf){
	  printf("{");
  char isFirst = TRUE;
  for(int i = 0; i < aaf->number_of_arguments; i++){
    if(solver->val(in_vars[i])< 0)
      continue;
    if(isFirst)
      isFirst = FALSE;
    else printf(",");
    printf("%s", aaf->ids2arguments[i]);
  }
  printf("}\n");
}

 /* ============================================================================================================== */
 /* == END FILE ================================================================================================== */
 /* ============================================================================================================== */
