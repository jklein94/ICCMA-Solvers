/Users/mthimm/Documents/software/cpp/taas-fudge-v3.1/taas-fudge -sat /Users/mthimm/Documents/software/cpp/taas-fudge-v3.1/lib/cadical-1.3.1/build/cadical $@
