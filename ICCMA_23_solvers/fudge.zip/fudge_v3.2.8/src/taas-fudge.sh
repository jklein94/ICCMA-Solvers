#!/bin/bash
$(dirname "$0")/taas-fudge -sat $(dirname "$0")/lib/cadical-1.3.1/build/cadical $@
