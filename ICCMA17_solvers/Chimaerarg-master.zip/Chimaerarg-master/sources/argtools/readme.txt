please put here FindStableExtensions.cpp from argtools
