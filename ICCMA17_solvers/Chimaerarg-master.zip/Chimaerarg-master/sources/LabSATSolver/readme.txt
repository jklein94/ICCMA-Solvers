please extract here LabSATSolver version submitted to ICMMA2015
