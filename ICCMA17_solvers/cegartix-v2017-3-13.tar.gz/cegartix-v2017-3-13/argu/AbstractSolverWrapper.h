// 
// Copyright (c) 2012-2017, Johannes Wallner
// 
// This file (AbstractSolverWrapper.h) is part of cegartix
// 
// cegartix is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// cegartix is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with cegartix; if not, write to the Free Software
// Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
//

#ifndef ABSTRACTSOLVERWRAPPER_H_
#define ABSTRACTSOLVERWRAPPER_H_

#include <vector>

// structure for abstract literal. The algorithm works on this structure and it is then transformed to concrete literals
struct AbstractLit {
    int     x;
    bool    pol;

    friend AbstractLit mkAbstrLit(int var, bool pol = true);
};

inline AbstractLit  mkAbstrLit (int var) { AbstractLit p;
p.x = var;
p.pol = true;
return p; }
inline AbstractLit operator~(AbstractLit p) { p.pol = !p.pol; return p; }

#define abstr_l_True  (0)
#define abstr_l_False (1)
#define abstr_l_Undef (2)

// virtual class for solver wrappers. Algorithm works on this class
class AbstractSolverWrapper
{
public:
	virtual ~AbstractSolverWrapper(void) {};
	virtual bool addClause(AbstractLit p) =0;
	virtual bool addClause(AbstractLit p, AbstractLit q) =0;
	virtual bool addClause(AbstractLit p, AbstractLit q, AbstractLit r) =0;
	virtual bool addClause_(std::vector<AbstractLit>& ps) =0;
	virtual int newVar() =0;
	virtual bool solve() =0;
	virtual bool solveLimited(std::vector<AbstractLit>& assumps) =0;
	virtual std::vector<int> model() =0;
	virtual bool simplify() =0;
	bool externalError;
	// helper: vec to vector and vice versa
	//Minisat::vec<Minisat::lbool> toVec(std::vector<int> vector);
	//std::vector<int> toVector(Minisat::vec<Minisat::lbool> vec);
};


//class ClaspWrapper: public AbstractSolverWrapper
//{
//public:
//	Clasp::ClaspFacade libclasp;
//};

//class ClaspCallback : public Clasp::ClaspFacade::Callback
//{
//
//};
//
//class ClaspProblem: public Clasp::Input
//{
//
//};


#endif /* ABSTRACTSOLVERWRAPPER_H_ */
