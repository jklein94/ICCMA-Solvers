// 
// Copyright (c) 2012-2017, Johannes Wallner
// 
// This file (Argusat.h) is part of cegartix
// 
// cegartix is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// cegartix is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with cegartix; if not, write to the Free Software
// Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
//

#ifndef ARGUSAT_H
#define ARGUSAT_H

#include "stdio.h"
#include <map>
#include "string"
//#include "mtl/Vec.h"
#include "utils/Options.h"
//#include "core/Solver.h"
//#include "core/SolverTypes.h"
#include "iostream"
#include <vector>
#include <algorithm>
#include "AbstractSolverWrapper.h"
#include "ArguSolverFactory.h"
//#include <clasp/clause.h>
//#include <clasp/clasp_facade.h>
// #include <memory>
#include <boost/shared_ptr.hpp>

//using namespace Minisat;

// simple logging macro
#define LOGSAT(MSG) do {std::cout << MSG << std::endl;} while (0)
//#define LOG(MSG) do {std::cout << "log:" << MSG << std::endl;} while (0)
#define LOG(MSG)

class Argusat
{
public:
  // constructor
  Argusat(boost::shared_ptr<ArguSolverFactory> infactory);
  ~Argusat();

  std::map<std::string,int> argToId; //arg "a" -> 0
  std::map<int,std::string> idToArg; //0 -> "a"
  std::map<int,int> argCountAtts; //arg 0 -> 3
  std::multimap<int,int> idToAttackersId;
  std::multimap<int,int> idToAttackedId; // arg id 0 to args attacked by 0
  int maxArg; // 0,1,2,3,4,...,n=numberOfArgs, every var above is a range var.
  boost::shared_ptr<AbstractSolverWrapper> mainQuery; // contains main query with all learnt stuff. corresponds to phi in paper
  boost::shared_ptr<AbstractSolverWrapper> auxQuery; // contains an auxiliary query. Will be added/removed/changed over time.
  boost::shared_ptr<AbstractSolverWrapper> storeStableQuery;
  int storeStableFlag;
  int storedStableExists;
  std::vector< std::vector<int> > storedStableExts;
  int semantics;
  boost::shared_ptr<ArguSolverFactory> factory;
  int mode;
  int extNumGoal;
  int idQueryArg;

  int initialize();
  
  int grounded();
  
  int enumerateNP();
  
  int credNP();
  
  int skeptNP();
  
  int cegar();
  
  int dung();
  
  int ideal();
  
  // methods for formula construction
  int solve();

  // constructs the query which only contains the AF and formulae for chosen semantics, e.g. complete does NOT contain cred/skept query.
  int constructSemanticsFormulae(boost::shared_ptr<AbstractSolverWrapper> solver);

  // ArgumentSetIterator. Returns the next argument set. e.g. 0,1,2,3,5 -> 0,1,2,3,6, 0,3,11 -> 0,4,5 if 11 is argmax, Assumes a correct set as input
  int nextArgumentSet(std::vector<int>& arguSet);

  // the following functions take a _sorted_ vector of args as input (this is the set S or I) and constructs a vec Lit or adds it directly to the solver

  // for F_S in algorithm
  int argsToLits_range(std::vector<int>& args, std::vector<AbstractLit> &lits);

  // for learning in the first loop
  int argsToLits_learn_range(std::vector<int>& args, boost::shared_ptr<AbstractSolverWrapper> solver,bool sat);

  // for psi in the second loop
  int argsToLits_aux(std::vector<int>& args, boost::shared_ptr<AbstractSolverWrapper> solver);

  // for phi in the second loop
  int argsToLits_learn(std::vector<int>& args, boost::shared_ptr<AbstractSolverWrapper> solver);

  // extracts model from the solver into a new vector, which we can sort and use otherwise.
  int extractModel(std::vector<int> solverModel, std::vector<int> &model);

  // sets limits start and max to 0,maxArg or if we learn range to maxArg+1,2*maxArg+1
  void getLimits(int &start, int &max);

  int getResult(bool result, bool cred, bool externalError);
};

#endif // ARGUSAT_H
