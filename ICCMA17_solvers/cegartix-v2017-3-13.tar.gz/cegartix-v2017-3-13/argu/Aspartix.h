// 
// Copyright (c) 2012-2017, Johannes Wallner
// 
// This file (Aspartix.h) is part of cegartix
// 
// cegartix is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// cegartix is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with cegartix; if not, write to the Free Software
// Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
//


#ifndef ASPARTIX_H
#define ASPARTIX_H

#include <argu/Argusat.h>
#include "string.h"
#include "istream"
#include "iostream"
#include <boost/tokenizer.hpp>
#include <boost/algorithm/string/trim.hpp>
#include "stdio.h"
#include "Argusat.h"
//#include "MinisatWrapper.h"

// basically copy from Dimacs.h

// format: arg(X).  att(X,Y). comments: %
// n args, m atts
// we need an int n - then we see for all larger than n that it is a helper var
// for each encountered var, check if it is already in data struct, otherwise add
// for each new var S.newVar
// add it to a lits vector

// hashmap from arg string to arg int second one for backward

// hashmap which results in vector of attackers of arg int

class Aspartix
{
public:

  // parse the input file
  static int parse_ASPARTIX(std::istream* input, Argusat& argu);
  static int addArgument(Argusat &argu,std::string* arg);
  static int addAttack(Argusat &argu,int attacker,int attacked);
};

#endif // ASPARTIX_H
