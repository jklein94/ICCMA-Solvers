// 
// Copyright (c) 2012-2017, Johannes Wallner
// 
// This file (Aspartix.cc) is part of cegartix
// 
// cegartix is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// cegartix is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with cegartix; if not, write to the Free Software
// Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
//

#include "Aspartix.h"

typedef boost::tokenizer<boost::char_separator<char> > tokenizer;

int Aspartix::parse_ASPARTIX(std::istream* input, Argusat &argu) {
  // string for each line
  std::string line, arg;
  int attacker=0,attacked=0;

  LOG("Parse input");
  //while we didnt reach the end
  while (! input->eof() )
  {
    getline (*input,line);

    boost::algorithm::trim(line);

    std::string firstchar = line.substr(0,1);

    // ignore "/" or newlines or comments (%)
    if (firstchar.compare("/") == 0
        || line.length() == 0
        || firstchar.compare("%") == 0)
      continue;

    std::string compLine = line.substr(0,3);

    if (compLine.compare("arg")==0) {
      // argument
      boost::char_separator<char> sep("()"); // tokenize

      // tokenize
      tokenizer tok(line,sep);
      tokenizer::iterator beg=tok.begin();
      ++beg;

      // argument
      arg = *beg;
      addArgument(argu,&arg);

    } else if (compLine.compare("att")==0) {
      // attack
      boost::char_separator<char> sep("(,)"); // tokenize

      // tokenize
      tokenizer tok(line,sep);
      tokenizer::iterator beg=tok.begin();
      ++beg;

      // extract argument
      arg = *beg;
      attacker=addArgument(argu,&arg);
      LOG("Attacker:" + arg);
      ++beg;
      arg = *beg;
      LOG("Attacked: " + arg);
      attacked=addArgument(argu,&arg);
      addAttack(argu,attacker,attacked);
    } else {
      // parse error
      LOG("Parse error (ignore line):" + line);
    }
  }
  LOG("Max argument index: " << argu.maxArg);
  return 0;
}

int Aspartix::addArgument(Argusat &argu,std::string* arg) {

  int ret = 0;
  // check if it already exists
  if (argu.argToId.count(*arg) == 0) {
    ret = ++argu.maxArg;
    argu.argToId[*arg] = argu.maxArg;
    argu.idToArg[argu.maxArg] = *arg;
    argu.argCountAtts[argu.maxArg] = 0;
    LOG("Argument added: " + *arg);
  } else {
    ret = argu.argToId[*arg];
  }
  return ret;
}

int Aspartix::addAttack(Argusat &argu,int attacker, int attacked) {
  argu.idToAttackersId.insert(std::pair<int,int>(attacked,attacker));
  argu.idToAttackedId.insert(std::pair<int,int>(attacker,attacked));
  argu.argCountAtts[attacked] = argu.argCountAtts[attacked] + 1;
  return 0;
}
