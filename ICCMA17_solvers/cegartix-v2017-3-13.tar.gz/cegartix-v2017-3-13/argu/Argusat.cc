// 
// Copyright (c) 2012-2017, Johannes Wallner
// 
// This file (Argusat.cc) is part of cegartix
// 
// cegartix is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// cegartix is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with cegartix; if not, write to the Free Software
// Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
//


#include "argu/Argusat.h"
#include <stack> 
//#include "simp/SimpSolver.h"

#define CNF_CF 0x01
#define CNF_ADM 0x02
#define CNF_COMP 0x04
#define CNF_RANGE_VARS 0x08
#define LEARN_RANGE 0x10
#define ID_CEGAR 0x20
#define STB_CLAUSES 0x40
//#define ALL 0x3F

//define semantics
/*
 * CNF_CF         ... adds clauses for conflict-freeness
 * CNF_ADM        ... adds remaning clauses for admissibility
 * CNF_COMP       ... adds remaining clauses for complete
 * CNF_RANGE_VARS ... adds clauses for range
 * LEARN_RANGE    ... learns range clauses instead of normal variables
 *
 */
#define SEM_ADM   CNF_CF + CNF_ADM
#define SEM_COM   CNF_CF + CNF_ADM + CNF_COMP + CNF_RANGE_VARS
#define SEM_STB   CNF_CF + CNF_ADM + STB_CLAUSES + CNF_RANGE_VARS 
#define SEM_GRD   0
#define SEM_IDL   -1
#define SEM_DUNG  -2
// base semantics:
#define SEM_PREF  CNF_CF + CNF_ADM + CNF_COMP + CNF_RANGE_VARS               + ID_CEGAR
#define SEM_SEMI  CNF_CF + CNF_ADM + CNF_COMP + CNF_RANGE_VARS + LEARN_RANGE + ID_CEGAR
#define SEM_STAGE CNF_CF +                      CNF_RANGE_VARS + LEARN_RANGE + ID_CEGAR

#define MODE_ENUM  0
#define MODE_CRED  1
#define MODE_SKEPT 2

// depending on cred/skept change the output
#define RESULTACCEPTANCE(RESULT,CRED) (CRED) ? RESULT : !RESULT

//=================================================================================================
// Options:
static const char* _cat = "ARGU";

static Minisat::StringOption opt_arg_argument     (_cat, "argument",     "Argument for query.", "0");
static Minisat::StringOption opt_arg_semantics    (_cat, "semantics",    "Semantics: pref,semi,stage", "pref");
static Minisat::StringOption opt_arg_mode         (_cat, "mode",         "Reasoning mode: cred(olous), skept(ical), enum(eration), or first (extension found)", "enum");
static Minisat::IntOption    opt_arg_depth        (_cat, "depthArg",     "Depth of shortcuts (-1 for off, otherwise up to 2).", -1, Minisat::IntRange(-1,2));
static Minisat::IntOption    opt_arg_extnum       (_cat, "extNum",       "Number of extensions to enumerate (with enum).", 0, Minisat::IntRange(0,INT32_MAX));

Argusat::Argusat(boost::shared_ptr<ArguSolverFactory> infactory) :
    maxArg (-1) // highest ID of arguments (-1 if no args are present)
{
	factory = infactory;
}

Argusat::~Argusat()
{
// 	delete mainQuery;
// 	delete factory;
}

int Argusat::initialize() {
  
  storeStableFlag = false;
  storedStableExists = false;
  
  std::string queryArg = (std::string)opt_arg_argument, mode_parsed = (std::string)opt_arg_mode;
  if (mode_parsed.compare("skept")==0) {
    mode = MODE_SKEPT;
    LOG("Mode: skeptical");
  } else if (mode_parsed.compare("cred")==0) {
    mode = MODE_CRED;
    LOG("Mode: credulous");
  } else if (mode_parsed.compare("enum")==0) {
    mode = MODE_ENUM;
    LOG("Mode: enumeration");
  } else {
    LOGSAT("Unknown mode: " << mode_parsed);
    exit(1);
  }
  
  if(queryArg.compare("")!=0 && (mode == MODE_SKEPT || mode == MODE_CRED )) {
      if (argToId.count(queryArg)>0) {
	idQueryArg = argToId[queryArg];
      } else {
	std::cout << "Error: Queried argument " << queryArg << " not part of AF.";
	return 1;
      }
  }
  
  // number of exts to compute
  extNumGoal = (int)opt_arg_extnum;
  
  // get semantics
  std::string s_semantics = (std::string)opt_arg_semantics;
  if (s_semantics.compare("pref")==0) {
    semantics = SEM_PREF;
    LOG("Semantics: Preferred");
  } else if (s_semantics.compare("semi")==0) {
    semantics = SEM_SEMI;
    LOG("Semantics: Semi-stable");
  } else if (s_semantics.compare("stage")==0) {
    semantics = SEM_STAGE;
    LOG("Semantics: Stage");
  } else if (s_semantics.compare("adm")==0) {
    semantics = SEM_ADM;
    LOG("Semantics: Admissible");
  } else if (s_semantics.compare("com")==0) {
    semantics = SEM_COM;
    LOG("Semantics: Complete");
  } else if (s_semantics.compare("grd")==0) {
    semantics = SEM_GRD;
    LOG("Semantics: Grounded");
  } else if (s_semantics.compare("stable")==0) {
    semantics = SEM_STB;
    LOG("Semantics: Stable");
  } else if (s_semantics.compare("ideal")==0) {
    semantics = SEM_IDL;
    LOG("Semantics: Ideal");
  } else if (s_semantics.compare("dung")==0) {
    semantics = SEM_DUNG;
    LOG("Semantics: Dung");
  } else {
    LOGSAT("Unknown Semantics: " << semantics);
    exit(1);
  }
  
  switch (semantics) {
	case SEM_GRD:
		if (mode == MODE_CRED) {mode = MODE_SKEPT;}
		grounded();
		break;
	case SEM_PREF:
		if (mode == MODE_CRED) {semantics = SEM_ADM; credNP(); return 0;}
		cegar();
		break;
	case SEM_SEMI:
		cegar();
		break;
	case SEM_STAGE:
		cegar();
		break;
	case SEM_DUNG:
		mode = MODE_ENUM;
		extNumGoal=0;
		dung();
		break;
	case SEM_IDL:
		if (mode == MODE_CRED) {mode = MODE_SKEPT;}
		ideal();
		break;
	case SEM_ADM:
		if (mode == MODE_SKEPT) {std::cout << "NO"; return 0;}
	case SEM_COM:
		if (mode == MODE_SKEPT) {grounded(); return 0;}
		if (mode == MODE_CRED) {semantics=SEM_ADM;}
	case SEM_STB: // equal to default
	default:
		if (mode == MODE_SKEPT) {skeptNP();}
		if (mode == MODE_CRED) {credNP();}
		if (mode == MODE_ENUM) {std::cout << "["; enumerateNP(); std::cout << "]";}
		break;
  }
  
  

  return 0;
}

int Argusat::grounded() {
  
  std::stack<int> argsToProcess;
  std::map<int,int> outArgs;
  
  int firstArgInGrd = false;
  
  if (mode==MODE_ENUM) {std::cout << "[[";}
  
  for (std::multimap<int,int>::iterator it=argCountAtts.begin(); it!=argCountAtts.end(); ++it) {
    std::pair<int,int> unattackedArg =(*it);
    if (unattackedArg.second > 0 ) {continue;};
    
    int currentArg = unattackedArg.first;
    
    if (mode == MODE_SKEPT && currentArg == idQueryArg) { std::cout << "YES"; return 0; }
    if (mode==MODE_ENUM) { if (firstArgInGrd ) {std::cout << ",";} std::cout << idToArg[currentArg]; }
    
    firstArgInGrd = true;
    
    while(true) {
      
      std::multimap<int,int>::iterator itOut = idToAttackedId.find(currentArg);
      if (itOut != idToAttackedId.end()) {
      do {
        std::pair<int,int> att =(*itOut);
        
	int outArg = att.second;
	
	// check if already visited
	if (outArgs.count(outArg)==0) { 
	
	  outArgs.insert(std::pair<int,int>(outArg,1));

	  std::multimap<int,int>::iterator itDecrArg = idToAttackedId.find(outArg);
	  if (itDecrArg != idToAttackedId.end()) {
	  do {
	    std::pair<int,int> att2 =(*itDecrArg);
	  
	    int DecrArg = att2.second;
	  
	    if (argCountAtts[DecrArg] == 1) {
	      argsToProcess.push(DecrArg);
	    } else if (argCountAtts[DecrArg] > 1) {
	      argCountAtts[DecrArg] = argCountAtts[DecrArg] - 1;
	    };

	    itDecrArg++;
	  } while (itDecrArg != idToAttackedId.upper_bound(outArg));
	  }
	}

        itOut++;
      } while (itOut != idToAttackedId.upper_bound(currentArg));
      }
    
      if (argsToProcess.empty()) {
	break;	
      }
      
      currentArg = argsToProcess.top();
      if (mode == MODE_SKEPT && currentArg == idQueryArg) { std::cout << "YES"; return 0; }
      if (mode==MODE_ENUM) { std::cout << "," << idToArg[currentArg]; }
      argsToProcess.pop();
    }
    
  }
  
  if (mode==MODE_ENUM) {
    std::cout << "]]";
  } else if (mode == MODE_CRED || mode == MODE_SKEPT) {
    std::cout << "NO";
  }
  
  return 0;
}
  
int Argusat::enumerateNP() {
  
  std::vector<AbstractLit> dummy;
  mainQuery = factory->getSolver(); 
  constructSemanticsFormulae(mainQuery);
  
  
  int firstExt = true;
  
  int numOfExts=0;
  
  while ( (numOfExts<extNumGoal || extNumGoal==0 ) && (mainQuery->solveLimited(dummy) == true)) {
    
    
    numOfExts++;
    
    int firstArg = true;
    std::vector<AbstractLit> disjunctiveClause;
    std::vector<int> stableExt;
    
    if (firstExt) {firstExt=false;} else {std::cout << ",";}
    
    if (storeStableFlag) {
      storedStableExists = true;
      std::vector<int> model;
      extractModel(mainQuery->model(), model);
      std::sort(model.begin(),model.end());
      argsToLits_learn(model,storeStableQuery);
    }
    
    std::cout << "[";
    for (int i=0;i<mainQuery->model().size();i++) {
//       std::cout << "size:" << mainQuery->model().size() << "SIZEND";
      AbstractLit add;
      	
      if (mainQuery->model()[i] == abstr_l_True) {
	add = ~mkAbstrLit(i);
	
	if (i>maxArg) {continue;}
	
	if (storeStableFlag) {
	  stableExt.push_back(i);
	}
	
	if (!firstArg) {
	  std::cout << "," << idToArg[i];
	} else {
	  std::cout << idToArg[i];
	  firstArg = false;
	}
	
      } else {
	add = mkAbstrLit(i);
      }
      
      disjunctiveClause.push_back(add);
	
    }
    
    if (storeStableFlag) { storedStableExts.push_back(stableExt); }
    
    mainQuery->addClause_(disjunctiveClause);
    std::cout << "]";
  }
 
  return 0;
}

int Argusat::credNP() {
 
  mainQuery = factory->getSolver(); 
  constructSemanticsFormulae(mainQuery);
  AbstractLit queryLit = mkAbstrLit(idQueryArg);
  mainQuery->addClause(queryLit);   
  std::vector<AbstractLit> dummy;
  
  if (mainQuery->solveLimited(dummy)) {std::cout << "YES";} else {std::cout << "NO";}
  
  return 0;
}

int Argusat::skeptNP() {
  
  mainQuery = factory->getSolver(); 
  constructSemanticsFormulae(mainQuery);
  AbstractLit queryLit = ~mkAbstrLit(idQueryArg);
  mainQuery->addClause(queryLit);   
  std::vector<AbstractLit> dummy;
  
  if (mainQuery->solveLimited(dummy)) {std::cout << "NO";} else {std::cout << "YES";}
  
  return 0;
}

int Argusat::ideal() {
 
  semantics=SEM_ADM;
  mainQuery = factory->getSolver(); 
  constructSemanticsFormulae(mainQuery);
  std::vector<AbstractLit> disjunctiveClause, dummy;
  std::vector<int> credAdm (maxArg+1,0), idealApprox;
  
  for (int i=0;i<=maxArg;i++) {
   disjunctiveClause.push_back(mkAbstrLit(i));
  }

  mainQuery->addClause_(disjunctiveClause);
  
  while (mainQuery->solveLimited(dummy) == true) {
    
    disjunctiveClause.clear();
   
    for (int i=0;i<mainQuery->model().size();i++) {
      
      if (i>maxArg) {break;}
	
      if (mainQuery->model()[i] == abstr_l_True) {
	credAdm[i] = 1;
      } else if (credAdm[i] == 0) {
	    
	disjunctiveClause.push_back(mkAbstrLit(i));
      }
      
    }
    
    mainQuery->addClause_(disjunctiveClause);
    
  }
  
//   TODO: there is most likely a bug here: the AF construction or fix-point computation fails (resulting set is not admissible
  
  std::multimap<int,int>::iterator itAdjacent,itDef;
  
  for (int i=0;i<=maxArg;i++) {
    
    int check=true;
    
    if (credAdm[i]==1) {
      
      itAdjacent = idToAttackersId.find(i);
      if(itAdjacent != idToAttackersId.end()) {
	do {
	  if (credAdm[(*itAdjacent).second]==1) { check=false;} 
	  itAdjacent++;
	} while (itAdjacent != idToAttackersId.upper_bound(i));
	
      }
      
      itAdjacent = idToAttackedId.find(i);
      if(itAdjacent != idToAttackedId.end()) {
	do {
	  if (credAdm[(*itAdjacent).second]==1) { check=false;} 
	  itAdjacent++;
	} while (itAdjacent != idToAttackedId.upper_bound(i));
	
      }
      
      if (check) { idealApprox.push_back(i); }
      
    }
 
    
  }
  
  
  int fixpoint = false;
  
  
  
  while (!fixpoint) {
//   std::cout << "FIX";
    fixpoint = true;
    
//     int curMaximum = idealApprox.size();
    
    for (int i=0;i<idealApprox.size();i++) {
//       std::cout << "check:" << idToArg[idealApprox[i]];
      int remove = false;
      
      itAdjacent = idToAttackersId.find(idealApprox[i]);
      if(itAdjacent != idToAttackersId.end()) {
	do {
// 	  std::pair<int,int> att =(*itAdjacent);
	  remove = true;
	  itDef = idToAttackersId.find((*itAdjacent).second);
	  if(itDef != idToAttackersId.end()) {
	    do {
	      
	      for (int j=0;j<idealApprox.size();j++) {
		if (idealApprox[j] == (*itDef).second) {remove=false;}
	      }
	      
	      if(!remove) {break;}
	      
	      itDef++;
	    } while (itDef != idToAttackersId.upper_bound((*itAdjacent).second));
	  }
	  
	  if(remove) {break;}
	  
	  itAdjacent++;
	} while (itAdjacent != idToAttackersId.upper_bound(idealApprox[i]));
      } 
//       else {
// 	remove=false;
//       }
      
      if (remove) {
// 	std::cout << "REM" << idToArg[idealApprox[i]];
	idealApprox.erase(idealApprox.begin()+i);
	i--;
	fixpoint = false;
	if (i==idealApprox.size()) {break;}
      }
      
      
    }
    
    
  }
  
  int printfirstArg = true;
  
  if (mode==MODE_ENUM) {std::cout << "[[";}
  
  for (int j=0;j<idealApprox.size();j++) {
    
    if (mode == MODE_SKEPT && idealApprox[j] == idQueryArg) {
      std::cout << "YES";
      return 0;
    } else if (mode==MODE_ENUM ) {
    
      if (printfirstArg) {
	std::cout << idToArg[idealApprox[j]]; printfirstArg=false;
      } else {
	std::cout << "," <<  idToArg[idealApprox[j]];
      }
      
    }
  }
  
  if (mode==MODE_ENUM) {std::cout << "]]";}
  
  if (mode == MODE_SKEPT) {std::cout << "NO";}
  
  return 0;
}

int Argusat::dung() {
 
  storeStableFlag = true;
  storeStableQuery = factory->getSolver();
  semantics=SEM_PREF;
  constructSemanticsFormulae(storeStableQuery);
  
//   std::cout << "[";
  semantics = SEM_GRD;
  grounded();
//   std::cout << "]";
  
  std::cout << ",";
  
  std::cout << "[";
  semantics = SEM_STB;
  enumerateNP();
  std::cout << "]";
  
  std::cout << ",";
  
  std::cout << "[";
  
  int firstExt=true;
  
  for (int i=0;i<storedStableExts.size();i++) {
    int firstArg = true;
    if (firstExt) {std::cout << "["; firstExt=false;} else {std::cout << ",[";}
    for (int j=0;j<storedStableExts[i].size();j++) {
      
      if (!firstArg) {
	  std::cout << "," << idToArg[storedStableExts[i][j]];
	} else {
	  std::cout << idToArg[storedStableExts[i][j]];
	  firstArg = false;
	}
      
    }
    std::cout << "]";
  }  
  
  if (!storedStableExts.empty()) {storedStableExists = true;}
  
  
  semantics = SEM_PREF;
  mainQuery = storeStableQuery;
  solve();
  std::cout << "]";
  
  return 0;
}

int Argusat::cegar() {
 
  mainQuery = factory->getSolver();
  if (mode==MODE_ENUM) { std::cout << "[";}
  solve();
  if (mode==MODE_ENUM) { std::cout << "]";}
  return 0;
}



int Argusat::solve() {
	//Clasp::ClauseCreator nc;
	//Clasp::ProgramBuilder api;
	//api.startProgram(ctx);
	//api.setAtomName(1, "a");
	//api.Incremental
  /*
    datastructures:
    formulae (= solvers)
    basicQuery (phi init)
    mainQuery for second loop (contains all learned stuff)
    tempQuery for second loop containing cred/skept Query, and PSI

    first while loop
    array F_S contains range unit vars and is initialized with ArgumentSetIterator
    d_curr = 1 initially
    idea: generate a F_S with d_current
      with d-1,d-2,d-3,...,0
      mkLit out of these (be careful, need range vars)
      run SAT (BasicQuery + F_S + Cred/skept Query)
    after that next set is easily generated, increment first element of F_S, if at max, then increase last, if at max, incr last but one, etc...

    first if
    second if


  */
	bool externalError = false;
  int firstExt = true;
  int numOfExts=0;

  // get semantics
//   std::string s_semantics = (std::string)opt_arg_semantics;
//   if (s_semantics.compare("pref")==0) {
//     semantics = SEM_PREF;
//     LOG("Semantics: Preferred");
//   } else if (s_semantics.compare("semi")==0) {
//     semantics = SEM_SEMI;
//     LOG("Semantics: Semi-stable");
//   } else if (s_semantics.compare("stage")==0) {
//     semantics = SEM_STAGE;
//     LOG("Semantics: Stage");
//   } else {
//     LOGSAT("Unknown Semantics: " << semantics);
//     exit(1);
//   }

  // query (reasoning mode)
  std::string queryArg = (std::string)opt_arg_argument, mode_parsed = (std::string)opt_arg_mode;
  if (mode_parsed.compare("skept")!=0 && mode_parsed.compare("cred")!=0 && mode_parsed.compare("enum")!=0 && mode_parsed.compare("first")!=0) {
    LOGSAT("ERROR: unknown reasoning mode: " << mode_parsed);
    exit(1);
  }
//   if (mode_parsed.compare("cred")==0 && semantics==SEM_PREF) {
//     LOGSAT("Credulous mode for preferred semantics not supported");
//     exit(1);
//   }

  AbstractLit queryLit;
  bool cred = false;
  
  // for skept/cred we set queryLit
  if (mode_parsed.compare("skept")==0 || mode_parsed.compare("cred")==0) {
    if(queryArg.compare("")!=0) {
      if (argToId.count(queryArg)>0) {
	if (mode_parsed.compare("skept")==0) {
	  queryLit = ~mkAbstrLit(argToId[queryArg]);
	  cred = false;
	} else {
	  queryLit = mkAbstrLit(argToId[queryArg]);
	  cred = true;
	}
      } else {
	LOGSAT("Argument for query (" << queryArg << ") is not part of AF");
	exit(1);
      }
    }
  }

  // get depth
  int depth = (int)opt_arg_depth;
  LOG("Depth: " << depth);

  LOG("Start Algorithm");
  /*
    Algorithm according to paper Wolfgang Dvorak, Matti Jaervisalo
  */

  /*
    Initialization
    Main datastructures:
    mainQuery, auxQuery of type SimpSolver
    first stores the "phi" in the paper, i.e. the main formulae. It is never removed or weakened, we only add formulae
    the second stores auxiliary queries, usually denoted by psi in the paper. auxQuery may often be removed and newly instantiated
  */

  // initialize phi, i.e. the basic formulae for semantics in the mainquery
  // note: the query for desired skept/cred argument is added here, but for all other queries the argument is given as an argument to the solver
  LOG("Initialization");
  
//   mainQuery = factory->getSolver(); // construct mainQuery
  if (!storeStableFlag) {constructSemanticsFormulae(mainQuery);}    // typical construction. the argument solver gets the basic clauses for the chosen semantics
  
  if (mode_parsed.compare("skept")==0 || mode_parsed.compare("cred")==0) {
    mainQuery->addClause(queryLit);             // add the query literal
  }
  int firstloop=0, secondloop=0, satcalls=0; // counters just for statistics

  /*
    First While Loop ("shortcuts")
  */
  LOG("First while loop");
  auxQuery = factory->getSolver();
  constructSemanticsFormulae(auxQuery);
  int currentArg = -1,curDepth=0, queryInt = argToId[queryArg];
  // complSet: complementary set, stores vars which should not be in; whiteset: stores vars which should be later taken in two-element sets
  std::vector<int> complSet, whiteSet;
  //set.push_back(0);
  std::vector<AbstractLit> f_s;
  std::vector<int>::iterator it1,it2;

  // for preferred we do a simple check
  if (semantics == SEM_PREF && depth>=0) {
    // add cnf for all attackers of queryArg
    std::multimap<int,int>::iterator it;
    std::vector<int>::iterator itL;
    std::vector<AbstractLit> lits_attackers;
    std::vector<int> attackers;
    it = idToAttackersId.find(queryInt);
    if(it != idToAttackersId.end()) {
      do {
        std::pair<int,int> att =(*it);
        lits_attackers.push_back(mkAbstrLit(att.second));
        attackers.push_back(att.second);
        it++;
      } while (it != idToAttackersId.upper_bound(queryInt));
    }
    auxQuery->addClause_(lits_attackers);
    satcalls++;
    if (auxQuery->solve()) {
      externalError = auxQuery->externalError;
//       delete auxQuery;
      LOGSAT("terminated in first (1) loop");
      LOGSAT("SAT calls: " << satcalls << " first loop: " << firstloop << " second loop: " << secondloop);
      return getResult(true,cred,externalError);
    } else {
      // learn
	  if (auxQuery->externalError) {
// 		delete auxQuery;
		return getResult(false,false,true);
      }
      itL = attackers.begin();
      while (itL != attackers.end()) {
        mainQuery->addClause(~mkAbstrLit(*itL));
        itL++;
      }
    }
  } else { // for semi and stage we do a more sophisticated check
    while (curDepth <= depth) {
      firstloop++;
      f_s.clear();
      argsToLits_range(complSet,f_s);
      f_s.push_back(queryLit);
      auxQuery->simplify();

      // check
      satcalls++;
      if (auxQuery->solveLimited(f_s) == true) {
        // accept
    	externalError = auxQuery->externalError;
//         delete auxQuery;
        LOGSAT("terminated in first (1) loop");
        LOGSAT("SAT calls: " << satcalls << " first loop: " << firstloop << " second loop: " << secondloop);
        return getResult(true,cred,externalError);;
      } else {
    	if (auxQuery->externalError) {
//     	  delete auxQuery;
    	  return getResult(false,false,true);
    	}
        // learn and update set

        // learn
        f_s.clear();
        argsToLits_range(complSet,f_s);
        auxQuery->simplify();

        satcalls++;
        if (auxQuery->solveLimited(f_s) == true) {

          // learn TRUE
          argsToLits_learn_range(complSet,mainQuery,true);
          if (currentArg==-1) {
        	externalError = auxQuery->externalError;
            LOGSAT("terminated in first (1) loop");
            LOGSAT("SAT calls: " << satcalls << " first loop: " << firstloop << " second loop: " << secondloop);
            return getResult(false,cred,externalError);
          }
        } else {
          // learn FALSE
          argsToLits_learn_range(complSet,mainQuery,false);
          if (currentArg >=0 && currentArg <=maxArg)
            whiteSet.push_back(currentArg);
        }
        if (auxQuery->externalError) {
//           delete auxQuery;
          return getResult(false,false,true);
        }
      }

      // next set
      // all one - element sets
      if (currentArg < maxArg) {
        currentArg++;
        complSet.clear();
        complSet.push_back(currentArg);
        if (curDepth==0)
          curDepth++;
      } else {
        if (currentArg == maxArg) { // TODO was just "=" before... i.e. was only executed at most twice... could have some effects..
          // init
          currentArg = maxArg+1;
          it1 = whiteSet.begin();
          it2 = whiteSet.begin();
          curDepth++;
          if (it1 == whiteSet.end())
            break;
        }

        if (++it2 == whiteSet.end()) {
          if (++it1 == whiteSet.end())
            break;
        }

        complSet.clear();
        complSet.push_back(*it1);
        complSet.push_back(*it2);

        // do the iterator thing

      }

      /*if (auxQuery->solveLimited(dummy2) == l_True) {
        // accept
        delete auxQuery;
        LOGSAT("accept in first loop");
        return l_True;
      } else {
        // learn and update set

        // learn
        f_s.clear();
        argsToLits_range(set,f_s);
        //auxQuery->simplify();
        delete auxQuery;
        auxQuery = new SimpSolver;
        constructSemanticsFormulae(auxQuery);
        // test: dont use assumps
        for (int k=0;k<=f_s.size()-1;k++)
          auxQuery->addClause(f_s[k]);

        if ((semantics==SEM_PREF) || (auxQuery->solveLimited(dummy2) == l_True)) { // TODO add for preferred no check necessary
          // learn TRUE
          argsToLits_learn_range(set,mainQuery,true);
        } else {
          // learn FALSE
          argsToLits_learn_range(set,mainQuery,false);
        }

        if (nextArgumentSet(set)==0) {
          curDepth++;
          if (curDepth>depth) break;
          set.clear();
          for (int i=0;i<=curDepth-1;i++)
            set.push_back(i);
        }
      }
    }*/
    }
  }

  /*
    Second While Loop
  */
  LOG("Second while loop");

  std::vector<AbstractLit> dummy, vecQuery; // vecQuery contains only the argument for cred/skept acceptance
  
  if (mode_parsed.compare("skept")==0 || mode_parsed.compare("cred")==0) {
    vecQuery.push_back(queryLit);
  }
  
 
  std::vector<int> model, fullmodel;

  while (mainQuery->solveLimited(dummy) == true) {
	if (mainQuery->externalError) {
		return getResult(false,false,true);
	}
    satcalls++;
    secondloop++;
    // init aux Query
    LOG("Init auxQuery");
//     delete auxQuery;
    auxQuery = factory->getSolver();
    constructSemanticsFormulae(auxQuery);

    // extract model
    LOG("Extraxt model from mainQuery");
    model.clear();
    fullmodel.clear();
    extractModel(mainQuery->model(), model);
    
    // extract full model for enum
    for (int i=0;i<mainQuery->model().size();i++) {
//       if (mainQuery->model()[i]==abstr_l_True)
	fullmodel.push_back(mainQuery->model()[i]);
    }
    
    // sort
    LOG("Sort model");
    std::sort(model.begin(),model.end());

    // construct rest of psi formula
    LOG("Add remaining formulae to auxQuery");
    argsToLits_aux(model,auxQuery);

    // inner while loop
    LOG("Inner while loop start");
    satcalls++;

    
    auxQuery->simplify();
    while (auxQuery->solveLimited(vecQuery) == true) {
    //while (auxQuery->solve()== true) {
      // update model
      if (auxQuery->externalError) {
//     	  delete auxQuery;
    	  return getResult(false,false,true);
      }
      LOG("Update Model");
      model.clear();
      extractModel(auxQuery->model(), model);
      
      // extract full model for enum
      fullmodel.clear();
      for (int i=0;i<auxQuery->model().size();i++) {
// 	if (auxQuery->model()[i]==abstr_l_True)
	  fullmodel.push_back(auxQuery->model()[i]);
      }
      
      std::sort(model.begin(),model.end());

      // add to auxQuery
      LOG("Add to auxQuery");
      auxQuery->simplify();
      argsToLits_aux(model,auxQuery);
      auxQuery->simplify();
    }

    if (auxQuery->externalError) {
//     	delete auxQuery;
  	  return getResult(false,false,true);
    }
    // auxQuery with cred/skept argument is unsat
//     delete auxQuery;
    auxQuery = factory->getSolver();
    constructSemanticsFormulae(auxQuery);
    argsToLits_aux(model,auxQuery);

    
    
    
    
    
    // first and enum modes
    if (mode_parsed.compare("first")==0 || mode_parsed.compare("enum")==0) {
      numOfExts++;
      // print sigma extension 
      if (firstExt) {
	if (storedStableExists) {std::cout << ",";}
	std::cout << "["; 
	firstExt=false;
      } else {std::cout << ",[";} 
      int firstArg=true;
      for (int i=0;i<fullmodel.size();i++) {
	  if (i>maxArg)
	    break;
	  if (fullmodel[i]==abstr_l_True) {
	    if (firstArg) {std::cout << idToArg[i]; firstArg=false;} else {std::cout << "," << idToArg[i];} 
	  }
       }
       std::cout << "]";
       
       if (numOfExts==extNumGoal && 0<extNumGoal) {return 0;}

       // for "first" we're done
       if (mode_parsed.compare("first")==0) {
	 std::cout << std::endl;
	 return getResult(false,false,externalError);
       }
       
       // for semi-stable and stage we enumerate all for current rage
       if (semantics!=SEM_PREF) {
	  boost::shared_ptr<AbstractSolverWrapper> enumQuery= factory->getSolver();
	  constructSemanticsFormulae(enumQuery);
	  
	  std::vector<AbstractLit> forbidlast;
	  forbidlast.clear();
	  
	  // fix range, and forbid already found extension
	  for (int i=0;i<fullmodel.size();i++) {
	      if (i<=maxArg) {
		if (fullmodel[i]!=abstr_l_True) {
// 		  std::cout << "TRUE: " << idToArg[i];
		  forbidlast.push_back(mkAbstrLit(i));
		} else {
// 		  std::cout << "FALSE: " << idToArg[i];
		  forbidlast.push_back(~mkAbstrLit(i));
		}
	      } else if (fullmodel[i] == abstr_l_True) {
// 		std::cout << "RANGE: " << i;
		enumQuery->addClause(mkAbstrLit(i));
	      }
	  }
	  enumQuery->addClause_(forbidlast);
	  enumQuery->simplify();
	  
	  while (enumQuery->solveLimited(dummy) == true) {
	    numOfExts++;
	    forbidlast.clear();
	    if (firstExt) {std::cout << "["; firstExt=false;} else {std::cout << ",[";} 
	    int firstArg=true;
	    for (int i=0;i<enumQuery->model().size();i++) {
	      if (i>maxArg)// || i<start)
		continue;
	      if (enumQuery->model()[i]==abstr_l_True) {
// 		if (fullmodel[i]==abstr_l_True) {
		forbidlast.push_back(~mkAbstrLit(i));
		if (firstArg) {std::cout << idToArg[i]; firstArg=false;} else {std::cout << "," << idToArg[i];} 
// 		}
	      } else {
		forbidlast.push_back(mkAbstrLit(i));
	      }
	    }
	    if (numOfExts==extNumGoal && 0<extNumGoal) {return 0;}
	    enumQuery->addClause_(forbidlast);
	    enumQuery->simplify();
	    std::cout << "]";
	  }
	}
	
	if (numOfExts==extNumGoal && 0<extNumGoal) {return 0;}
	
	std::sort(model.begin(),model.end());
	// learn
	argsToLits_learn(model,mainQuery);
	continue;
    }
    
    
    
//     if (mode.compare("first")==0) {
//        std::cout << "[";
// 
//        for (int i=0;i<fullmodel.size();i++) {
// 	  if (fullmodel[i]>maxArg)
// 	    continue;
// 	  std::cout << idToArg[fullmodel[i]];
// 	  std::cout << ",";
//        }
//        std::cout << "]" << std::endl;
//        
//        return getResult(false,false,externalError);
//     } else if (mode.compare("enum")==0) {
//       
//       if (auxQuery->externalError) {
//     	  delete auxQuery;
//     	return getResult(false,false,true);
//       }
//       
//       
//       
//       
//       if (semantics!=SEM_PREF) {
// 	// enumerate all for current range
// 	AbstractSolverWrapper* enumQuery= factory->getSolver();
// 	constructSemanticsFormulae(enumQuery);
// 	for (int i=0;i<model.size();i++) {
// 	    if (model[i]<=maxArg)
// 	      continue;
// 	    enumQuery->addClause(mkAbstrLit(model[i]));
// 	}
// 	std::vector<AbstractLit> forbidlast;
// 	while (enumQuery->solveLimited(dummy) == true) {
// 	  forbidlast.clear();
// 	  std::cout << "[";
// 	  for (int i=0;i<enumQuery->model().size();i++) {
// 	    if (i>maxArg)// || i<start)
// 	      continue;
// 	    if (enumQuery->model()[i]==abstr_l_True) {
// 	      std::cout << idToArg[i];
// 	      std::cout << ",";
// 	    } else {
// 	      forbidlast.push_back(mkAbstrLit(i));
// 	    }
// 	  }
// 	  enumQuery->addClause_(forbidlast);
// 	  enumQuery->simplify();
// 	  std::cout << "]";
// 	}
// 	
//       } else {
// 	// learn from model
// 	//model.clear();
// 	//extractModel(auxQuery->model(), model);
// 	std::cout << "[";
// 	for (int i=0;i<model.size();i++) {
// 	    if (model[i]>maxArg)
// 	      continue;
// 	    std::cout << idToArg[model[i]];
// 	    std::cout << ",";
// 	}
// 	std::cout << "]";
// 	
// 	std::sort(model.begin(),model.end());
// 	// learn
// 	argsToLits_learn(model,mainQuery);
// 	continue;
//       }
//     }
    
    // check if psi is unsat
    satcalls++;
    if (auxQuery->solveLimited(dummy) == false) {
//       LOGSAT("terminated in second (2) loop");
      externalError = auxQuery->externalError;
//       delete auxQuery;
//       LOGSAT("SAT calls: " << satcalls << " first loop: " << firstloop << " second loop: " << secondloop);
      return getResult(true,cred,externalError);;
    } else {
      if (auxQuery->externalError) {
//     	  delete auxQuery;
    	return getResult(false,false,true);
      }
      // learn from model
      model.clear();
      extractModel(auxQuery->model(), model);
      std::sort(model.begin(),model.end());
      // learn
      argsToLits_learn(model,mainQuery);
    }

  }
  externalError = mainQuery->externalError;
  // no success, we reject
//   LOGSAT("terminated in second (2) loop");
  if (secondloop == 0) {satcalls++;} // if we do not enter second loop, then we had at least one additional satcall
//   LOGSAT("SAT calls: " << satcalls << " first loop: " << firstloop << " second loop: " << secondloop);
//   delete auxQuery;
  return getResult(false,cred,externalError);;

  /*
  // preliminary second while loop of algo
  lbool ret = solver->solveLimited(dummy);
  while(ret) { // while phi is SAT

    // extract model I of phi and construct psi^Ivv
    for (int arg = 0;arg<=maxArg;arg++) {
      // copy solver model into an array and sort, then for each arg, do the SEM- psi^I
    }

    // while psi^I and q is sat
    // find a model I2
    // update I with I2

    // if psi^I is unsat (without q) then learnv
  } */
}

int Argusat::constructSemanticsFormulae(boost::shared_ptr<AbstractSolverWrapper> solver) {
  std::vector<AbstractLit> lits_adm, lits_range_attackers, lits_comp;
  std::multimap<int,int>::iterator it,itAdm;
  //int sem =0;

  // declare variables for solver, for now just here, more efficient would be below when we actually add them to the cnf
  //TODO CHECK
  if (semantics & CNF_RANGE_VARS) {
    for (int arg = 0;arg<=(2*maxArg)+1;arg++) {
      solver->newVar();
      if ( (semantics & STB_CLAUSES) && (arg>maxArg)) {solver->addClause(mkAbstrLit(arg)); }
    }
  } else {
    for (int arg = 0;arg<=(maxArg);arg++) solver->newVar();
  }

  // for each argument
  for (int arg = 0;arg<=maxArg;arg++) {

    // range: add arg var and its range var, and add directly -xa v xa'
    lits_range_attackers.clear();
    lits_range_attackers.push_back(mkAbstrLit(arg));
    lits_range_attackers.push_back(~mkAbstrLit(arg+maxArg+1)); // range var
    if (semantics & CNF_RANGE_VARS) solver->addClause(~mkAbstrLit(arg),mkAbstrLit(arg+maxArg+1)); // also -xa v xa'

    // complete
    lits_comp.clear();
    lits_comp.push_back(mkAbstrLit(arg+maxArg+1));

    // for each attacker of arg
    it = idToAttackersId.find(arg);
    if(it != idToAttackersId.end()) {
      do {
        std::pair<int,int> att =(*it);

        // conflict -free: for each attacker (i.e. each attack) add clause -a v -b
        AbstractLit attacked = ~mkAbstrLit(att.first);
        AbstractLit attacker = ~mkAbstrLit(att.second);
        if (semantics & CNF_CF) solver->addClause(attacked,attacker);

        // complete
        lits_comp.push_back(~mkAbstrLit(att.second+maxArg+1));

        // range
        lits_range_attackers.push_back(mkAbstrLit(att.second));
        if (semantics & CNF_RANGE_VARS) solver->addClause(~mkAbstrLit(att.second),mkAbstrLit(arg+maxArg+1));

        // admissibility
        lits_adm.clear();
        lits_adm.push_back(~mkAbstrLit(att.first));
        itAdm = idToAttackersId.find((*it).second);
        if(itAdm != idToAttackersId.end()) {
          do {
            AbstractLit defender = mkAbstrLit((*itAdm).second);
            lits_adm.push_back(defender);
            itAdm++;
          } while (itAdm != idToAttackersId.upper_bound((*it).second));
        }
        if (semantics & CNF_ADM) solver->addClause_(lits_adm);
        it++;
      } while (it != idToAttackersId.upper_bound(arg));
    }

    // range: add clause
    if (semantics & CNF_RANGE_VARS) solver->addClause_(lits_range_attackers);

    // complete
    if (semantics & CNF_COMP) solver->addClause_(lits_comp);
  }

  return 0;
}

int Argusat::nextArgumentSet(std::vector<int> &arguSet) {

  int j = 0;
  // from last to first
  for (int i=arguSet.size()-1;i>=0;i--) {

    // if we have reached the max-j
    if (arguSet[i] == maxArg - j) {
      // go to next
      j++;
      // else we found the first element to increase
    } else {
      // set values starting from i to arguSet.size()-1 to content of i, i+1, i+2 ...
      j=arguSet[i]+1;
      for (int t=i;t<=arguSet.size()-1;t++) {
        arguSet[t]=j;
        j++;
      }
      return 1;
    }
  }

  return 0;
}

int Argusat::argsToLits_aux(std::vector<int> &args, boost::shared_ptr<AbstractSolverWrapper> solver) {
  std::vector<int>::iterator it;
  it = args.begin();
  int comp = -1; // comparison variable if i equal to this then contained in model
  if (it != args.end())
    comp = *it;

  std::vector<AbstractLit> disjunctiveClause;
  // for each argument
  int start=0,max=0;
  // for LEARN_RANGE we just look at range variables
  getLimits(start,max);
  for (int i=start;i<=max;i++) {
    if (comp == i) {
      // i is in model
      solver->addClause(mkAbstrLit(i));
      it++;
      if (it != args.end())
        comp = *it;
    } else {
      // i is not in model
      AbstractLit add = mkAbstrLit(i);
      disjunctiveClause.push_back(add);
    }
  }
  solver->addClause_(disjunctiveClause);
  return 0;
}

int Argusat::argsToLits_learn(std::vector<int> &args, boost::shared_ptr<AbstractSolverWrapper> solver) {
  std::vector<int>::iterator it;
  it = args.begin();
  int comp = -1; // comparison variable if i equal to this then contained in model
  if (it != args.end())
    comp = *it;

  std::vector<AbstractLit> disjunctiveClause;
  // for each argument

  int start=0,max=0;
  // for LEARN_RANGE we just look at range variables
  getLimits(start,max);
// std::cout << "START: " << start << " END: " << max;
  for (int i=start;i<=max;i++) {
//     std::cout << "TEST " << comp;
    if (comp == i) {
      // i is in model
      it++;
      if (it != args.end())
        comp = *it;
    } else {
      // i is not in model
      disjunctiveClause.push_back(mkAbstrLit(i));
//       std::cout << "NOT IN MODEL: " << i;
    }
  }
  solver->addClause_(disjunctiveClause);
  return 0;
}

int Argusat::argsToLits_learn_range(std::vector<int> &args, boost::shared_ptr<AbstractSolverWrapper> solver,bool sat) {
  std::vector<int>::iterator it;
  it = args.begin();
  int comp = -1; // comparison variable if i equal to this then contained in model
  if (it != args.end())
    comp = *it;

  int start=0,max=maxArg;
  std::vector<AbstractLit> disjunctiveClause;

  for (int i=start;i<=max;i++) {
    if (comp != i) {
      // i is not in model
      if (!sat) {disjunctiveClause.push_back(~mkAbstrLit(i+maxArg+1));}
    } else {
      // i is in model
      disjunctiveClause.push_back(mkAbstrLit(i+maxArg+1));
      it++;
      if (it != args.end())
        comp = *it;
    }
  }
  solver->addClause_(disjunctiveClause);

  return 0;
}

int Argusat::argsToLits_range(std::vector<int> &args, std::vector<AbstractLit> &lits){
  int start=0,max=maxArg;
  std::vector<int>::iterator it;
  it = args.begin();
  int comp = -1; // comparison variable if i equal to this then contained in model
  if (it != args.end())
    comp = *it;

  for (int i=start;i<=max;i++) {
    if (comp != i) {
      // i is not in model
      lits.push_back(mkAbstrLit(i+maxArg+1));
    } else {
      // i is in model
      lits.push_back(~mkAbstrLit(i+maxArg+1));
      it++;
      if (it != args.end())
        comp = *it;
    }
  }
  return 0;
}

int Argusat::extractModel(std::vector<int> solverModel, std::vector<int> &model) {
  int start=0,max=0;
  // for LEARN_RANGE we just look at range variables
  getLimits(start,max);
//   std::cout << "SOLVEMODEL: " << solverModel.size();
  for (int i=start;i<solverModel.size();i++) {
//     std::cout << "ITER: " << i;
    if (i>max)// || i<start)
      break;
    if (solverModel[i]==abstr_l_True) {
//       std::cout << "TRUE: " << i;
      model.push_back(i);
//     } else {
//       std::cout << "FALSE: " << i;
    }
  }

  return 0;
}

void Argusat::getLimits(int &start, int &max) {
  if (semantics & LEARN_RANGE) {
    start = maxArg+1;
    max = maxArg*2+1;
  } else { // learn only arg variables, no range vars
    start = 0;
    max = maxArg;
  }
  return;
}

int Argusat::getResult(bool result, bool cred, bool externalError) {
	if (externalError) {
		return -1;
	} else {
		if (mode==MODE_SKEPT) {
		  if (result) {std::cout << "NO";} else {std::cout << "YES";}
		} else if (mode==MODE_CRED) {
		  if (result) {std::cout << "YES";} else {std::cout << "NO";}
		}
		return RESULTACCEPTANCE(result,cred);
	}
}
