// 
// Copyright (c) 2012-2017, Johannes Wallner
// 
// This file (ArguSolverFactory.h) is part of cegartix
// 
// cegartix is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// cegartix is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with cegartix; if not, write to the Free Software
// Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
//


#ifndef ARGUSOLVERFACTORY_H_
#define ARGUSOLVERFACTORY_H_

#include "AbstractSolverWrapper.h"
#include "MinisatWrapper.h"
//#include "ClaspWrapper.h"
#include "ExternalSolver.h"
#include <boost/shared_ptr.hpp>

enum ARGU_SOLVER_TYPE { MINISAT_SOLV, CLASP_SOLV, EXTERNAL_SOLV };

class ArguSolverFactory
{
public:
	boost::shared_ptr<AbstractSolverWrapper> getSolver();
	void setExternalSolver(std::string filename);
	ARGU_SOLVER_TYPE curOracleType;
	std::string externalSolver;
};

#endif /* ARGUSOLVERFACTORY_H_ */
