// 
// Copyright (c) 2012-2017, Johannes Wallner
// 
// This file (ArguSolverFactory.cpp) is part of cegartix
// 
// cegartix is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// cegartix is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with cegartix; if not, write to the Free Software
// Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
//

#include "ArguSolverFactory.h"
#include <boost/shared_ptr.hpp>

boost::shared_ptr<AbstractSolverWrapper> ArguSolverFactory::getSolver() {
	switch (curOracleType) {
		case MINISAT_SOLV:
			{boost::shared_ptr<AbstractSolverWrapper> msolver(new MinisatWrapper);
			return msolver; }//new MinisatWrapper(); 
			break;
// 		case CLASP_SOLV:
// 			return new ClaspWrapper();
// 			break;
// 		case EXTERNAL_SOLV:
// 			boost::shared_ptr<AbstractSolverWrapper> solver(new ExternalSolver(this->externalSolver));
// 			return solver //factory(new ExternalSolver(this->externalSolver)) //new ExternalSolver(this->externalSolver);
// 			break;
		default:
			{boost::shared_ptr<AbstractSolverWrapper> solver(new MinisatWrapper);
			return solver; } //factory(new MinisatWrapper);
			break;
	}
}

void ArguSolverFactory::setExternalSolver(std::string filename) {
	externalSolver = filename;
}
