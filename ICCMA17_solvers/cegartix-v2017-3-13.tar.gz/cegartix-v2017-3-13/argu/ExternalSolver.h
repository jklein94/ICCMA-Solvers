// 
// Copyright (c) 2012-2017, Johannes Wallner
// 
// This file (ExternalSolver.h) is part of cegartix
// 
// cegartix is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// cegartix is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with cegartix; if not, write to the Free Software
// Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
//

#ifndef EXTERNALSOLVER_H_
#define EXTERNALSOLVER_H_

#include "AbstractSolverWrapper.h"
#include "stdio.h"
#include "iostream"
#include "string"
#include <sstream>
//#include <iostream>
#include <fstream>
#include "boost/iostreams/stream.hpp"
#include "boost/iostreams/device/file_descriptor.hpp"
#include "boost/lexical_cast.hpp"

class ExternalSolver: public AbstractSolverWrapper
{
public:
	ExternalSolver(std::string filename);
	//~ClaspWrapper();
	bool addClause(AbstractLit p);
	bool addClause(AbstractLit p, AbstractLit q);
	bool addClause(AbstractLit p, AbstractLit q, AbstractLit r);
	bool addClause_(std::vector<AbstractLit>& ps);
	int newVar();
	bool solve();
	bool solveLimited(std::vector<AbstractLit>& assumps);
	std::vector<int> model();
	bool simplify();
	bool dumpSATinstance(char *tmpfile, std::vector<AbstractLit>& assumps);
	bool executeExternalSolver(char *tmpfile);
	bool parseExternalSolverOutput();
	std::string filename;
	std::vector<std::vector<AbstractLit> > clausesToProcess;
//	std::vector<Clasp::Literal> assumptions;
	std::vector<int> resModel;
	bool modelFound;
	int maxVar;
};


#endif /* EXTERNALSOLVER_H_ */
